title: 部署solo博客自动升级
date: '2019-04-10 23:23:40'
updated: '2019-04-15 20:39:50'
tags: [linux]
permalink: /articles/2019/04/10/1554909820806.html
---
定于每周三的早上5点准时升级solo，有那么一段时间发现pull一个solo镜像用了好长时间，打算打印一下时间计算下pull一个镜像到底又做猛？

```
#!/bin/bash
#
# Solo docker 升级并且重启脚本
# 参考solo指南 https://hacpai.com/article/1492881378588
#
echo "-----------------升级前------------------------------------"
start_time=`date +'%Y-%m-%d %H:%M:%S'`
docker pull b3log/solo
docker stop solo
docker rm solo
docker run --detach --name solo --network=host \
    --env RUNTIME_DB="MYSQL" \
    --env JDBC_USERNAME="root" \
    --env JDBC_PASSWORD="xxxxxxxxxxx" \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
    --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
    b3log/solo --listen_port=8080 --server_scheme=http  --server_host=www.cjzshilong.cn

if [[ $? == 0 ]];
   then
        echo -e ""$start_time 拉取镜像完成并且安装成功！！！""
   else
        echo -e "solo docker 升级有报错，请检查！！！  " 

fi
end_time=`date +'%Y-%m-%d %H:%M:%S'`
start_seconds=$(date --date="$start_time" +%s);
end_seconds=$(date --date="$end_time" +%s);
echo "升级所用时间为："$((end_seconds-start_seconds))"s"
echo "开始时间为: $start_time ,结束时间为：$end_time"

echo "----------------升级完毕！！！！-----------------------------"
```

下次升级看下打印的日志，安排一下啊，大哥，不想本地测试了！下周三的