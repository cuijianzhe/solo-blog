title: '@Scheduled 增加 @Transactional 事务'
date: '2019-11-30 15:38:02'
updated: '2019-11-30 15:39:15'
tags: [java]
permalink: /articles/2019/11/30/1575099482173.html
---
![](https://img.hacpai.com/bing/20180130.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 定时任务与事务合理搭配结构为：
```
@Autowired
Y y;

@ Scheduled()
void xxx(){
   y.x();
}


class Y {
   @Transactional
   x(){
   }
}
```

### 错误示例：
```java   
@Scheduled(fixedDelay = 5201314)   
 @Autowired   
 public void storeHuaweiData(){   
 iAgentQueryService.delHwSkillGroups();   
 int i = 0/1;   
 int i2 = 1/0;   
 iAgentQueryService.addHwSkillGroups();   
 }   
```


### 生效示例：
```java
    @Scheduled(fixedDelay = 5201314)
    public void storeHuaweiData(){
        SkillGroupsTransactional skillGroupsTransactional = new SkillGroupsTransactional();
        skillGroupsTransactional.transactional(hwSkillGroups);
    }
```
```java
package com.ulane.spring.job;

import com.ulane.spring.bean.agent.HwSkillGroup;
import com.ulane.spring.service.IAgentQueryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author Xu Yuntong
 * @date 2019/11/30 15:21
 */
public class SkillGroupsTransactional {

    @Autowired
    protected IAgentQueryService iAgentQueryService;

    @Transactional
    public void transactional(List<HwSkillGroup> hwSkillGroups){
        iAgentQueryService.delHwSkillGroups();
        int i = 0/1;
        int i2 = 1/0;
        iAgentQueryService.addHwSkillGroups(hwSkillGroups);
    }
}

```

