title: 使用python发送邮件
date: '2019-03-16 11:39:16'
updated: '2019-03-16 13:15:12'
tags: [python]
permalink: /articles/2019/03/16/1552707556605.html
---
:cold_sweat: **废话就不多说了，直接上代码**  :cold_sweat:

```python
from email.mime.text import MIMEText
from_addr = input("From:")
password = input('Password:')
toaddr = input('To:')
#msg =MIMEText('你好啊，我是崔建哲，powerd by python')
msg = MIMEText('<html><body><h1>你好啊</h1>'+
      '<p>send by <a href="http://144.34.226.13/images/cuijianzhe.jpg">Python</a>...</p>'+
      '</body></html>','html','utf-8')
##设置标题的一些主题，邮件来自，和邮件发送
msg['Subject'] = '文鸯....----崔建哲的邮件'
msg['From'] = from_addr
msg['TO'] = toaddr
smtp_server = 'smtp.qq.com'
import smtplib
#创建一个SMTP实例对象，并25是默认邮件发送端口
server = smtplib.SMTP(smtp_server,25)
#登录SMTP服务器
server.login(from_addr,password)
#发送邮件 第一个参数是发送的地址，第二个是接收地址，第三个是msg然后利用as_string（）,把MIMEText变成一个str，当然[toaddr] 可以写成一个列表。发送给多个人
server.sendmail(from_addr,toaddr,msg.as_string())
server.close
```

### 使用方法：
如果用的是QQ邮箱需要生成第三方邮箱授权码：
![shouquanma.png](https://img.hacpai.com/file/2019/03/shouquanma-e26a4b8e.png)

然后运行py脚本

![pythonyoujian.png](https://img.hacpai.com/file/2019/03/pythonyoujian-a889cbb2.png)

### 结果：
![pythonyoujian1.png](https://img.hacpai.com/file/2019/03/pythonyoujian1-54527b07.png)





