title: 治疗snow的猫瘟之路
date: '2019-05-16 10:54:12'
updated: '2019-05-17 23:43:30'
tags: [人情世故]
permalink: /articles/2019/05/16/1557975252062.html
---
# 2019年5月5日  :cry:  :sob: 
这一天，把之前的决定落实，就是做绝育。因为它乱尿尿的症状困扰了我半个月了，最严重的时候尿我枕巾上面，导致我把枕头扔了，因为太臭了。当天情况良好，做完后麻药没过，四肢无力的在地上转圈。

<img src="https://cjz.cjzshilong.cn/%E7%9D%A1%E8%A7%89.jpg" width=500 height=256 />
<img src="https://cjz.cjzshilong.cn/%E7%8C%AB%E5%92%AA5.5.jpg" width=500 height=256 />
# 2019年5月12日-5月14日
发现猫咪吐是做完绝育后的一周，我休息，之前看到床底下的以为是尿的，后来去医院看病，没查出结果，大了三针。第二天没效果。上班闲暇时看了一下监控，看到猫咪正在呕吐，决定下班后再次去看病。

  ** 这是查看监控到猫咪吐的视频，受苦了。**  :sob: 

<video width="100%" height="100%" controls>
<source src="https://cjz.cjzshilong.cn/%E5%90%90%E7%9A%84%E8%A7%86%E9%A2%91.mp4" 
 type="video/mp4">
</video>

在家人的建议下喂小米粥会好点，可是……已经一周没吃什么东西了，再这样下去必死无疑了。

<video width="100%" height="100%" controls>
<source src="https://cjz.cjzshilong.cn/%E5%B0%8F%E7%B1%B3%E7%B2%A5.mp4" 
 type="video/mp4">
</video>

**下图这是猫咪的呕吐物，吐这个黄水已经一周多了，光吐不吃饭，心疼。**  :sob: 

<img src="https://cjz.cjzshilong.cn/%E5%90%90%E7%9A%84%E9%BB%84%E6%B0%B4.jpg" width=400 height=200 />

下班又去看病，因为一天中吐了三次，我又去了，检查的是抽血化验、猫瘟测试。最后确诊为猫瘟。没打疫苗的猫很容易出现的病症。所以，脖子上又挨了三针药。晚上到家后，医生给我打电话，建议住院，避免耽误病情。
<img src="https://cjz.cjzshilong.cn/%E5%8C%96%E9%AA%8C%E5%8D%95.jpg" width=500 height=256 />

<img src="https://cjz.cjzshilong.cn/%E5%8C%96%E9%AA%8C%E5%8D%951.jpg" width=500 height=256 />
<img src="https://cjz.cjzshilong.cn/%E8%B4%9D%E8%B4%9D.jpg" width=500 height=256 />

# 2019年5月15日 :sob: 
猫咪在医院输液第一天，钱不钱的无所谓了。也了解过大概会话多少钱。治吧，陪了我一年了。 :sob: 

<img src="https://cjz.cjzshilong.cn/%E5%8C%BB%E9%99%A2%E7%AC%BC%E5%AD%90.jpg" width=500 height=256 />

<video width="100%" height="100%" controls>
<source src="https://cjz.cjzshilong.cn/%E5%8C%BB%E9%99%A2%E7%8E%AF%E5%A2%83.mp4" 
 type="video/mp4">
</video>

但是，这医院的免疫隔离室是真的臭，坚持一下吧，快点好起来。 :cry: 

# 2019年5月16日 确诊第二天 :sob: 
今天早上我看见它又吐了，唉。再次踏上治疗之路。今晚医生说灌了点钡餐，明天给它拍下片子，今天看的肠胃那里有便但是不拉，医生说建议让猫留宿医院一晚，唉，不舍。医院气味不佳，弥漫病毒。只能尽力了。

<img src="https://cjz.cjzshilong.cn/%E4%BB%8A%E5%A4%A9516.jpg" width=550 height=400 />
晚上下班看了小猫一眼。弗泪离去，强忍着难过打开家门，开始了……思念  :cry:  :sob: 
<img src="https://cjz.cjzshilong.cn/516.jpg" width=550 height=400 />

# 2019年5月17日 输液第三天
今天加了医生微信，因为方便实时沟通snow当前情况。

<img src="https://cjz.cjzshilong.cn/%E5%AF%B9%E8%AF%9D.png" width=500 height=260 />

今天看到这情况，还是没活力没精神啊…… :cry:  :sob: 

<video width="100%" height="100%" controls>
<source src="https://cjz.cjzshilong.cn/517.mp4" 
 type="video/mp4">
</video>

下班后去看了一眼，医生让我看了下片子，说是钡餐蠕动很慢，今天做了下排便，再次灌钡餐明天在拍片子，看下胃肠情况。是否有异物还是胃肠有毛病。再针对治疗。
<video width="100%" height="100%" controls>
<source src="https://cjz.cjzshilong.cn/517night.mp4" 
 type="video/mp4">
</video>
