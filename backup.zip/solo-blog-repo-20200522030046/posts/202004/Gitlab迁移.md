title: Gitlab迁移
date: '2020-04-25 11:10:13'
updated: '2020-04-26 12:57:06'
tags: [Linux, Gitlab]
permalink: /articles/2020/04/25/1587784213122.html
---
# docker-compose创建的gitlab迁移到ECS

**安装gitlab需要的组件：**
```
ssh-copy-id -i ~/.ssh/id_rsa.pub backup_ip  #授信免密登陆
scp backup_files backup_ip:/data/gitlab/backups/  #传输备份文件
yum install curl policycoreutils openssh-server openssh-clients postfix  policycoreutils-python  -y
wget https://mirrors.tuna.tsinghua.edu.cn/gitlab-ce/yum/el7/gitlab-ce-11.8.1-ce.0.el7.x86_64.rpm
rpm -ivh gitlab-ce-11.8.1-ce.0.el7.x86_64.rpm
```
## 进行备份迁移：
**注意：先改配置文件**
```
[root@pro /var/opt/gitlab/backups]# vim /etc/gitlab/gitlab.rb
...
gitlab_rails['manage_backup_path'] = true
gitlab_rails['backup_path'] = "/alidata/gitlab/git-data/backups"  #修改备份数据目录.
...
 git_data_dirs({                                                                 
     "default" => {                                                              
     "path" => "/alidata/gitlab/git-data"                                        
     }                                                                           
 })

[root@iZ2zed92f8g67tyf26ql2wZ ~]# mkdir -p /data/gitlab/git-data
[root@iZ2zed92f8g67tyf26ql2wZ ~]# chown git:git /data/gitlab/git-data/
```
```
# 进行迁移：
gitlab-ctl reconfigure
gitlab-rake gitlab:backup:restore BACKUP=xxxx
```

## gitlab端口配置：
```
[root@iZ2zed92f8g67tyf26ql2wZ ~]# vim /var/opt/gitlab/nginx/conf/gitlab-http.conf 
...
server {
  listen *:80;


  server_name 172.16.16.36;
  server_tokens off; ## Don't show the nginx version number, a security best practice
...
```

```
[root@iZ2zed92f8g67tyf26ql2wZ ~]# vim /var/opt/gitlab/gitlab-rails/etc/unicorn.rb
...
# What ports/sockets to listen on, and what options for them.
listen "127.0.0.1:10080", :tcp_nopush => true
listen "/var/opt/gitlab/gitlab-rails/sockets/gitlab.socket", :backlog => 1024
...
```

```
[root@iZ2zed92f8g67tyf26ql2wZ etc]# vim /etc/gitlab/gitlab.rb
gitlab_rails['gitlab_shell_ssh_port'] = 10022
gitlab_rails['gitlab_shell_git_timeout'] = 80
 unicorn['listen'] = '127.0.0.1'
 unicorn['port'] = 10080
nginx['listen_addresses'] = ['*']
nginx['listen_port'] = 80
```
> 更改clone代码http端口
```
[root@iZ2zed92f8g67tyf26ql2wZ config]# vim /opt/gitlab/embedded/service/gitlab-rails/config/gitlab.yml
  gitlab:
    ## Web server settings (note: host is the FQDN, do not include http://)
    host: 172.16.16.36
    port: 10080
    https: false
```



**执行 `gitlab-ctl reconfigure`**


## 常见配置及命令

**配置、服务**

gitlab配置文件：/etc/gitlab/gitlab.rb
重新加载配置：gitlab-ctl reconfigure
重启服务：gitlab-ctl restart
启动服务：gitlab-ctl start
停止服务：gitlab-ctl stop

**日志位置**

日志路径：` /var/log/gitlab`
查看所有日志：`gitlab-ctl tail`
查看nginx日志：`gitlab-ctl tail nginx/gitlab_access.log`
查看指数据库日志：`gitlab-ctl tail postgresql`

**数据库**

重启数据库：` gitlab-ctl restart postgresql`

数据库配置文件：（修改内容后，需要修改对应的 /etc/gitlab/gitlab.rb 配置，否则重新加载gitlab配置文件后修改会失效）

```
/var/opt/gitlab/gitlab-rails/etc/database.yml
/var/opt/gitlab/postgresql/data/postgresql.conf
/var/opt/gitlab/postgresql/data/pg_hba.conf
```

### postfix启动报错
`systemctl start postfix`

邮件配置
vi /etc/postfix/main.cf 

发现配置为：
```
inet_interfaces = localhost
inet_protocols = all
```
改成：
```
inet_interfaces = all
inet_protocols = all
```

参考：
https://docs.gitlab.com/omnibus/settings/configuration.html#storing-git-data-in-an-alternative-directory
https://www.cnblogs.com/ssgeek/p/9392104.html
