title: 并发工具类 ---Semaphore
date: '2019-04-15 16:48:34'
updated: '2019-04-16 21:01:29'
tags: [进阶之路]
permalink: /articles/2019/04/15/1555318114318.html
---
![](https://img.hacpai.com/bing/20180701.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

![票.jpg](https://img.hacpai.com/file/2019/04/票-90304765.jpg)

### 模拟场景：
`北京开往邯郸的火车K7761开始售票，在9号站台验票进站，进站口只有三个，许许多多的乘客排成长队验票进站。
`
`那么此时三个进站口就是有限的公共资源，乘客们就是线程。
`
`Semaphore信号量是用来控制同时访问特定资源的线程数量，它通过协调各个线程，以保证合理的使用公共资源。`

```
public class testMain {

    public static void main(String[] args) {

        int ticketGate = 3;//检票口
        int numberOfPassengers = 9527;//乘客数量d

        Semaphore semaphore = new Semaphore(ticketGate);
        //允许进入3人,剩下的人想进入时，需等待前面的人已经进入站。

        for (int i = 0; i < numberOfPassengers; i++) {
            new Through(i,semaphore).start();
        }
    }

    static class Through extends Thread{
        private int n;
        private Semaphore semaphore;

        public Through(int n,Semaphore semaphore){
            this.n = n;
            this.semaphore = semaphore;
        }

        @Override
        public void run(){
            try {
                semaphore.acquire();//占用进站口
                System.out.println(n+"号乘客doing");
                Thread.sleep(2000);//2秒的进站时间
                semaphore.release();//进入站
                System.out.println(n+"号乘客ok");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
```
### 运行结果
![实验结果.png](https://img.hacpai.com/file/2019/04/实验结果-96331b8c.png)
