title: 编写一个自动安装zabbix-agentd客户端的脚本
date: '2019-04-07 19:48:07'
updated: '2019-10-31 20:25:57'
tags: [Linux]
permalink: /articles/2019/04/07/1554637687016.html
---
刚上架7台服务器，想试下水，写一个自动安装agentd脚本进行监控，磨刀不误砍柴工，说干就干！

```bash
#!/bin/bash
#This bash is for install zabbix-agentd .
#Author:cuijianzhe
#Email:598941324@qq.com
#Create date: 2019-4-7
version=zabbix-4.2.0
logfile_dir=/var/log/zabbix/
tar_dir=/usr/local/src
download_dir=/root/
date=`date +%Y-%m-%d`
logfile="$logfile_dir"agentd_install.log
filename=zabbix-4.2.0.tar.gz
BINARY_NAME=zabbix_agentd
conf_file=/usr/local/zabbix/etc/zabbix_agentd.conf
#-----------------------------------------------------------------------------------------------------------#
 [ ! -d $logfile_dir ]  && mkdir -p $logfile_dir   ##判断路径是否存在，没有则创建
 if [ ! -f "$logfile" ];
    then
        touch $logfile
 fi
#-----------------------------------------------------------------------------------------------------------#
yum install gcc pcre*  wget -y
wget -P $download_dir https://jaist.dl.sourceforge.net/project/zabbix/ZABBIX%20Latest%20Stable/4.2.0/$filename
groupadd zabbix
useradd -s /sbin/nologin -g zabbix zabbix
tar xf  $download_dir$filename -C $tar_dir
cd $tar_dir/$version
  ./configure --prefix=/usr/local/zabbix  --enable-agent
#----------------------------------------------------------------------------------------------------------#
if [[ $? == 0 ]];
   then
        make install
        rm $download_dir/$filename
        echo -e "$date  Make install zabbix-agentd Success !!!"  > $logfile
    else
        echo -e "$date zabbix-agentd is fail install " > $logfile

fi
#-------------------------启动脚本--------------------------------------------------#
cp $tar_dir/$version/misc/init.d/fedora/core/$BINARY_NAME   /etc/rc.d/init.d/
sed -i -e 's|BASEDIR=/usr/local|BASEDIR=/usr/local/zabbix|' /etc/init.d/$BINARY_NAME
chmod  +x /etc/init.d/$BINARY_NAME
/etc/init.d/$BINARY_NAME start

#----------------------写入配置文件---------------------------------#
> $conf_file && cat << EOF > $conf_file
PidFile=/tmp/zabbix_agentd.pid
LogFile=/var/log/zabbix/agentd.log
LogFileSize=10
DebugLevel=3
EnableRemoteCommands=1
LogRemoteCommands=1
Server=192.168.51.202
ListenPort=10050
StartAgents=2
ServerActive=192.168.51.202
Timeout=30
AllowRoot=1
Include=/usr/local/zabbix/etc/zabbix_agentd.conf.d/*.conf
EOF

/etc/init.d/$BINARY_NAME restart

chkconfig --add $BINARY_NAME
chkconfig  $BINARY_NAME on       #开机自启动
netstat -antup | grep 10050
```

执行脚本的话可以输出到屏幕看下过程是否有报错
`sh zabbix-agent_install_.sh | tee log.txt`

花了一定时间，不过跑过测试没出问题，心里一大安慰。
查看安装成功日志
```
[root@localhost ~]# cat /var/log/zabbix/agentd_install.log 

2019-04-07  Make install zabbix-agentd Success !!!
```

附件如下：
zabbix自动安装脚本文件，下载即可使用：
[zabbix-agent_install.rar]
下载链接： [zabbixagentinstall.rar](https://img.hacpai.com/file/2019/04/zabbixagentinstall-e2acc2c2.rar)
