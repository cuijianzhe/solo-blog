title: vmware添加硬盘识别问题
date: '2022-06-13 19:30:07'
updated: '2022-06-13 19:30:07'
tags: [vmware]
permalink: /articles/2022/06/13/1655119806937.html
---
添加硬盘后，输入如下命令可识别：

```
echo '- - -' > /sys/class/scsi_host/host0/scan  #vm虚拟机扫描硬盘并识别硬盘
```



