title: nginx反向代理tomcat项目之solo
date: '2019-03-15 19:17:18'
updated: '2019-03-21 14:25:39'
tags: [nginx]
permalink: /articles/2019/03/15/1552648638089.html
---
nginx配置

```
upstream backend {

    server localhost:8080; # Tomcat/Jetty 监听端口
}
    #access_log  logs/access.log  main;
    sendfile        on;
    keepalive_timeout  65;

    #gzip  on;

      server {
        listen       80;
        server_name  www.cjzshilong.cn;
        #charset koi8-r;
        #access_log  logs/host.access.log  main;
        location / {
        proxy_pass http://backend$request_uri;
        proxy_set_header  Host $host:$server_port;
        proxy_set_header  X-Real-IP  $remote_addr;
        server_name_in_redirect off;
        proxy_set_header REMOTE-HOST $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        client_max_body_size  10m;
        }
```