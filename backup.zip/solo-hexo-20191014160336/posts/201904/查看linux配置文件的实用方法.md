title: 查看linux配置文件的实用方法
date: '2019-04-06 18:30:33'
updated: '2019-09-15 00:31:56'
tags: [linux]
permalink: /articles/2019/04/06/1554546633835.html
---
![](https://img.hacpai.com/bing/20171221.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 查看打印文件没被注释的内容
`[root@inside ~]# grep  -v "^#" /etc/zabbix/zabbix_agentd.conf`

`[root@inside ~]# grep "^[a-Z]" /etc/zabbix/zabbix_agentd.conf `
以上方式不会去除空格，只会把没有注释掉的打印出来。

```
 grep -v "^$\|^#" /etc/ssh/sshd_config 
```

```
grep -E -v "^$|^#" /etc/ssh/sshd_config
```

```
 egrep -v "^$|^#" /etc/ssh/sshd_config 
```

*  查看file中的同行所在行号
```
$ awk '/^$/{print NR}' apdiscovery.sh 
9
```
* 计算第二列的和并输出
```
$ cat sum.txt| awk -F " " '{sum+=$2}END{print sum}'
273

# root @ zabbix in ~ [14:14:23] 
$ cat sum.txt 
张三 123
李四 100
王五 50


```
* 查看目录下包含“root”的所有文件
```
grep -r "root" /home | cut -d ":" -f 1
```

