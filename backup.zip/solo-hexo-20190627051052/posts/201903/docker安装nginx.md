title: docker安装nginx
date: '2019-03-28 16:10:03'
updated: '2019-04-04 23:13:33'
tags: [linux]
permalink: /articles/2019/03/28/1553760603642.html
---
![](https://img.hacpai.com/bing/20190224.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


```
[root@bogon ~]# docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
docker.io/centos    latest              9f38484d220f        13 days ago         202 MB
[root@bogon ~]# docker run -it docker.io/centos:latest /bin/bash
[root@0c27bcf9bd58 /]# yum install vim wget -y
[root@0c27bcf9bd58 /]# yum -y install make gcc gcc-c++ flex bison file libtool libtool-libs autoconf kernel-devel libjpeg libjpeg-devel libpng libpng-devel gd freetype freetype-devel libxml2 libxml2-devel zlib zlib-devel glib2 glib2-devel bzip2 bzip2-devel libevent ncurses ncurses-devel curl curl-devel e2fsprogs e2fsprogs-devel krb5-devel libidn libidn-devel openssl openssl-devel gettext gettext-devel ncurses-devel gmp-devel unzip libcap lsof
[root@0c27bcf9bd58 /]# wget https://ftp.pcre.org/pub/pcre/pcre-8.39.tar.gz
[root@0c27bcf9bd58 /]# wget http://nginx.org/download/nginx-1.15.10.tar.gz
[root@0c27bcf9bd58 /]# tar xf pcre-8.39.tar.gz -C /usr/local/src/
[root@0c27bcf9bd58 /]# tar xf nginx-1.15.10.tar.gz -C /usr/local/src/
[root@0c27bcf9bd58 nginx-1.15.10]# useradd -M -s /sbin/nologin nginx 
[root@0c27bcf9bd58 nginx-1.15.10]#   ./configure --prefix=/usr/local/nginx --with-http_dav_module --with-http_stub_status_module --with-http_addition_module --with-http_sub_module --with-http_flv_module --with-http_mp4_module --with-pcre=/usr/local/src/pcre-8.39  --user=nginx --group=nginx  --with-http_stub_status_module --with-http_ssl_module
[root@0c27bcf9bd58 nginx-1.15.10]# make && make install 
[root@0c27bcf9bd58 ~]# vim /usr/local/nginx/conf/nginx.conf
[root@0c27bcf9bd58 ~]# /usr/local/nginx/sbin/nginx
 ```

* 安装完成并启动后测试：
```
[root@0c27bcf9bd58 ~]# echo "woaini" > /usr/local/nginx/html/test.html
[root@0c27bcf9bd58 ~]# curl localhost/test.html
woaini
[root@0c27bcf9bd58 ~]# 
```
![nginxdocker.png](https://img.hacpai.com/file/2019/03/nginxdocker-860d85a2.png)

* 通估镜像生成容器实例
```
[root@bogon ~]# docker ps -a

CONTAINER ID        IMAGE                     COMMAND             CREATED             STATUS              PORTS               NAMES
0c27bcf9bd58        docker.io/centos:latest   "/bin/bash"         16 minutes ago      Up 16 minutes                           modest_kalam
[root@bogon ~]# docker commit 0c27bcf9bd58 docker.io/centos:nginx
sha256:a48ad0a5e910fbf741120b1690866c10d0b888de70b2f0ac153860b5f22821f4
[root@bogon ~]# docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
docker.io/centos    nginx               a48ad0a5e910        7 seconds ago       654 MB
docker.io/centos    latest              9f38484d220f        13 days ago         202 MB
```
![dockernginxtag.png](https://img.hacpai.com/file/2019/03/dockernginxtag-a2da8970.png)

```
[root@bogon ~]# docker run -it centos:nginx /bin/bash
[root@f8f6ba65fdea ~]# /usr/local/nginx/sbin/nginx 
[root@f8f6ba65fdea ~]# ps -aux | grep nginx
root         22  0.0  0.1  46084  1144 ?        Ss   08:28   0:00 nginx: master process /usr/local/nginx/sbin/nginx
nginx        23  0.0  0.1  46548  1928 ?        S    08:28   0:00 nginx: worker process
root         25  0.0  0.0   9088   668 ?        S+   08:28   0:00 grep --color=auto nginx
```
![nginxqidong.png](https://img.hacpai.com/file/2019/03/nginxqidong-115a0b77.png)

说明基于docker的nginx服务器搭建成功

* 查看容器的ip
```
[root@f8f6ba65fdea ~]# ifconfig

eth0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet 172.17.0.3  netmask 255.255.0.0  broadcast 0.0.0.0
        inet6 fe80::42:acff:fe11:3  prefixlen 64  scopeid 0x20<link>
        ether 02:42:ac:11:00:03  txqueuelen 0  (Ethernet)
        RX packets 54  bytes 317758 (310.3 KiB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 53  bytes 3817 (3.7 KiB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0

lo: flags=73<UP,LOOPBACK,RUNNING>  mtu 65536
        inet 127.0.0.1  netmask 255.0.0.0
        inet6 ::1  prefixlen 128  scopeid 0x10<host>
        loop  txqueuelen 1000  (Local Loopback)
        RX packets 14  bytes 1104 (1.0 KiB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 14  bytes 1104 (1.0 KiB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0

```

* 保存镜像到本地
```
[root@bogon ~]# docker save -o docker.io-centos-nginx-image.tar  docker.io/centos:nginx 
[root@bogon ~]# ll -h
总用量 651M
-rw-------. 1 root root 1.3K 11月 17 15:34 anaconda-ks.cfg
-rw-------. 1 root root 651M 3月  28 16:33 docker.io-centos-nginx-image.tar
[root@bogon ~]# 
```

* 端口映射：
```
[root@bogon ~]# docker run -d -p 80:80 docker.io/centos:nginx 

230fa0ae2a49ef248c5dce6f336e084142587e887bb2c117cbbdd8de878c914f
```

* 容器自启动
```
[root@bogon ~]# docker run  --restart=always -itd --name mynginx centos:nginx /bin/bash 

f6caa1100ce758494cd55e3dc6aaad3f68ef0e80d9fae12c58e9ae0960d85b5a
```
