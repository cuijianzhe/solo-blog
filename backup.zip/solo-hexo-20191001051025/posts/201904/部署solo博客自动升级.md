title: 部署solo博客自动升级
date: '2019-04-10 23:23:40'
updated: '2019-09-25 20:09:31'
tags: [linux, solo]
permalink: /articles/2019/04/10/1554909820806.html
---
## 1.1版本
**特性：自动升级solo博客版本，打印升级所用时间，是否报错等信息**
定于每周三的早上5点准时升级solo，有那么一段时间发现pull一个solo镜像用了好长时间，打算打印一下时间计算下pull一个镜像到底又做猛？

```bash
#!/bin/bash
#
# Solo docker 升级并且重启脚本
# 参考solo指南 https://hacpai.com/article/1492881378588
#
echo "-----------------升级前------------------------------------"
start_time=`date +'%Y-%m-%d %H:%M:%S'`
docker pull b3log/solo
docker stop solo
docker rm solo
docker run --detach --name solo --network=host \
    --env RUNTIME_DB="MYSQL" \
    --env JDBC_USERNAME="root" \
    --env JDBC_PASSWORD="xxxxxxxxxxx" \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
    --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
    b3log/solo --listen_port=8080 --server_scheme=http  --server_host=www.cjzshilong.cn

if [[ $? == 0 ]];
   then
        echo -e ""$start_time 拉取镜像完成并且安装成功！！！""
   else
        echo -e "solo docker 升级有报错，请检查！！！  " 

fi
end_time=`date +'%Y-%m-%d %H:%M:%S'`
start_seconds=$(date --date="$start_time" +%s);
end_seconds=$(date --date="$end_time" +%s);
echo "升级所用时间为："$((end_seconds-start_seconds))"s"
echo "开始时间为: $start_time ,结束时间为：$end_time"

echo "----------------升级完毕！！！！-----------------------------"
```

下次升级看下打印的日志，安排一下啊，大哥，不想本地测试了！下周三的

## 1.2版本
新增特性：自动删除下载的docker images，因为每次升级，原有的images不会删除，升级后自动删除特性增加
```bash
#!/bin/bash  
  
#  
# Solo docker 升级脚本&删除旧的镜像脚本  
#  
echo "-----------------------------------------------------------"  
echo "-----------------升级前------------------------------------"  
start_time=`date +'%Y-%m-%d %H:%M:%S'`  
docker pull b3log/solo  
docker stop solo  
docker rm solo  
docker run --detach --name solo --network=host \  
 --env RUNTIME_DB="MYSQL" \  
 --env JDBC_USERNAME="solo" \  
 --env JDBC_PASSWORD="b3blogsolo" \  
 --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \  
 --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \  
 --volume /dockerdata/solo/skins/:/opt/solo/skins/ \  
 --rm \  
 b3log/solo --listen_port=8080 --server_scheme=https --lute_http=  --server_host=www.cjzshilong.cn --server_port=  
if [[ $? == 0 ]];  
 then  
 echo -e ""$start_time 拉取镜像完成并且安装成功！！！""  
 else  
 echo -e "solo docker 升级有报错，请检查！！！  "   
  
fi  
end_time=`date +'%Y-%m-%d %H:%M:%S'`  
start_seconds=$(date --date="$start_time" +%s);  
end_seconds=$(date --date="$end_time" +%s);  
echo "升级所用时间为："$((end_seconds-start_seconds))"s"  
echo "开始时间为: $start_time ,结束时间为：$end_time"  
  
echo "----------------升级完毕！！！！-----------------------------"  
echo "                                                             "  
  
#安装lute_http  
#docker pull b3log/lute-http  
# docker run --detach --name lute-http  --rm --network=host b3log/lute-http  
  
sleep 5  
#删除docker镜像脚本：  
echo -e "##############################尝试删除旧镜像，如下############################################"  
docker images  
num=`docker images |grep b3log/solo|wc -l`  
#echo $num  
  
if [ "$num" -gt 1 ]; then  
 images=`docker images |grep b3log/solo | awk 'NR==2{print $3}'`  
 echo $images  
 docker rmi $images  
 docker images  
 echo -e "#############################$end_time 删除镜像id:$images ####################################"  
  
else  
 echo -e "####################$end_time 没有旧的镜像可删除 ####################################"  
fi  
echo -e "
```
