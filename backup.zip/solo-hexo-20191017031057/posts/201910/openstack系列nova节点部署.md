title: openstack系列-nova节点部署
date: '2019-10-13 18:20:40'
updated: '2019-10-15 12:57:50'
tags: [openstack, linux]
permalink: /articles/2019/10/13/1570962040262.html
---
# [ controller node nova节点](https://docs.openstack.org/nova/rocky/install/controller-install-rdo.html)
## 数据库部署
```mysql
MariaDB [(none)]> CREATE DATABASE nova_api;
MariaDB [(none)]> CREATE DATABASE nova;
MariaDB [(none)]> CREATE DATABASE nova_cell0;
MariaDB [(none)]> CREATE DATABASE placement;
```
```
 GRANT ALL PRIVILEGES ON nova_api.* TO 'nova'@'localhost' \
  IDENTIFIED BY 'nova';
GRANT ALL PRIVILEGES ON nova_api.* TO 'nova'@'%' \
  IDENTIFIED BY 'nova';
GRANT ALL PRIVILEGES ON nova.* TO 'nova'@'localhost' \
  IDENTIFIED BY 'nova';
GRANT ALL PRIVILEGES ON nova.* TO 'nova'@'%' \
  IDENTIFIED BY 'nova';
 GRANT ALL PRIVILEGES ON nova_cell0.* TO 'nova'@'localhost' \
  IDENTIFIED BY 'nova';
 GRANT ALL PRIVILEGES ON nova_cell0.* TO 'nova'@'%' \
  IDENTIFIED BY 'nova';
  GRANT ALL PRIVILEGES ON placement.* TO 'placement'@'localhost' \
  IDENTIFIED BY 'placement';
  GRANT ALL PRIVILEGES ON placement.* TO 'placement'@'%' \
  IDENTIFIED BY 'placement';  
```
## 在keystone中注册nove服务用户以及凭证
```bash
[root@linux-node1 ~]# . admin-openrc 
[root@linux-node1 ~]#  openstack user create --domain default --password-prompt nova
User Password:
Repeat User Password:
+---------------------+----------------------------------+
| Field               | Value                            |
+---------------------+----------------------------------+
| domain_id           | default                          |
| enabled             | True                             |
| id                  | e305672ae61c4ee5b67f2cd2ed8c3d46 |
| name                | nova                             |
| options             | {}                               |
| password_expires_at | None                             |
+---------------------+----------------------------------+
[root@linux-node1 ~]# openstack role add --project service --user nova admin
```
* 创建nove服务
```bash
[root@linux-node1 ~]# openstack service create --name nova \
>   --description "OpenStack Compute" compute
+-------------+----------------------------------+
| Field       | Value                            |
+-------------+----------------------------------+
| description | OpenStack Compute                |
| enabled     | True                             |
| id          | c66049c8de0f4dda90158a02d758da4c |
| name        | nova                             |
| type        | compute                          |
+-------------+----------------------------------+
```
* 创建计算API服务endpoints：
```bash
[root@linux-node1 ~]#  openstack endpoint create --region RegionOne \
>   compute public http://10.200.51.100:8774/v2.1
+--------------+----------------------------------+
| Field        | Value                            |
+--------------+----------------------------------+
| enabled      | True                             |
| id           | a64fc9f5db3c4aa68d1d394882d00d82 |
| interface    | public                           |
| region       | RegionOne                        |
| region_id    | RegionOne                        |
| service_id   | c66049c8de0f4dda90158a02d758da4c |
| service_name | nova                             |
| service_type | compute                          |
| url          | http://10.200.51.100:8774/v2.1   |
+--------------+----------------------------------+
[root@linux-node1 ~]#    openstack endpoint create --region RegionOne \
>   compute internal http://10.200.51.100:8774/v2.1
+--------------+----------------------------------+
| Field        | Value                            |
+--------------+----------------------------------+
| enabled      | True                             |
| id           | 338ca0584e5942a09b02ac25ede0accb |
| interface    | internal                         |
| region       | RegionOne                        |
| region_id    | RegionOne                        |
| service_id   | c66049c8de0f4dda90158a02d758da4c |
| service_name | nova                             |
| service_type | compute                          |
| url          | http://10.200.51.100:8774/v2.1   |
+--------------+----------------------------------+
[root@linux-node1 ~]#   openstack endpoint create --region RegionOne \
>   compute admin http://10.200.51.100:8774/v2.1
+--------------+----------------------------------+
| Field        | Value                            |
+--------------+----------------------------------+
| enabled      | True                             |
| id           | 36c6e2b7ddb8403889d1d3ba6538d642 |
| interface    | admin                            |
| region       | RegionOne                        |
| region_id    | RegionOne                        |
| service_id   | c66049c8de0f4dda90158a02d758da4c |
| service_name | nova                             |
| service_type | compute                          |
| url          | http://10.200.51.100:8774/v2.1   |
+--------------+----------------------------------+
```
* 创建placement凭证
```bash
[root@linux-node1 ~]# openstack user create --domain default --password-prompt placement
User Password:
Repeat User Password:
+---------------------+----------------------------------+
| Field               | Value                            |
+---------------------+----------------------------------+
| domain_id           | default                          |
| enabled             | True                             |
| id                  | 3ac64afaf7f24f5e9d2f44ab5615a8ed |
| name                | placement                        |
| options             | {}                               |
| password_expires_at | None                             |
+---------------------+----------------------------------+
```

* 将Placement用户添加到具有管理角色的服务项目中：
```
 openstack role add --project service --user placement admin
```
* 在服务目录中创建Placement API条目
```bash
[root@linux-node1 ~]# openstack service create --name placement \
>   --description "Placement API" placement
+-------------+----------------------------------+
| Field       | Value                            |
+-------------+----------------------------------+
| description | Placement API                    |
| enabled     | True                             |
| id          | b421e5544f724ddd8e56c9b996a0563a |
| name        | placement                        |
| type        | placement                        |
+-------------+----------------------------------+
```
* 创建 Placement API service endpoints
```bash
[root@linux-node1 ~]#   openstack endpoint create --region RegionOne \
>   placement public http://10.200.51.100:8778
+--------------+----------------------------------+
| Field        | Value                            |
+--------------+----------------------------------+
| enabled      | True                             |
| id           | d84bfc96a9154bd584ff4a85b6d23cfc |
| interface    | public                           |
| region       | RegionOne                        |
| region_id    | RegionOne                        |
| service_id   | b421e5544f724ddd8e56c9b996a0563a |
| service_name | placement                        |
| service_type | placement                        |
| url          | http://10.200.51.100:8778        |
+--------------+----------------------------------+
[root@linux-node1 ~]#    openstack endpoint create --region RegionOne \
>   placement internal http://10.200.51.100:8778
+--------------+----------------------------------+
| Field        | Value                            |
+--------------+----------------------------------+
| enabled      | True                             |
| id           | 67f4a2d11aff4866be1a275d2a7711c3 |
| interface    | internal                         |
| region       | RegionOne                        |
| region_id    | RegionOne                        |
| service_id   | b421e5544f724ddd8e56c9b996a0563a |
| service_name | placement                        |
| service_type | placement                        |
| url          | http://10.200.51.100:8778        |
+--------------+----------------------------------+
[root@linux-node1 ~]#   openstack endpoint create --region RegionOne \
>   placement admin http://10.200.51.100:8778
+--------------+----------------------------------+
| Field        | Value                            |
+--------------+----------------------------------+
| enabled      | True                             |
| id           | 937b98177b0e48e8b197f8a830153b49 |
| interface    | admin                            |
| region       | RegionOne                        |
| region_id    | RegionOne                        |
| service_id   | b421e5544f724ddd8e56c9b996a0563a |
| service_name | placement                        |
| service_type | placement                        |
| url          | http://10.200.51.100:8778        |
+--------------+----------------------------------+
```
## 安装nove计算节点
```
yum install openstack-nova-api openstack-nova-conductor \
  openstack-nova-console openstack-nova-novncproxy \
  openstack-nova-scheduler openstack-nova-placement-api -y
```
### 编辑`/etc/nova/nova.conf`配置文件
* 修改连接database配置
```shell
[DEFAULT]
enabled_apis = osapi_compute,metadata
[api_database]
connection = mysql+pymysql://nova:nova@10.200.51.100/nova_api
[database]
connection = mysql+pymysql://nova:nova@10.200.51.100/nova
[placement_database]
connection = mysql+pymysql://placement:placement@10.200.51.100/placement
```
* 修改消息队列配置
```
[DEFAULT]
transport_url = rabbit://openstack:openstack@10.200.51.100
```
* 配置身份认证服务
```shell
[api]
auth_strategy = keystone
[keystone_authtoken]
auth_url = http://10.200.51.100:5000/v3
memcached_servers = 10.200.51.100:11211
auth_type = password
project_domain_name = Default
user_domain_name = Default
project_name = service
username = nova
password = 598941324
```
* 启用对网络服务的支持
```
my_ip = 10.200.51.100
use_neutron = true
firewall_driver = nova.virt.firewall.NoopFirewallDriver
```
* 配置VNC代理以使用控制器节点的管理接口IP地址
```
[vnc]
enabled = true
server_listen = 0.0.0.0
server_proxyclient_address = $my_ip
```
* 配置Image服务API的位置
```
[glance]
api_servers = http://10.200.51.100:9292
```
* 配置锁定路径
```
[oslo_concurrency]
lock_path = /var/lib/nova/tmp
```

* 配置Placement API
```
[placement]
region_name = RegionOne
project_domain_name = Default
project_name = service
auth_type = password
user_domain_name = Default
auth_url = http://10.200.51.100:5000/v3
username = placement
password = 598941324
```
### 配置HTTP 中/etc/httpd/conf.d/00-nova-placement-api.conf文件
* 配置添加到以下内容来启用对Placement API的访问 `/etc/httpd/conf.d/00-nova-placement-api.conf`：

```
<Directory /usr/bin>
   <IfVersion >= 2.4>
      Require all granted
   </IfVersion>
   <IfVersion < 2.4>
      Order allow,deny
      Allow from all
   </IfVersion>
</Directory>
```

```
systemctl  restart httpd.service 
```
### 数据库验证
* 同步数据库（`nova-api` 、`placement` databases:）
```
su -s /bin/sh -c "nova-manage api_db sync" nova
```
* 注册cell0数据库：

```
[root@linux-node1 ~]# su -s /bin/sh -c "nova-manage cell_v2 map_cell0" nova
```
* 创建cell1单元格：
```bash
[root@linux-node1 ~]# su -s /bin/sh -c "nova-manage cell_v2 create_cell --name=cell1 --verbose" nova
1f5b2d9e-b360-46e0-abfc-0491a7631098
```
* 填充新数据库
```
su -s /bin/sh -c "nova-manage db sync" nova
```
* 验证nova cell0和cell1是否正确注册：
```bash
[root@linux-node1 ~]# su -s /bin/sh -c "nova-manage cell_v2 list_cells" nova
+-------+--------------------------------------+---------------------------------------+----------------------------------------------------+----------+
|  名称 |                 UUID                 |             Transport URL             |                     数据库连接                     | Disabled |
+-------+--------------------------------------+---------------------------------------+----------------------------------------------------+----------+
| cell0 | 00000000-0000-0000-0000-000000000000 |                 none:/                | mysql+pymysql://nova:****@10.200.51.100/nova_cell0 |  False   |
| cell1 | 1f5b2d9e-b360-46e0-abfc-0491a7631098 | rabbit://openstack:****@10.200.51.100 |    mysql+pymysql://nova:****@10.200.51.100/nova    |  False   |
+-------+--------------------------------------+---------------------------------------+----------------------------------------------------+----------+
```
* 开机自启动

```
# systemctl enable openstack-nova-api.service \
  openstack-nova-consoleauth openstack-nova-scheduler.service \
  openstack-nova-conductor.service openstack-nova-novncproxy.service
# systemctl start openstack-nova-api.service \
  openstack-nova-consoleauth openstack-nova-scheduler.service \
  openstack-nova-conductor.service openstack-nova-novncproxy.service
```
# node计算节点安装
* 安装时nova时报错，提示：
（ 需要：qemu-kvm-rhev >= 2.10.0）
添加yum源文件
```bash
[root@linux-node2 ~]# cat /etc/yum.repos.d/CentOS-QEMU-EV.repo 
[centos-qemu-ev]
name=CentOS-$releasever - QEMU EV
baseurl=https://mirrors.aliyun.com/centos/7.7.1908/virt/x86_64/kvm-common/
gpgcheck=0
enabled=1
```
###  [安装nova计算节点](https://docs.openstack.org/nova/rocky/install/compute-install-rdo.html)
```
yum install openstack-nova-compute
```
* 配置/etc/nova/nova.conf

```
[DEFAULT]
enabled_apis = osapi_compute,metadata
```
* RabbitMQ配置
```
[DEFAULT]
transport_url = rabbit://openstack:openstack@10.200.51.100
```
* 标识服务访问配置
```
[api]
auth_strategy = keystone
```
```bash
[keystone_authtoken]
auth_url = http://10.200.51.100:5000/v3
memcached_servers = 10.200.51.100:11211
auth_type = password
project_domain_name = Default
user_domain_name = Default
project_name = service
username = nova
password = 598941324
```

* 配置网络服务支持
```bash
my_ip = 10.200.51.31
use_neutron = true
firewall_driver = nova.virt.firewall.NoopFirewallDriver
```
* 在[vnc]部分中，启用并配置远程控制台访问：
```bash
[vnc]
enabled = true
server_listen = 0.0.0.0
server_proxyclient_address = $my_ip
novncproxy_base_url = http://10.200.51.100:6080/vnc_auto.html
```
* 在[Glance]部分中，配置映像服务API的位置：
```
[glance]
api_servers = http://10.200.51.100:9292
```
* 在[oslo_concurrency]部分中，配置锁路径：
```
[oslo_concurrency]
lock_path = /var/lib/nova/tmp
```
* [placement]中配置
```bash
[placement]
region_name = RegionOne
project_domain_name = Default
project_name = service
auth_type = password
user_domain_name = Default
auth_url = http://10.200.51.100:5000/v3
username = placement
password = 598941324
```

* 确定您的计算节点是否支持虚拟机的硬件加速：
```
 egrep -c '(vmx|svm)' /proc/cpuinfo
```
如果此命令返回值大于1，则计算节点支持硬件加速，通常不需要其他配置。

如果此命令返回值`zero`，则您的计算节点不支持硬件加速，您必须配置`libvirt`为使用QEMU而不是KVM。

编辑文件中的`[libvirt]`部分，`/etc/nova/nova.conf`如下所示：
```
[libvirt]
virt_type = qemu
```

### 以下在控制节点配置

添加新计算节点时，必须在控制器节点上运行以注册这些新计算节点。或者，您可以在以下位置设置适当的间隔 ：`/etc/nova/nova.conf`
```
[scheduler]
discover_hosts_in_cells_interval = 300
```

```bash
[root@linux-node1 ~]# . admin-openrc 
[root@linux-node1 ~]# openstack compute service list --service nova-compute  
+----+--------------+-------------+------+---------+-------+----------------------------+  
| ID | Binary       | Host        | Zone | Status  | State | Updated At                 |  
+----+--------------+-------------+------+---------+-------+----------------------------+  
|  7 | nova-compute | linux-node2 | nova | enabled | up    | 2019-10-13T11:13:55.000000 |  
+----+--------------+-------------+------+---------+-------+----------------------------+
[root@linux-node1 ~]# su -s /bin/sh -c "nova-manage cell_v2 discover_hosts --verbose" nova
Found 2 cell mappings.
Getting computes from cell 'cell1': 1f5b2d9e-b360-46e0-abfc-0491a7631098
Checking host mapping for compute host 'linux-node2': 15edaaaf-d17b-4763-b920-d31c763da7de
Creating host mapping for compute host 'linux-node2': 15edaaaf-d17b-4763-b920-d31c763da7de
Found 1 unmapped computes in cell: 1f5b2d9e-b360-46e0-abfc-0491a7631098
Skipping cell0 since it does not contain hosts.
[root@linux-node1 ~]# 
```

* [验证操作](https://docs.openstack.org/nova/rocky/install/verify.html)
```bash
source admin-openstack.sh
#列出服务组件以验证每个进程的成功启动和注册：state为up 状态
openstack compute service list
# 列出Identity服务中的API端点以验证与Identity服务的连接
openstack catalog list
# 列出Image服务中的图像以验证与Image服务的连接：
openstack image list
# 检查单元格和放置API是否成功运行：
nova-status upgrade check
```

```bash
[root@linux-node1 ~]# openstack compute service list
+----+------------------+-------------+----------+---------+-------+----------------------------+
| ID | Binary           | Host        | Zone     | Status  | State | Updated At                 |
+----+------------------+-------------+----------+---------+-------+----------------------------+
|  3 | nova-consoleauth | linux-node1 | internal | enabled | up    | 2019-10-13T11:17:35.000000 |
|  4 | nova-scheduler   | linux-node1 | internal | enabled | up    | 2019-10-13T11:17:36.000000 |
|  5 | nova-conductor   | linux-node1 | internal | enabled | up    | 2019-10-13T11:17:29.000000 |
|  7 | nova-compute     | linux-node2 | nova     | enabled | up    | 2019-10-13T11:17:35.000000 |
+----+------------------+-------------+----------+---------+-------+----------------------------+
[root@linux-node1 ~]# openstack catalog list
+-----------+-----------+--------------------------------------------+
| Name      | Type      | Endpoints                                  |
+-----------+-----------+--------------------------------------------+
| keystone  | identity  | RegionOne                                  |
|           |           |   public: http://10.200.51.100:5000/v3     |
|           |           | RegionOne                                  |
|           |           |   internal: http://10.200.51.100:5000/v3   |
|           |           | RegionOne                                  |
|           |           |   admin: http://10.200.51.100:5000/v3      |
|           |           |                                            |
| placement | placement | RegionOne                                  |
|           |           |   internal: http://10.200.51.100:8778      |
|           |           | RegionOne                                  |
|           |           |   admin: http://10.200.51.100:8778         |
|           |           | RegionOne                                  |
|           |           |   public: http://10.200.51.100:8778        |
|           |           |                                            |
| glance    | image     | RegionOne                                  |
|           |           |   admin: http://10.200.51.100:9292         |
|           |           | RegionOne                                  |
|           |           |   public: http://10.200.51.100:9292        |
|           |           | RegionOne                                  |
|           |           |   internal: http://10.200.51.100:9292      |
|           |           |                                            |
| nova      | compute   | RegionOne                                  |
|           |           |   internal: http://10.200.51.100:8774/v2.1 |
|           |           | RegionOne                                  |
|           |           |   admin: http://10.200.51.100:8774/v2.1    |
|           |           | RegionOne                                  |
|           |           |   public: http://10.200.51.100:8774/v2.1   |
|           |           |                                            |
+-----------+-----------+--------------------------------------------+
[root@linux-node1 ~]# openstack image list
+--------------------------------------+--------+--------+
| ID                                   | Name   | Status |
+--------------------------------------+--------+--------+
| b700d8c9-518f-4e30-853b-a245339f41d3 | cirros | active |
+--------------------------------------+--------+--------+
[root@linux-node1 ~]# nova-status upgrade check
+-------------------------------+
| 升级检查结果                  |
+-------------------------------+
| 检查: Cells v2                |
| 结果: 成功                    |
| 详情: None                    |
+-------------------------------+
| 检查: Placement API           |
| 结果: 成功                    |
| 详情: None                    |
+-------------------------------+
| 检查: Resource Providers      |
| 结果: 成功                    |
| 详情: None                    |
+-------------------------------+
| 检查: Ironic Flavor Migration |
| 结果: 成功                    |
| 详情: None                    |
+-------------------------------+
| 检查: API Service Version     |
| 结果: 成功                    |
| 详情: None                    |
+-------------------------------+
| 检查: Request Spec Migration  |
| 结果: 成功                    |
| 详情: None                    |
+-------------------------------+
| 检查: Console Auths           |
| 结果: 成功                    |
| 详情: None                    |
+-------------------------------+
```
