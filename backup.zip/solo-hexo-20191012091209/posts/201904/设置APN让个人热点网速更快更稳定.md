title: 设置APN让个人热点网速更快更稳定
date: '2019-04-10 11:45:18'
updated: '2019-04-10 17:20:32'
tags: [APN]
permalink: /articles/2019/04/10/1554867918639.html
---
1. 连接到设备的WIFI浏览器打开192.168.8.1，开启移动数据和漫游数据，开启后返回主页
2. 设置--拨号--Profile管理--APN设置，【新增】APN设置框，名称随便写，用户名和密码空着，ip类型选择IPV4,接入点APN联通为:   unim2m.njmmapn  设置后重启路由器就可以了
![](http://pouu7al9q.bkt.clouddn.com/BB42C31A29E0B3D09905FDD0B3F12BE4.png) 