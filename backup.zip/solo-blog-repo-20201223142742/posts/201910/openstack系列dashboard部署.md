title: openstack系列-dashboard部署
date: '2019-10-15 16:40:03'
updated: '2019-10-31 20:20:21'
tags: [openstack, Linux]
permalink: /articles/2019/10/15/1571128802984.html
---


# [horizon节点安装](https://docs.openstack.org/horizon/rocky/install/)
```
 yum install openstack-dashboard
```
## 编辑/etc/openstack-dashboard/local_settings文件
* 将仪表板配置为在控制器节点上使用OpenStack服务：
```
OPENSTACK_HOST = "10.200.51.100"
```
* 允许主机访问仪表板：
```
ALLOWED_HOSTS = ['*', 'localhost']
```
* 配置memcached会话存储服务
```
SESSION_ENGINE = 'django.contrib.sessions.backends.cache'

CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.memcached.MemcachedCache',
        'LOCATION': '10.200.51.100:11211',
    },
}
```
* 启用标识API版本3：
```
OPENSTACK_KEYSTONE_URL = "http://%s:5000/v3" % OPENSTACK_HOST
```
* 启用对域的支持
```
OPENSTACK_KEYSTONE_MULTIDOMAIN_SUPPORT = True
```

* 配置API版本：OpenStack_API_版本

```
OPENSTACK_API_VERSIONS = {
    "identity": 3,
    "image": 2,
    "volume": 2,
}
```
* 将默认配置为通过仪表板创建的用户的默认域：
```
OPENSTACK_KEYSTONE_DEFAULT_DOMAIN = 'Default'
```
* 将用户配置为通过仪表板创建的用户的默认角色：
```
OPENSTACK_KEYSTONE_DEFAULT_ROLE = "myrole"
```
* 如果选择网络选项1，请禁用对第3层网络服务的支持：
```bash
OPENSTACK_NEUTRON_NETWORK = {
    'enable_router': False,
    'enable_quotas': False,
    'enable_ipv6': False,
    'enable_distributed_router': False,
    'enable_ha_router': False,
    'enable_fip_topology_check': False,
    #...
```
* 配置时区：
```
TIME_ZONE = "Asia/Shanghai"
```

* 如果不包括，请将以下行添加到/etc/httpd/conf.d/openstack-dashboard.conf。
```
WSGIApplicationGroup %{GLOBAL}
```

### 重启服务
```
 systemctl restart httpd.service memcached.service
```

# 验证web
浏览器输入：http://10.200.51.100/dashboard
![image.png](https://img.hacpai.com/file/2019/10/image-f54adfd5.png)

![image.png](https://img.hacpai.com/file/2019/10/image-3c9b6fee.png)





