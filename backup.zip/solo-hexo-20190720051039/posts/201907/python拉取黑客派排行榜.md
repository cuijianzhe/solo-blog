title: python拉取黑客派排行榜
date: '2019-07-18 19:31:48'
updated: '2019-07-19 09:23:29'
tags: [python]
permalink: /articles/2019/07/18/1563449508471.html
---
虽然没什么用，学习阶段，练手。

```
import requests
import re
html =  requests.get('https://hacpai.com/top/general').text
result = re.findall('class="fn-flex-1".*?aria-name="(.*?)".*?href="(.*?)".*?',html,flags=re.S)
#paihang_str = str(result)
for value in result:
    name, url = value
    tup1 = name.replace("/"," "),url
    tup2 = ' '.join(tup1)
    print(tup2)
    with open('paihangbang.txt','a',encoding='utf-8') as f:
        f.write(tup2)
```