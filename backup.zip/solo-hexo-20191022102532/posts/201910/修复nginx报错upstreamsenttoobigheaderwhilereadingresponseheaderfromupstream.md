title: 修复nginx报错："upstream sent too big header while reading response header from
  upstream"
date: '2019-10-20 20:27:34'
updated: '2019-10-20 23:37:50'
tags: [nginx, linux]
permalink: /articles/2019/10/20/1571574453990.html
---

> 近来几天发现访问博客端文章间歇性报出502，一开始以为是solo博客端的配置问题，纠正排查后发现不是博客后台设置的问题。后来查看nginx的日志。发现如下报错：
```
2019/10/20 20:05:09 [error] 8539#0: *67 no live upstreams while connecting to upstream, client: 111.194.50.93, server: cjzshilong.cn, request: "GET /sw.js HTTP/1.1", upstream: "http://localhost/sw.js", host: "www.cjzshilong.cn", referrer: "https://www.cjzshilong.cn/sw.js"
2019/10/20 20:08:53 [notice] 8638#0: signal process started
2019/10/20 20:09:11 [error] 8659#0: *2 upstream sent too big header while reading response header from upstream, client: 111.194.50.93, server: cjzshilong.cn, request: "GET /articles/2019/10/15/1571128802984.html?pjax=true HTTP/1.1", upstream: "http://127.0.0.1:8080/articles/2019/10/15/1571128802984.html?pjax=true", host: "www.cjzshilong.cn", referrer: "https://www.cjzshilong.cn/?utm_source=hacpai.com"
```

![image.png](https://img.hacpai.com/file/2019/10/image-7f8b6b0a.png)


通过参考各种网上资料，综合解决方法：
HTTP和HTTPS下的配置，增加

* 解决upstream sent too big header while reading response header from upstream
```
   proxy_buffer_size 128k;
   proxy_buffers  32 32k;
   proxy_busy_buffers_size 128k;
```
完整配置
```
location / {
   proxy_pass http://backend$request_uri;
   proxy_set_header  Host $host:$server_port;
   proxy_set_header Connection "Keep-Alive";
   proxy_set_header  X-Real-IP  $remote_addr;
   client_max_body_size  10m;
   proxy_buffer_size 128k;
   proxy_buffers  32 32k;
   proxy_busy_buffers_size 128k;
   }
```
**参考**[链接](https://www.jianshu.com/p/389f45d0e7a2)

