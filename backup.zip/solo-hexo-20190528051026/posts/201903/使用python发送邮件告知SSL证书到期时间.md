title: 使用python发送邮件告知SSL证书到期时间
date: '2019-03-16 11:39:16'
updated: '2019-05-22 15:35:00'
tags: [python]
permalink: /articles/2019/03/16/1552707556605.html
---
现在域名上面很多证书，需要一个强有力的工具去查看并且了解到期时间的状况然后告知你。
检测脚本下载地址：
[sslooker.kernel3.10.0.x8664.rar](https://img.hacpai.com/file/2019/05/sslooker.kernel3.10.0.x8664-8ad47f6b.rar)

使用方法：
```
$ /usr/bin/sslooker                       
please input host and port
# root @ blog in ~ [14:14:58] 
$ /usr/bin/sslooker www.cjzshilong.cn 443 
8261

```
注意事项：
1.获取证书有效期为**小时**  
2.**自签发证书**暂不支持检测


:cold_sweat: **废话就不多说了，直接上代码**  :cold_sweat:

```python
#!/bin/bash

dir=/tmp/yuming
data=`date +%Y-%m-%d`
script=/usr/bin/sslooker
yuming=`cat /tmp/yuming`
for i in ${yuming[*]}
     do
         time=`echo -e "$( $script $i 443 )"`
 if [ "$time" -lt  "48" ];
   then
    cat > /tmp/sendmail.py << ccc

#!/usr/bin/env python3
import os
import smtplib
from email.mime.text import MIMEText
from email.utils import formataddr

my_sender = '598941324@qq.com'
my_pass = 'mXXXXxxxxxxxdcc'     
my_user = '598941324@qq.com'

body = '''
时间：$data -----> 
Your SSL certificate on {name}   to expire  {time} hours
请检查相关域名SSL证书，并续费。
'''.format(name="$i",time="$time")

def mail():
    ret = True
    msg = MIMEText(body, 'html', 'utf-8')
    msg['From'] = formataddr(["Cuijianzhe", my_sender])
    msg['To'] = formataddr(["Cuijianzhe", my_user])
    msg['Subject'] = 'SSL check on cjzshilong.cn'
    server = smtplib.SMTP_SSL("smtp.qq.com", 465)
    server.login(my_sender, my_pass)
    server.sendmail(my_sender, [my_user, ], msg.as_string())
    server.quit()
    ret=False

    return ret
    ret = mail()
    if ret:
        print("邮件发送成功")
    else:
        print("邮件发送失败")
mail()
ccc
/usr/bin/python3  /tmp/sendmail.py

    fi
done
```

### 使用方法：
如果用的是QQ邮箱需要生成第三方邮箱授权码：
![shouquanma.png](https://img.hacpai.com/file/2019/03/shouquanma-e26a4b8e.png)

然后运行脚本

`# root @ blog in ~ [14:22:46] 
$ ./SSL_check.sh  
`
### 结果：
![SSL.png](https://cjz.cjzshilong.cn/SSL.png)





