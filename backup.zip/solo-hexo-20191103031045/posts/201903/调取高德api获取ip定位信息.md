title: 调取高德api获取ip定位信息
date: '2019-03-08 10:56:56'
updated: '2019-04-15 20:58:17'
tags: [API]
permalink: /articles/2019/03/08/1552013816021.html
---
![](https://img.hacpai.com/bing/20180530.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

我为什么记录这个呢，为了以后用到相关监控工具或者访问日志时可以调用这个api去查询访问者的地域信息
IP定位是一个简单的HTTP接口，根据用户输入的IP地址，能够快速的帮用户定位IP的所在位置。
使用API前您需先[申请Key](https://lbs.amap.com/dev/key)。若无高德地图API账号需要先申请账号。

第一步，申请”web服务 API”密钥（Key）；

第二步，拼接HTTP请求URL，第一步申请的Key需作为必填参数一同发送；

第三步，接收HTTP请求返回的数据（JSON或XML格式），解析数据。

如无特殊声明，接口的输入参数和输出数据编码全部统一为UTF-8。

###  IP定位

----
* **IP定位API服务地址：**

| URL | https://restapi.amap.com/v3/ip?parameters | 
| --- | --- | 
| 请求方式 |                    GET                               | 

parameters代表的参数包括必填参数和可选参数。所有参数均使用和号字符(&)进行分隔。下面的列表枚举了这些参数及其使用规则。

*  **请求参数**

| 参数名 | 含义 | 规则说明 | 是否必须 | 缺省值 |
| --- | --- | --- |
| key|请求服务权限标识  |用户在高德地图官网[申请Web服务API类型KEY](https://lbs.amap.com/dev/)  | 必填|
| ip| ip地址 |  需要搜索的IP地址（仅支持国内）若用户不填写IP，则取客户http之中的请求来进行定位 |可选 |
| sig |  签名| 选择数字签名认证的付费用户必填 |可选 |
|output| 返回格式 |  可选值：JSON,XML | 可选|

*    **返回结果参数说明**

| 名称含义 | 含义 | 规则说明 |
| --- | --- | --- |
|  status|返回结果状态值  |值为0或1,0表示失败；1表示成功  |
|info  |返回状态说明  | 返回状态说明，status为0时，info返回错误原因，否则返回“OK”。 |
|infocode| 状态码|返回状态说明,10000代表正确,详情参阅info状态表 |
| province|省份名称 |若为直辖市则显示直辖市名称；如果在局域网 IP网段内，则返回“局域网”；非法IP以及国外IP则返回空 |
|city |城市名称 |若为直辖市则显示直辖市名称；如果为局域网网段内IP或者非法IP或国外IP，则返回空 |
| adcode|城市的adcode编码 | |
| rectangle| 所在城市矩形区域范围| 所在城市范围的左下右上对标对|

接下来，
这是我的高德官网API key
![key.png](https://img.hacpai.com/file/2019/04/key-426f2c14.png)




* **通过GET的方式开始调用：**

```
[root@zabbix ~]# curl "https://restapi.amap.com/v3/ip?output=json&key=fc9ab3e41e05ebc633244a07a83e1b1f&ip=223.71.40.26"

{"status":"1","info":"OK","infocode":"10000","province":"北京市","city":"北京市","adcode":"110000","rectangle":"116.0119343,39.66127144;116.7829835,40.2164962"}
```

如图

![API.png](https://img.hacpai.com/file/2019/04/API-50d4f7f2.png)



** 哦也**:sweat_smile:   ……





