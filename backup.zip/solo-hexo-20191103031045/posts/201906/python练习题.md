title: python练习题
date: '2019-06-05 14:35:35'
updated: '2019-10-31 20:24:19'
tags: [Python]
permalink: /articles/2019/06/05/1559716535382.html
---

# 一、字符串、列表、元组、字典、集合练习
## 1.1 BMI计算输出
> BMI指数(Body Mass Index) 以称身体质量指数
    BMI值计算公式: BMI = 体重(公斤) / 身高的平方(米)
例如:
    一个人69公斤，身高是173公分
    BMI = 69 / 1.73**2 = 23.05
标准表:
    BMI < 18.5   体重过轻
    18.5 <= BMI < 24 体重正常
    BMI > 24  体重过重
要求: 输入身高的体重，打印出BMI的值并打印体重状况

```python
#!/bin/python3

Height = float(input('请输入身高(米)：'))
Weight = float(input('请输入体重(公斤)：'))
BMI =  Weight / Height **2
print('%.2f'%BMI)
if BMI < 18.5:
   print('您的体重过轻，BMI值为：%.2f' %BMI)
elif  BMI < 24:
   print('您的体重正常，BMI值为：%.2f'%BMI)
else:
   print('您的体重过重，BMI值为：%.2f'%BMI)
```
## 1.2：统计字符串类型
> 题目要求!任意输入一串字母加数字，统计出，整数出现的个数。（字母不限大小写！）
   例：`123abc456efg123asd88$#@`
>
   输出规范：

>   print(整数总共出现4次)

### 1.2.1 解决方法1：
```python
#!/usr/bin/python3
# @Time  : 2019/6/7 13:58
# @Author : cuijianzhe
# @File  : str.py
# @Software: PyCharm
#a = "123abc456efg123asd88$#@"
a = input("请输入你需要查询的字符串包含数字和字母:")
num_list = [i for i in a if i.isdigit()]
print("出现数字的次数为:{},分别为{}".format(len(num_list),num_list))
num_set = set(num_list)
print("去重后的数字整数个数为{},分别为{}:".format(len(num_set),num_set))
```

输出结果：
```
请输入你需要查询的字符串包含数字和字母:123abc456efg123asd88$#@
出现数字的次数为:11,分别为['1', '2', '3', '4', '5', '6', '1', '2', '3', '8', '8']
去重后的数字整数个数为7,分别为{'8', '4', '1', '6', '3', '5', '2'}
```
### 1.2.2 解决方法2：
```python
#!/usr/bin/python3
# @Time  : 2019/6/7 13:58
# @Author : cuijianzhe
# @File  : str.py
# @Software: PyCharm
#a = "123abc456efg123asd88$#@"
a = input('请输入一串包含数字和字母的字符串：')
dict_str = {"num":0,"letter":0,"other":0}

for item in a:
    if item.isdigit():
        dict_str["num"] = dict_str["num"] + 1
    elif item.isalpha():
        dict_str["letter"] = dict_str["letter"] + 1
    else:
        dict_str["other"] = dict_str["other"] + 1
print(" 字符串：{}\n 数字个数：{}\n 字母个数：{}\n 其他字符：{}".format(a,dict_str["num"],dict_str["letter"],dict_str["other"]))
`````
输出结果：
```
$ python3 /python_file/str.py        

请输入一串包含字母或者数字或者特殊字符的字符串:123abc456efg123asd88$#@
字符串:123abc456efg123asd88$#@
数字个数：11
字母个数：9
其他特殊字符个数：3
```
### 1.2.3 最佳字典统计法
```python
#!/bin/python3
str = 'abcsadfadsfgfegegegea'
dict = {}
for i in str:
    dict[i]=str.count(i)
print(dict)

```
输出：
`{'a': 4, 'b': 1, 'c': 1, 's': 2, 'd': 2, 'f': 3, 'g': 4, 'e': 4}
`
### 1.2.4 统计奇偶数字的和以及个数，元组返回
```python
'''
统计奇数和偶数
个数以及和
以元组方式返回
'''
num = [1,2,3,4,5,6,7,8,9,10]
sum = []
sum_1 = []
s = 0
g = 0
for i in num:
    if i % 2 == 0:
        s += i
        sum.append(i)
    else:
        g += i
        sum_1.append(i)

tup = (len(sum),s)
tup_1 = (len(sum_1),g)
print('现有数值中偶数的和为{},个数为{},奇数的和为{},个数为{}'.format(s,len(sum),g,len(sum_1)))
print(tup,tup_1)

```

# 二、编程第一步
## 2.1 裴波那契数列
```python
#!/bin/python3
# Fibonacci series: 斐波纳契数列
# 两个元素的总和确定了下一个数
a,b = 0, 1
while b < 1000:
    print(b,end=' ')
    a, b = b, a+b
```
输出结果：
```python
[root@cjz ~]# python3 shulie.py 

1 1 2 3 5 8 13 21 34 55 89 144 233 377 610 987 
```
## 2.2 韩信点兵
> 汉代名将韩信带1500名士兵打仗，战死四五百人，战后清点人数，3 人一排多出2人，5人一排，多出4人；7人一排，多出6人。韩信很快说出剩余人数：1049人。请问对吗？  
请用python验证：  
思路：定义变量，输出变量与3的余数，与5的余数，与7的余数

```python
#!/bin/python3
#验证韩信结果：
sum = 1500
a = 1049
if (sum-a)%3==2 and (sum-a)%5==4 and (sum-a)%7==6:
    print('韩信说得对')
else:
    print('韩信说的不对')
#战死四五百人，说明最大人数为1100，最少人数为1000.
for i in range(1000,1100):
    if(i % 3 ==2 and i % 5 ==3 and i % 7 ==6):
        print('剩余士兵人数应该为:',i ,'个人')
```

## 2.3 字符串统计判断

> 给你一个字符串例如：’abcsadfadsfgfegegegea’，经过计算返回一个字典，字典中包含每个元素当中的个数，结合if 判断，for 循环，完成本次代码！
 例如：‘abb’ --> {‘a’:1,’b’:2}

### 2.3.1 最佳代码：
```python
str = 'abcsadfadsfgfegegegea'

dict = {}
for i in str:
    dict[i]=str.count(i)
print(dict)
```
### 2.3.2 水
```python
#水代码：只符合结果，不符合题意。
a = list(input('请输入你要查询的字符串：'))

set_a = set(a)
list_set = list(set_a)
# print(list_set)
print('不重复的字符为：%s' % (list_set))
for i in list_set:
    print('输入的字符串中{}的个数为{}'.format(i, a.count(i)))

```
## 2.4 字符串统计
> 输入任意行文字，存于列表L中,当不输入任何容直接回车后结束输入
   1) 打印L列表中的内容
   2) 计算您共输入了几行内容
   3) 计算您共输入了多少个字符
### 2.4.1 解决方法1：

```python
a = 1
L = []
while a:
    b = str(input('输入任意行文字，回车结束：'))
    if  b.strip() == '':
        break
    else:
        L.append(b)
print('列表中的内容：{}\n一共输入{}行内容\n一共输入{}个字符'.format(L,len(L),len(''.join(L))))

```

### 2.4.2 解决方法2：
```python
L = []
while 1 :
    s =  input('请输入任意字符：')
    if bool(s):
        L.append(s)
    else:
        break
print(L)
```
## 2.5 循环（while、for）
> 输入一个整数（代表树干的高度)
     打印出如下一棵树
     输入: 2
     打印: 
      *
   \***
      *
      *
     输入:3
       *
    \***
  \*****
       *
       *
       *

### 2.5.1 解决方法1：
  
```python
n = int(input('输入一个正整数：'))

count = 1
while(n-count>=0):
    print(' '*(n-count) + '*'*(count*2-1) + ' '*(n-count))
    count = count + 1
count2 = 1
while(n-count2>=0):
    print(' '*(n-1) + '*'*(1*2-1) + ' '*(n-1))
    count2 = count2 + 1

```
### 2.5.2  解决方法2：

```python
n = input("请输入一个整数：")

n = int(n)
for j in range(1,n+1):
    print(' '*(n-j),'*'*(j*2-1),' '*(n-j),end='\n')
for j in range(1,n+1):
    print(' '*(n-1),'*',end='\n')
```
### 2.5.3 拓展：打印金字塔树干：
```python
tall_num =int(input("请输入高度(金字塔打印)："))

for i in range (tall_num + 1):
    print(" "*(tall_num - i),end=" ")
    print(" *"*(i+1))
for i in range (tall_num):
    print(' '*(tall_num+2)+'*')
```
### 2.5.4 利用while或for打印100以内奇数的和
```python
i = 0
b = 0
for i in range(100):
    if i % 2 != 0:
        b = b + i
    i += 1
print(b)

```

```python
i = 0
sum = 0
while i <= 100:
    if i % 2 != 0:
        sum = sum + i
    i += 1
print(sum)
```
### 2.5.5乘法表

```python
for i in range(1,10):

    for j in range(1,i+1):
        print('%d x %d = %d\t'%(j,i,i*j),end='')
    print()
```
### 2.5.6 输入数字找规律
> 输入n = 3
 输出：
 1
 3 * 2
 4* 5 * 6

```python
n = int(input('请输入你要输入的数字：'))

n_list = []
row = None
num = 0
for i in range(1,n+1):
    for t in range(1,i+1):
        row = t
        num += 1
        n_list.append(str(num))
    if row %2 == 0:
        print("*".join(reversed(n_list)))
    else:
        print("*".join(n_list))
    n_list = []
```
## 2.6 判断是否为质数（素数）
> 写一个程序，任意输入一个整数，判断这个数是否是素数(prime)
    素数(也叫质数), 是只能被1和自身整除的正整数:
      如: 2 3 5 7 11 等
    提示:
      用排除法: 当判断x是否是素数是，只要让x分别除以:
        2, 3, 4, 5, .... x-1, 只要整除了，那x不是素数，否则x是素数

```python
num = int(input('请输入一个正整数：'))
if num<2:
    print('请输入大于2的正整数')
else:
    for i in range(2,num):
        if (num % i) == 0:
            print(num,'不是质数')
            print(i,"乘以",num//i,"是",num)
            break
        else:
            print(num,'这个数是质数')

```

### 2.6.1 统计范围内的质数：
```python
for n in range(2,10):

    for x in range(2,n):
        if n % x == 0:
            print(n,'等于',x,'*',n//x)
            break
    else:
        print(n,'是质数')
```

# 2.7 python找出一个数的最大质因数（欧拉计划）
思路：
1. 定义一个空列表：
2、将数字定义为变量，在while条件下执行，再将整除的数做一个for循环，范围2~(此数+1)。
3、如果这个数能整除，添加到列表中，然后将整除的数再循环，直到不能整除break。
4、使用max打印列表中最大质因数

```python
my_list = []

my_num = 13195
while my_num != 1:
    for i in range(2,int(my_num)+1):
        if my_num % i == 0:
            my_list.append(i)
            my_num = my_num / i
            break
print(max(my_list))
print(my_list)
```

# 2.8 查找列表索引
> Given an array of integers, return indices of the two numbers such that they add up to a specific target.
You may assume that each input would have exactly one solution, and you may not use the same element twice.
Example:
Given nums = [2, 7, 11, 15], target = 9,
Because nums[0] + nums[1] = 2 + 7 = 9,
return [0, 1].

```python
my_list = [2,7,11,15,10,6]
last_list = []
sum = 25
for i in my_list:
    for j in my_list:
        if i + j == sum:
            last_list.append(i)
            break
print('和值为{}的数的索引值为{},{}'.format(sum,my_list.index(int(last_list[0])),my_list.index(int(last_list[1]))))

```

# 三、函数的使用：
## 3.2 函数结合while循环：

```python
def city_country(city_name,city_guojia):

    city = city_name + ' ' + city_guojia
    return city.title()
while True:
    print("Please tell me your city :")
    print("('Enter 'q' any time to quit')")
    my_city = input("your city:")
    if my_city == 'q':
        break
    my_guojia = input('your country:')
    if my_guojia == 'q':
        break
    my_country = city_country(my_guojia,my_city)
    print("\nHello," + my_country + "!")
```

## 3.3 仿银行系统(加校验、提醒交互)
### 3.3.1 心中解法

```python
import random
Random = random.randrange(1,9999)
Random1 = random.randrange(1,9999)
names = ['cuijianzhe','test','gun']
user = input('请您的用户名:')

def savemoney():
    global user
    print('你好{},您当前余额为{}'.format(user,Random))
    before_money = input('请输入您要充值的钱数:')
    print('您存款{}元，现在余额为{}'.format(before_money,Random + int(before_money)))
def takemoney():
    global user
    print('你好{},您当前余额为{}'.format(user,Random1))
    later_money = input('您取款多少元？')
    if int(later_money) > Random:
        print('对不起，你的余额不足……')
    else:
        print('您取款{}元，现在余额为{}'.format(later_money, Random - int(later_money)))

if user in names:
    print('你好，存钱还是取钱')
    choose = input("如果取钱请按't',如果存钱请按's',退出请按'q'")
    if choose == 's':
        savemoney()
    if choose == 't':
        takemoney()
```

### 3.3.2 标准解法

```python
import time

# 1. 添加一个余额变动提醒短消息功能
def messend_send(fn):
    def fx(name, x):
        print("发送消息:", name, '来银行办理业务...')
        time.sleep(2)
        fn(name, x)
        print("发送消息:", name, '办了', x,
'元的业务...')
    return fx

# 2. 加一个权限验证功能的装饰器
def bank_check(fn):
    def fx(name, x):
        print("正在检查权限.....")
        time.sleep(2)
        print('%s权限通过' % name)
        time.sleep(2)
        if True:
            fn(name, x)

    return fx


@bank_check
@messend_send
def savemoney(name, x):
    print(name, "存钱", x, '元')


@messend_send
def withdraw(name, x):
    print(name, '取钱', x, '元')


# 以下是调用者小张写的程序
savemoney('cuijianzhe', 666)
savemoney('斌斌', 1500)
withdraw('东方', 3900)
```

## 3.4 判断一个对象是否可迭代：

```python
def iterable(index):
    try:
        iter(index)
        return True
    except TypeError:
        return False

indexs = [
    1234,
    [1,2,3,4],
    {1,2,34}
]

for index in indexs:
    print('{} is iterable? {}'.format(index,iterable(index)))
```
# 四、 字符处理
## 4.1 MD5加密处理
```python
import hashlib
str = "123"
md5 = hashlib.md5()
md5.update(str.encode())
print(md5.hexdigest())
```
