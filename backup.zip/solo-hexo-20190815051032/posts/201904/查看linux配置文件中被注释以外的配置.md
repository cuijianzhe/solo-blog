title: 查看linux配置文件中被注释以外的配置
date: '2019-04-06 18:30:33'
updated: '2019-05-02 11:12:39'
tags: [linux]
permalink: /articles/2019/04/06/1554546633835.html
---
![](https://img.hacpai.com/bing/20171221.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


`[root@inside ~]# grep  -v "^#" /etc/zabbix/zabbix_agentd.conf`

`[root@inside ~]# grep "^[a-Z]" /etc/zabbix/zabbix_agentd.conf `
以上方式不会去除空格，只会把没有注释掉的打印出来。

```
 grep -v "^$\|^#" /etc/ssh/sshd_config 
```

```
grep -E -v "^$|^#" /etc/ssh/sshd_config
```

```
 egrep -v "^$|^#" /etc/ssh/sshd_config 
```