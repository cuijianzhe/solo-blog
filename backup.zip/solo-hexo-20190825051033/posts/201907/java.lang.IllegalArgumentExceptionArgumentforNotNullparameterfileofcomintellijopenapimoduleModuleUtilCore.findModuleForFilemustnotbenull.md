title: 'java.lang.IllegalArgumentException: Argument for @NotNull parameter ''file''
  of com/intellij/openapi/module/ModuleUtilCore.findModuleForFile must not be null'
date: '2019-07-26 15:41:21'
updated: '2019-07-26 15:41:21'
tags: [IDEA]
permalink: /articles/2019/07/26/1564126881261.html
---
![](https://img.hacpai.com/bing/20180511.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 事件起因
`用idea社区版的smart Tomcat 打开一个eclipse的javaweb项目`

### 问题根本原因
`JAVA SDK版本没选对`

### 解决办法
`用idea从新导入eclipse项目`
1. File --> open
2. 选择.project文件打开
3. 根据提示修改SDK信息