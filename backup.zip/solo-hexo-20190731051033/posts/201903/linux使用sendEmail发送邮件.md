title: linux使用sendEmail发送邮件
date: '2019-03-16 09:59:44'
updated: '2019-04-15 21:02:06'
tags: [linux]
permalink: /articles/2019/03/16/1552701584725.html
---
![](https://img.hacpai.com/bing/20181220.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### sendEmail官方下载地址
[http://caspian.dotconf.net/menu/Software/SendEmail/](https://)

官网最新版本1.5.6，可以直接下载上传到服务器，也可用wget方式

我生产环境是采用定时任务触发sendEmail并且发送每天的日志信息到邮箱进行保存。
![crontab.png](https://img.hacpai.com/file/2019/03/crontab-40bd3069.png)



![sendEmail.png](https://img.hacpai.com/file/2019/03/sendEmail-2f2f3866.png)

```
[root@localhost ~]# wget http://caspian.dotconf.net/menu/Software/SendEmail/sendEmail-v1.56.tar.gz
[root@localhost ~]# tar zf sendEmail-v1.56.tar.gz -C /usr/local/
[root@localhost ~]# cd /usr/local/sendEmail-v1.56/

[root@localhost sendEmail-v1.56]# ll
总用量 116
-rw-r--r--. 1 root root 13329 9月  30 2009 CHANGELOG
-rw-r--r--. 1 root root  7949 9月  30 2009 README
-rw-r--r--. 1 root root  4701 9月  30 2009 README-BR.txt
-rwxr-xr-x. 1 root root 80213 9月  30 2009 sendEmail     \\此脚本是发送邮件的文件
lrwxrwxrwx. 1 root root     9 9月  30 2009 sendEmail.pl -> sendEmail
-rw-r--r--. 1 root root  1229 9月  30 2009 TODO
```
可以自定义脚本路径
`[root@localhost sendEmail-v1.56]# mv sendEmail  /usr/local/bin/`

### 发送邮件：
```
   /usr/local/bin/sendEmail -f jianzhecui@163.com -t 598941324@qq.com \
   -s smtp.163.com -u "我是邮件主题" -o message-content-type=html \
    -o message-charset=utf8 -xu jianzhecui@163.com -xp 123456 -m "我是邮件内容"
```

命令说明：

```
/usr/local/bin/sendEmail 　　　命令主程序

-f yxylinux@163.com  　　　　　发件人邮箱
-s smtp.163.com       　　　　　发件人邮箱的smtp服务器
-u "我是邮件主题"     　　　　　　邮件的标题
-o message-content-type=html   邮件内容的格式,html表示它是html格式
-o message-charset=utf8        邮件内容编码
-xu yxylinux@163.com          发件人邮箱的用户名
-xp 123456               　　发件人邮箱密码
-m "我是邮件内容"        　　邮件的具体内容
```

### 测试发送邮件代码：
![sendEmail1.png](https://img.hacpai.com/file/2019/03/sendEmail1-ecf727f5.png)


```
[root@zabbix ~]# /data/sendEmail/sendEmail -f cuijianzhe@limikeji.com -t "cuijianzhe@limikeji.com" -s smtp.exmail.qq.com -u "loganalyzer 每日图片测试" -o message-charset=utf-8 -xu cuijianzhe@limikeji.com -xp 12345678 -m "附件为测试图片，请查收！" -a /var/www/html/images/backup.png 

Apr 15 21:01:02 zabbix sendEmail[31464]: Email was sent successfully!
```
发送成功会有successfully……

查收邮件：
![sendEmail2.png](https://img.hacpai.com/file/2019/03/sendEmail2-4f283eb1.png)



### sendEmail使用命令帮助：

```bash
[root@localhost ~]# /usr/local/bin/sendEmail --help


sendEmail-1.56 by Brandon Zehm <caspian@dotconf.net>

Synopsis:  sendEmail -f ADDRESS [options]

  Required:
    -f ADDRESS                from (sender) email address
    * At least one recipient required via -t, -cc, or -bcc
    * Message body required via -m, STDIN, or -o message-file=FILE

  Common:
    -t ADDRESS [ADDR ...]     to email address(es)
    -u SUBJECT                message subject
    -m MESSAGE                message body
    -s SERVER[:PORT]          smtp mail relay, default is localhost:25

  Optional:
    -a   FILE [FILE ...]      file attachment(s)
    -cc  ADDRESS [ADDR ...]   cc  email address(es)
    -bcc ADDRESS [ADDR ...]   bcc email address(es)
    -xu  USERNAME             username for SMTP authentication
    -xp  PASSWORD             password for SMTP authentication

  Paranormal:
    -b BINDADDR[:PORT]        local host bind address
    -l LOGFILE                log to the specified file
    -v                        verbosity, use multiple times for greater effect
    -q                        be quiet (i.e. no STDOUT output)
    -o NAME=VALUE             advanced options, for details try: --help misc
        -o message-content-type=<auto|text|html>
        -o message-file=FILE         -o message-format=raw
        -o message-header=HEADER     -o message-charset=CHARSET
        -o reply-to=ADDRESS          -o timeout=SECONDS
        -o username=USERNAME         -o password=PASSWORD
        -o tls=<auto|yes|no>         -o fqdn=FQDN


  Help:
    --help                    the helpful overview you're reading now
    --help addressing         explain addressing and related options
    --help message            explain message body input and related options
    --help networking         explain -s, -b, etc
    --help output             explain logging and other output options
    --help misc               explain -o options, TLS, SMTP auth, and more

```

