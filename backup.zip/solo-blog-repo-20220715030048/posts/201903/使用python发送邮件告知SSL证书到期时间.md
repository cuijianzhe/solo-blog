title: 使用python发送邮件告知SSL证书到期时间
date: '2019-03-16 11:39:16'
updated: '2020-05-11 15:56:24'
tags: [Python]
permalink: /articles/2019/03/16/1552707556605.html
---
现在域名上面很多证书，需要一个强有力的工具去查看并且了解到期时间的状况然后告知你。
检测脚本下载地址：
[sslooker.kernel3.10.0.x8664.rar](https://img.hacpai.com/file/2019/05/sslooker.kernel3.10.0.x8664-8ad47f6b.rar)

使用方法：

```bash
#!/bin/bash

dir=/tmp/yuming
data=`date +%Y-%m-%d`
script=/usr/bin/sslooker
yuming=`cat /tmp/yuming`

for i in ${yuming[*]}
do
   hours=`echo -e "$( $script $i 443 )"`
   days=`echo "$hours/24"|bc`

   if [ "$days" -lt  "3" ];
   then
   cat > /tmp/sendmail.py << ccc

#!/usr/bin/env python3
import os
import smtplib
from email.mime.text import MIMEText
from email.utils import formataddr

my_sender = '598941324@qq.com'
my_pass = 'mypsdfwlwbkojrqbdcc'
my_user = '598941324@qq.com'

body = '''
时间：$data :
Your SSL certificate on {name} to expire  {hours} hours
<请检查相关域名SSL证书， $days 天后到期，请注意！>。
'''.format(name="$i",hours="$hours")

def mail():
    ret = True
    msg = MIMEText(body, 'html', 'utf-8')
    msg['From'] = formataddr(["Cuijianzhe", my_sender])
    msg['To'] = formataddr(["Cuijianzhe", my_user])
    msg['Subject'] = 'SSL check on cjzshilong.cn'
    server = smtplib.SMTP_SSL("smtp.qq.com", 465)
    server.login(my_sender, my_pass)
    server.sendmail(my_sender, [my_user, ], msg.as_string())
    server.quit()
    ret=False

    return ret
    ret = mail()
    if ret:
        print("邮件发送成功")
    else:
        print("邮件发送失败")
mail()
ccc
/usr/bin/python3 /tmp/sendmail.py

    fi
done
```

### 使用方法：

如果用的是QQ邮箱需要生成第三方邮箱授权码：
![shouquanma.png](https://img.hacpai.com/file/2019/03/shouquanma-e26a4b8e.png)

然后运行脚本

`# root @ blog in ~ [14:22:46]  $ ./SSL_check.sh   `

### 结果：

![SSL.png](https://cjz.cjzshilong.cn/yuming_check.png)

注：腾讯QQ邮箱服务器：smtp.qq.com
腾讯企业邮服务器：**smtp.exmail.qq.com(使用SSL，端口号465)**



## **扩展**

邮箱添加附件并且发送图片



```python
import requests
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.utils import formataddr
from email import encoders
def _email():
    try:
        my_sender = '598941324@qq.com'
        my_pass = 'mypassword'
        my_user = ["xxx@163.com" ,]
        msg = MIMEMultipart()
        msg['From'] = formataddr(["爱你的哲哥", my_sender])
        msg['To'] = ','.join(my_user)
        msg['Subject'] = '滴！打卡，爱你的一天'
        msg_text = MIMEText('text', 'plain', 'utf-8')
        mime = MIMEBase('image', 'jpg', filename='love.jpg')
        mime.add_header('Content-Disposition', 'attachment', filename='love.jpg')
        mime.add_header('Content-ID', '<0>')
        mime.add_header('X-Attachment-Id', '0')
        # 把附件的内容读进来:
        lovePhotoSrc = 'https://file.loxxwng.cn/pictures_file/limi.png'
        req = requests.get(lovePhotoSrc)
        mime.set_payload(req.content)
        # 用Base64编码:
        encoders.encode_base64(mime)

        # 将邮件文本对象和邮件图片对象添加到邮件对象
        msg.attach(msg_text)
        msg.attach(mime)

        '''
        # 构建邮件图片对象
        # 设置附件的MIME和文件名，这里是jpg类型:
        mime = MIMEBase('image', 'jpg', filename='love.jpg')
        # 加上必要的头信息:
        mime.add_header('Content-Disposition', 'attachment', filename='love.jpg')
        mime.add_header('Content-ID', '<0>')
        mime.add_header('X-Attachment-Id', '0')
        # 把附件的内容读进来:
        req = requests.get(lovePhotoSrc)
        mime.set_payload(req.content)
        # 用Base64编码:
        encoders.encode_base64(mime)

        # 将邮件文本对象和邮件图片对象添加到邮件对象
        msg.attach(msg_text)
        msg.attach(mime)

        '''
        server = smtplib.SMTP_SSL("smtp.qq.com", 465)
        server.login(my_sender, my_pass)
        server.sendmail(my_sender, msg['To'].split(','), msg.as_string())
        server.quit()
    except Exception as err:
        print('发送失败!', 'error: {}'.format(err))
_email()
```
