title: python练习题
date: '2019-06-05 14:35:35'
updated: '2019-06-11 16:20:04'
tags: [python]
permalink: /articles/2019/06/05/1559716535382.html
---

# 一、字符串、列表、元组、字典、集合练习
## 1.1 BMI计算输出
> BMI指数(Body Mass Index) 以称身体质量指数
    BMI值计算公式: BMI = 体重(公斤) / 身高的平方(米)
例如:
    一个人69公斤，身高是173公分
    BMI = 69 / 1.73**2 = 23.05
标准表:
    BMI < 18.5   体重过轻
    18.5 <= BMI < 24 体重正常
    BMI > 24  体重过重
要求: 输入身高的体重，打印出BMI的值并打印体重状况

```python
#!/bin/python3

Height = float(input('请输入身高(米)：'))
Weight = float(input('请输入体重(公斤)：'))
BMI =  Weight / Height **2
print('%.2f'%BMI)
if BMI < 18.5:
   print('您的体重过轻，BMI值为：%.2f' %BMI)
elif  BMI < 24:
   print('您的体重正常，BMI值为：%.2f'%BMI)
else:
   print('您的体重过重，BMI值为：%.2f'%BMI)
```
## 1.2：统计字符串类型
> 题目要求!任意输入一串字母加数字，统计出，整数出现的个数。（字母不限大小写！）
   例：`123abc456efg123asd88$#@`
>   输出规范：
>   print(整数总共出现4次)

### 1.2.1 解决方法1：
```
#!/usr/bin/python3
# @Time  : 2019/6/7 13:58
# @Author : cuijianzhe
# @File  : str.py
# @Software: PyCharm
#a = "123abc456efg123asd88$#@"
a = input("请输入你需要查询的字符串包含数字和字母:")
num_list = [i for i in a if i.isdigit()]
print("出现数字的次数为:{},分别为{}".format(len(num_list),num_list))
num_set = set(num_list)
print("去重后的数字整数个数为{},分别为{}:".format(len(num_set),num_set))
```

输出结果：
```
请输入你需要查询的字符串包含数字和字母:123abc456efg123asd88$#@
出现数字的次数为:11,分别为['1', '2', '3', '4', '5', '6', '1', '2', '3', '8', '8']
去重后的数字整数个数为7,分别为{'8', '4', '1', '6', '3', '5', '2'}
```
### 1.2.2 解决方法2：
```python
#!/usr/bin/python3
# @Time  : 2019/6/7 13:58
# @Author : cuijianzhe
# @File  : str.py
# @Software: PyCharm
#a = "123abc456efg123asd88$#@"
a = input('请输入一串包含数字和字母的字符串：')
dict_str = {"num":0,"letter":0,"other":0}

for item in a:
    if item.isdigit():
        dict_str["num"] = dict_str["num"] + 1
    elif item.isalpha():
        dict_str["letter"] = dict_str["letter"] + 1
    else:
        dict_str["other"] = dict_str["other"] + 1
print(" 字符串：{}\n 数字个数：{}\n 字母个数：{}\n 其他字符：{}".format(a,dict_str["num"],dict_str["letter"],dict_str["other"]))
`````
输出结果：
```
$ python3 /python_file/str.py        

请输入一串包含字母或者数字或者特殊字符的字符串:123abc456efg123asd88$#@
字符串:123abc456efg123asd88$#@
数字个数：11
字母个数：9
其他特殊字符个数：3
```
# 二、编程第一步
## 2.1 裴波那契数列
```python
#!/bin/python3
# Fibonacci series: 斐波纳契数列
# 两个元素的总和确定了下一个数
a,b = 0, 1
while b < 1000:
    print(b,end=' ')
    a, b = b, a+b
```
输出结果：
```python
[root@cjz ~]# python3 shulie.py 

1 1 2 3 5 8 13 21 34 55 89 144 233 377 610 987 
```
## 2.2 韩信点兵
> 汉代名将韩信带1500名士兵打仗，战死四五百人，战后清点人数，3 人一排多出2人，5人一排，多出4人；7人一排，多出6人。韩信很快说出剩余人数：1049人。请问对吗？  
请用python验证：  
思路：定义变量，输出变量与3的余数，与5的余数，与7的余数

```
#!/bin/python3
#验证韩信结果：
sum = 1500
a = 1049
if (sum-a)%3==2 and (sum-a)%5==4 and (sum-a)%7==6:
    print('韩信说得对')
else:
    print('韩信说的不对')
#战死四五百人，说明最大人数为1100，最少人数为1000.
for i in range(1000,1100):
    if(i % 3 ==2 and i % 5 ==3 and i % 7 ==6):
        print('剩余士兵人数应该为:',i ,'个人')
```