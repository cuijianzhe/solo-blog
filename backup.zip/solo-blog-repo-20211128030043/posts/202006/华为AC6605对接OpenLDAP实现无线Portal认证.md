title: 华为AC6605对接OpenLDAP实现无线Portal认证
date: '2020-06-30 15:38:03'
updated: '2020-07-25 19:39:23'
tags: [Openldap, 无线认证]
permalink: /articles/2020/06/30/1593502682903.html
---
## AAA认证

```
#
aaa
 authentication-scheme ldap
  authentication-mode ldap
 authorization-scheme ldap
  authorization-mode ldap
#
```

## 配置LDAP服务器模板，并在模板内配置服务器的IP地址、端口号、Base DN以及管理员的区别名和管理员密码。

```
#
ldap-server template limi
 ldap-server authentication 192.168.51.207 389
 ldap-server authentication manager cn=root,dc=limikeji,dc=com %^%#~&j@#$7V;Ol|(nWg;.9/po,KEh+Cp'R]L3EuC{DX%^%#
 undo ldap-server authentication base-dn dc=my-domain,dc=com
 ldap-server authentication base-dn dc=limikeji,dc=com
 ldap-server server-type open-ldap
 ldap-server group-filter ou
 ldap-server user-filter uid
 undo ldap-server authentication manager-with-base-dn enable
#
```

### 配置认证模板

```
authentication-profile name ldap
 portal-access-profile ldap
 free-rule-template ldap
 authentication-scheme ldap
 ldap-server limi
#
```

### 检测ldap用户认证是否成功

```
[AC6605-ldap-limi]test-aaa cuijianzhe 598941324 ldap-template limi 
Info: Server detection succeeded.
```

## WLAN业务参数

```
#
wlan
 security-profile name limi-enzd
 ssid-profile name limi-enzd
  ssid limi-enzd
  max-sta-number 25                 
 vap-profile name limi-enzd
  service-vlan vlan-id 62
  ssid-profile limi-enzd
  security-profile limi-enzd
  authentication-profile ldap
```

## portal认证参数

```
#
portal local-server ip 10.200.42.1
portal local-server authentication-method pap
portal local-server background-image load flash:/header_logo.png
portal local-server terminal-type phone logo load flash:/header_logo.png
portal local-server https ssl-policy default_policy port 20000
portal local-server default-language chinese
#
```

### 创建Portal接入模板“ldap”，并配置其使用内置Portal服务器

```
#
portal-access-profile name ldap
 portal local-server enable
#
```

### 配置免认证规则模板

```
#
free-rule-template name ldap
free-rule 1 destination ip 221.179.155.161 mask 255.255.255.255
free-rule 2 destination ip 221.179.155.177 mask 255.255.255.255
free-rule 3 destination ip 10.200.50.209 mask 255.255.255.255
free-rule 4 destination ip 223.5.5.5 mask 255.255.255.255
free-rule 5 destination ip 114.114.114.114 mask 255.255.255.255
free-rule 6 destination ip 10.200.250.5 mask 255.255.255.255
free-rule 7 destination ip 10.200.42.1 mask 255.255.255.255
free-rule 8 destination ip 10.200.62.254 mask 255.255.255.255
#
```

