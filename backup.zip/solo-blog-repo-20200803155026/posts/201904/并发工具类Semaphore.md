title: 并发工具类 ---Semaphore
date: '2019-04-15 16:48:34'
updated: '2020-07-31 16:38:13'
tags: [进阶之路]
permalink: /articles/2019/04/15/1555318114318.html
---
![](https://img.hacpai.com/bing/20180701.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

![票.jpg](https://img.hacpai.com/file/2019/04/票-90304765.jpg)

### 举例示意

`北京开往邯郸的火车K7761开始售票，在9号站台验票进站，进站口只有三个，许许多多的乘客排成长队验票进站。 `
`那么此时三个进站口就是有限的公共资源，乘客们就是线程。 `
`Semaphore信号量是用来控制同时访问特定资源的线程数量，它通过协调各个线程，以保证合理的使用公共资源。`

```java

package com.jianwei;

import java.util.concurrent.Semaphore;

public class 上传思路 {
	public static void main(String[] args) throws Exception{

		SemaphoreService service = new SemaphoreService();
		for (int i = 0; i < 60; i++) {
			MyThread t = new MyThread("thread" + (i + 1), service);
		t.start();// 这里使用 t.run() 也可以运行，但是不是并发执行了
		}
	}
}

```

```java
package com.jianwei;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.Semaphore;

public class SemaphoreService {

    private static SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

    private Semaphore semaphore = new Semaphore(5);// 同步关键类，构造方法传入的数字是多少，则同一个时刻，只运行多少个进程同时运行制定代码

    public void doSomething() {
        try {
            /**
             * 在 semaphore.acquire() 和 semaphore.release()之间的代码，同一时刻只允许制定个数的线程进入，
             * 因为semaphore的构造方法是1，则同一时刻只允许一个线程进入，其他线程只能等待。
             * */
            semaphore.acquire();
            System.out.println(Thread.currentThread().getName() + ":doSomething start-" + getFormatTimeStr());
            Thread.sleep(10000);
            System.out.println(Thread.currentThread().getName() + ":doSomething end-" + getFormatTimeStr());
            semaphore.release();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static String getFormatTimeStr() {
        return sf.format(new Date());
    }
}
```

```java
package com.jianwei;

public class MyThread extends Thread {
    private SemaphoreService service;

    public MyThread(String name, SemaphoreService service) {
        super();
        this.setName(name);
        this.service = service;
    }

    @Override
    public void run() {
        this.service.doSomething();
    }
}
```


#### 在项目中的使用方法,每有一个请求,启动一个线程.然后去访问有信号量设置的这个service类或者serviceimpl类

```java
	ExecutorService cachedThreadPool = Executors.newCachedThreadPool();

        cachedThreadPool.execute(() -> {//启动线程异步处理csv文件,最多同时处理五个
            try {
                templateService.source(zhudanSourceQO);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
```
