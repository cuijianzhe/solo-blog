title: python读取本地文件，提取指定格式的内容
date: '2019-08-20 10:51:39'
updated: '2019-10-31 20:22:44'
tags: [Python]
permalink: /articles/2019/08/20/1566269499265.html
---
![](https://b3logfile.com/bing/20190530.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

```python
#-*- coding:utf-8 -*-
import sys
import re
def banner():
    print(' '*60)
    print('#'*60)
    print('#author laoyan')
    print('#This script is applied to Filtering IP information.')
    print('#'*60)
    print(' '*60)
def main(lyfile):
    try:
        f=open(lyfile,'r', encoding='UTF-8')
        ref=open('reloadips.txt','w', encoding='UTF-8')
        lyf=f.read()
        refind=re.findall(r'data-soundurl64=\".+?\"',lyf)
        print(refind)
        for i in range(len(refind)):
            a=refind[i].split('data-soundurl64="')
            b='https://static.missevan.com/'+a[1].split('"')[0]
            ref.write(b+'\n')
    except Exception as e:
        print('error occurs while reading file')
    finally:
        f.close()
        ref.close()
        print('Success!')
if __name__ == '__main__':
    if len(sys.argv) == 2:
        banner()
        lyfile=sys.argv[1]
        main(lyfile)
    else:
        print('useage: python reloadips.py filename')
        sys.exit(1)
```

