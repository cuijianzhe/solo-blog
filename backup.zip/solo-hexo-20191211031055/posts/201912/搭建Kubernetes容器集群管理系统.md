title: 搭建Kubernetes容器集群管理系统
date: '2019-12-05 18:06:59'
updated: '2019-12-07 16:43:44'
tags: [Linux, Kubernetes]
permalink: /articles/2019/12/05/1575540419679.html
---
##  # 环境
[Kubernetes中文文档](http://docs.kubernetes.org.cn/774.html)
* 主机清单
10.0.0.202   Master
10.0.0.215   Etcd
10.0.0.197   node1
10.0.0.163   node2

修改主机名:
`hostnamectl set-hostname master`

设置host文件：
```bash
cat >> /etc/hosts <<EOF
10.0.0.202 master
10.0.0.215 etcd
10.0.0.197 node1
10.0.0.163 node2
EOF
```

* 添加yum源（所有节点）
```
 wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repo
 sed -i  's/$releasever/7.7.1908/g' /etc/yum.repos.d/CentOS-Base.repo
 yum install epel-release -y 
```

## 节点部署

### 节点部署
* master节点
```
yum install -y kubernetes etcd flannel ntp
```
> 注：Flannel为Docker提供一种可配置的虚拟重叠网络。实现跨物理机的容器乊间能直接访问
1、Flannel在每一台主机上运行一个 agent。
2、flanneld，负责在提前配置好的地址空间中分配子网租约。Flannel使用etcd来存储网络配置。
3、ntpntpntp： 主要用于同步容器 主要用于同步容器 主要用于同步容器 主要用于同步容器 主要用于同步容器 云平台中所有结点的时间。 云平台中所有结点的时间。 云平台中所有结点的时间。 云平台中所有结点的时间。 云平台中所有结点的时间。 云平台中所有结点的时间。 云平台中所有结点的时间。 云平台中结点的时间需要保持一致。 云平台中结点的时间需要保持一致。 云平台中结点的时间需要保持一致。 云平台中结点的时间需要保持一致。 云平台中结点的时间需要保持一致。 云平台中结点的时间需要保持一致。 云平台中结点的时间需要保持一致。 云平台中结点的时间需要保持一致。 云平台中结点的时间需要保持一致。
4、kubernetes 中包括了服务端和客户端相关的软件包
5、etcd是etcd服务的软件包

* Etcd节点
```
yum install  etcd ntp -y
```
* node1节点：
```
yum install kubernetes flannel ntp -y
```
* node2节点：
```
yum install kubernetes flannel ntp -y
```

### 配置Etcd节点服务器

```bash
[root@etcd ~]# grep -v "^$\|^#" /etc/etcd/etcd.conf 
ETCD_DATA_DIR="/var/lib/etcd/default.etcd"
ETCD_LISTEN_CLIENT_URLS="http://localhost:2379,http://10.0.0.215:2379"
ETCD_NAME="etcd"
ETCD_ADVERTISE_CLIENT_URLS="http://10.0.0.215:2379"
```

> /etc/etcd/etcd.conf配置文件含意如下：
ETCD_NAME="etcd"
etcd节点名称，如果etcd集群只有一台etcd，这一项可以注释丌用配置，默认名称为default，这个名字后面会用到。
ETCD_DATA_DIR="/var/lib/etcd/default.etcd"
etcd存储数据的目录
ETCD_LISTEN_CLIENT_URLS="http://localhost:2379,http://192.168.1.63:2379"
etcd对外服务监听地址，一般指定2379端口，如果为0.0.0.0将会监听所有接口
ETCD_ARGS=""
需要额外添加的参数，可以自己添加，etcd的所有参数可以通过etcd -h查看。

```bash
[root@etcd ~]# systemctl start etcd 
[root@etcd ~]# systemctl enable  etcd 
Created symlink from /etc/systemd/system/multi-user.target.wants/etcd.service to /usr/lib/systemd/system/etcd.service.
[root@etcd ~]# systemctl status   etcd 
[root@etcd ~]# netstat -antup | grep 2379
tcp        0      0 127.0.0.1:2379          0.0.0.0:*               LISTEN      12038/etcd          
tcp        0      0 10.0.0.215:2379         0.0.0.0:*               LISTEN      12038/etcd          
tcp        0      0 10.0.0.215:41144        10.0.0.215:2379         ESTABLISHED 12038/etcd          
tcp        0      0 127.0.0.1:54510         127.0.0.1:2379          ESTABLISHED 12038/etcd          
tcp        0      0 10.0.0.215:2379         10.0.0.215:41144        ESTABLISHED 12038/etcd          
tcp        0      0 127.0.0.1:2379          127.0.0.1:54510         ESTABLISHED 12038/etcd          
[root@etcd ~]# etcdctl member list
8e9e05c52164694d: name=etcd peerURLs=http://localhost:2380 clientURLs=http://10.0.0.215:2379 isLeader=true
```
* etcdctl member list 检查etc集群成员列表

### 配置master节点
#### 配置kubernetes配置文件
```bash
[root@master ~]# grep -v "^$\|^#" /etc/kubernetes/config 
KUBE_LOGTOSTDERR="--logtostderr=true"
KUBE_LOG_LEVEL="--v=0"
KUBE_ALLOW_PRIV="--allow-privileged=false"
KUBE_MASTER="--master=http://10.0.0.202:8080"
```
#指定master在10.0.0.202  IP上监听端口8080

> 注：/etc/kubernetes/config配置文件含意：
KUBE_LOGTOSTDERR="--logtostderr=true" #表示错误日志记录到文件还是输出到stderr标准错误输出。
KUBE_LOG_LEVEL="--v=0" #日志等级。
KUBE_ALLOW_PRIV="--allow_privileged=false" #是否允讲运行特权容器。false表示是否允许特权容器

#### 修改apiserver配置文件
```bash
[root@master ~]# grep -v "^$\|^#" /etc/kubernetes/apiserver 
KUBE_API_ADDRESS="--insecure-bind-address=0.0.0.0"
KUBE_ETCD_SERVERS="--etcd-servers=http://10.0.0.215:2379"
KUBE_SERVICE_ADDRESSES="--service-cluster-ip-range=10.254.0.0/16"
KUBE_ADMISSION_CONTROL="--admission-control=AlwaysAdmit,NamespaceExists,LimitRanger,SecurityContextDeny,ServiceAccount,ResourceQuota"
KUBE_API_ARGS=""
```

> 注：/etc/kubernetes/apiserver配置文件含意：
* KUBE_API_ADDRESS="--insecure-bind-address=0.0.0.0" ##监听的接口，如果配置为127.0.0.1则只监听localhost，配置为0.0.0.0会监听所有接口，这里配置为0.0.0.0。
* KUBE_ETCD_SERVERS="--etcd-servers=http://192.168.1.63:2379" #etcd服务地址，前面已经启动了etcd服务
* KUBE_SERVICE_ADDRESSES="--service-cluster-ip-range=10.254.0.0/16" #kubernetes可以分配的ip的范围，kubernetes吭劢的每一个pod以及serveice都会分配一个ip地址，将从这个范围中分配IP。
KUBE_ADMISSION_CONTROL="--admission-control=AlwaysAdmit" #不做限制，允许所有节点可以访问apiserver ，对所有请求开绿灯。

* 扩展：
admission-control（准入控制） 概述：admission controller本质上一段代码，在对kubernetes api的请求过程中，顺序为 先经过认证和授权，然后执行准入操作，最后对目标对象进行操作。

#### 配置kube-controller-manager配置文件

```bash
[root@master ~]# vim /etc/kubernetes/controller-manager 
###
# The following values are used to configure the kubernetes controller-manager
# defaults from config and apiserver should be adequate  默认配置就应该足够了
# Add your own!
KUBE_CONTROLLER_MANAGER_ARGS=""
```
#### 配置kube-scheduler配置文件
```bash
[root@master ~]# vim /etc/kubernetes/scheduler 
###
# kubernetes scheduler config
# default config should be adequate
# Add your own!
KUBE_SCHEDULER_ARGS="0.0.0.0"
```
> 改scheduler监听到的地址为：0.0.0.0，默认是127.0.0.1。

### 配置etcd，指定容器云中docker的IP网段 ，在etcd上
* 设置etc网络：
```bash
[root@etcd ~]# etcdctl mkdir /k8s/network 
[root@etcd ~]# etcdctl set /k8s/network/config '{"Network":"10.255.0.0/16"}'
{"Network":"10.255.0.0/16"}
[root@etcd ~]# etcdctl get /k8s/network/config
{"Network":"10.255.0.0/16"}
```

> 注：在启动flannel之前，需要在etcd中添加一条网络配置记录，这个配置将用于flannel分配给每个docker的虚拟IP地址段。用于配置在minion上docker的IP地址.
由于flannel将覆盖docker0上的地址，所以flannel服务要先于docker服务启动。如果docker服务已经吭劢，则先停止docker服务，然后启动flannel，再启动docker

* flannel启动过程解析:
（1）从etcd中获取出/k8s/network/config的值
（2）划分subnet子网，并在etcd中迚行注册
（3）将子网信息记录到/run/flannel/subnet.env中

* 配置一下flanneld 服务：（master节点）
```bash
[root@master ~]# grep -v "^$\|^#" /etc/sysconfig/flanneld 
FLANNEL_ETCD_ENDPOINTS="http://10.0.0.215:2379"
FLANNEL_ETCD_PREFIX="/k8s/network"
FLANNEL_OPTIONS="--iface=eth0"
```

```
[root@master ~]# systemctl restart flanneld
```

* 查看子网信息/run/flannel/subnet.env
```bash
[root@master ~]# cat /run/flannel/subnet.env 
FLANNEL_NETWORK=10.255.0.0/16
FLANNEL_SUBNET=10.255.80.1/24
FLANNEL_MTU=1422
FLANNEL_IPMASQ=false
```
之后将会有一个脚本将subnet.env转写成一个docker的环境变量文件/run/flannel/docker。docker0的地址是由 /run/flannel/subnet.env 的 FLANNEL_SUBNET 参数决定的。

```bash
[root@master ~]# cat /run/flannel/docker
DOCKER_OPT_BIP="--bip=10.255.80.1/24"
DOCKER_OPT_IPMASQ="--ip-masq=true"
DOCKER_OPT_MTU="--mtu=1422"
DOCKER_NETWORK_OPTIONS=" --bip=10.255.80.1/24 --ip-masq=true --mtu=1422"
```

启动master上4个服务：
```
[root@master ~]# systemctl restart kube-apiserver kube-controller-manager kube-scheduler flanneld
[root@master ~]# systemctl status kube-apiserver kube-controller-manager kube-scheduler flanneld
[root@master ~]# systemctl enable kube-apiserver kube-controller-manager kube-scheduler flanneld
```

### 配置node节点

```bash
[root@node1 ~]# grep -v "^$\|^#" /etc/sysconfig/flanneld 
FLANNEL_ETCD_ENDPOINTS="http://10.0.0.215:2379"
FLANNEL_ETCD_PREFIX="/k8s/network"
FLANNEL_OPTIONS="--iface=eth0"
```

#### 配置node1上的master地址和 kube-proxy
1. 配置node1上的master地址
```bash
[root@node1 ~]# grep -v "^$\|^#" /etc/kubernetes/config 
KUBE_LOGTOSTDERR="--logtostderr=true"
KUBE_LOG_LEVEL="--v=0"
KUBE_ALLOW_PRIV="--allow-privileged=false"
KUBE_MASTER="--master=http://10.0.0.202:8080"
```
1. kube-proxy的作用主要是负责service的实现，具体来说，就是实现了内部从pod到service。
```bash
[root@node1 ~]# grep -v '^$\|^#' /etc/kubernetes/proxy 
KUBE_PROXY_ARGS=""
```

#### 配置node1 kubelet

Kubelet运行在minion节点上。Kubelet组件管理Pod、Pod中容器及容器的镜像和卷等信息。

```bash
[root@node1 ~]# vim /etc/kubernetes/kubelet 

###
# kubernetes kubelet (minion) config

# The address for the info server to serve on (set to 0.0.0.0 or "" for all interfaces)
KUBELET_ADDRESS="--address=0.0.0.0"

# The port for the info server to serve on
# KUBELET_PORT="--port=10250"

# You may leave this blank to use the actual hostname
KUBELET_HOSTNAME="--hostname-override=node1"

# location of the api-server
KUBELET_API_SERVER="--api-servers=http://10.0.0.202:8080"

# pod infrastructure container
KUBELET_POD_INFRA_CONTAINER="--pod-infra-container-image=registry.access.redhat.com/rhel7/pod-infrastructure:latest"

# Add your own!
KUBELET_ARGS=""
```

> KUBELET_POD_INFRA_CONTAINER="--pod-infra-container-image=registry.access.redhat.com/rhel7/pod-infrastructure:latest"
注：INFRA infrastructure  基础设施
KUBELET_POD_INFRA_CONTAINER 指定pod基础容器镜像地址。这个是一个基础容器，每一个
Pod启动的时候都会启动一个这样的容器。如果你的本地没有这个镜像，kubelet会连接外网把这个镜像下载下来。最开始的时候是在Google的registry上，因此国内因为GFW都下载不了导致Pod运行不起来。现在每个版本的Kubernetes都把这个镜像地址改成红帽的地址了。你也可以提前传到自己的registry上，然后再用这个参数指定成自己的镜像链接。
注：https://access.redhat.com/containers/ 是红帽的容器下载站点

重新启动：
```
[root@node1 ~]# systemctl  restart flanneld kube-proxy kubelet docker
[root@node1 ~]# systemctl enable flanneld kube-proxy kubelet docker
```
查看kube-proxy
```
[root@node1 ~]# netstat -antup | grep proxy 
tcp        0      0 127.0.0.1:10249         0.0.0.0:*               LISTEN      12961/kube-proxy    
tcp        0      0 10.0.0.197:46564        10.0.0.202:8080         ESTABLISHED 12961/kube-proxy    
tcp        0      0 10.0.0.197:46566        10.0.0.202:8080         ESTABLISHED 12961/kube-proxy    
```

### 配置node2节点

#### 配置node2网络，本实例采用flannel方式来配置
配置方法和node1一样
```
[root@node1 ~]# scp /etc/sysconfig/flanneld 10.0.0.163:/etc/sysconfig/
```
```bash
[root@node2 ~]# grep -v '^$\|^#' /etc/sysconfig/flanneld
FLANNEL_ETCD_ENDPOINTS="http://10.0.0.215:2379"
FLANNEL_ETCD_PREFIX="/k8s/network"
FLANNEL_OPTIONS="--iface=eth0"
```


#### 配置node2 上master地址和kube-proxy
```
[root@node1 ~]# scp /etc/kubernetes/config 10.0.0.163:/etc/kubernetes/
[root@node1 ~]# scp /etc/kubernetes/proxy 10.0.0.163:/etc/kubernetes/
```

```
[root@node2 ~]# systemctl start kube-proxy
[root@node2 ~]# systemctl status kube-proxy
[root@node2 ~]# netstat -antup | grep proxy 
tcp        0      0 127.0.0.1:10249         0.0.0.0:*               LISTEN      12993/kube-proxy    
tcp        0      0 10.0.0.163:35836        10.0.0.202:8080         ESTABLISHED 12993/kube-proxy    
tcp        0      0 10.0.0.163:35834        10.0.0.202:8080         ESTABLISHED 12993/kube-proxy    
tcp        0      0 10.0.0.163:35832        10.0.0.202:8080         ESTABLISHED 12993/kube-proxy    
```

#### 配置node2 kubelet
```
[root@node1 ~]# scp /etc/kubernetes/kubelet 10.0.0.163:/etc/kubernetes/
```

```bash
[root@node2 ~]# grep -v "^$\|^#" /etc/kubernetes/kubelet 
KUBELET_ADDRESS="--address=0.0.0.0"
KUBELET_HOSTNAME="--hostname-override=node2"
KUBELET_API_SERVER="--api-servers=http://10.0.0.202:8080"
KUBELET_POD_INFRA_CONTAINER="--pod-infra-container-image=registry.access.redhat.com/rhel7/pod-infrastructure:latest"
KUBELET_ARGS=""
```

```
[root@node2 ~]# systemctl  start kubelet 
[root@node2 ~]# systemctl  status kubelet 
```

```
[root@node2 ~]# netstat -antup | grep 8080
tcp        0      0 10.0.0.163:35844        10.0.0.202:8080         ESTABLISHED 14987/kubelet       
tcp        0      0 10.0.0.163:35848        10.0.0.202:8080         ESTABLISHED 14987/kubelet       
tcp        0      0 10.0.0.163:35850        10.0.0.202:8080         ESTABLISHED 14987/kubelet       
tcp        0      0 10.0.0.163:35846        10.0.0.202:8080         ESTABLISHED 14987/kubelet       
tcp        0      0 10.0.0.163:35834        10.0.0.202:8080         ESTABLISHED 12993/kube-proxy    
tcp        0      0 10.0.0.163:35832        10.0.0.202:8080         ESTABLISHED 12993/kube-proxy    
tcp        0      0 10.0.0.163:35842        10.0.0.202:8080         ESTABLISHED 14987/kubelet      
```
启动node2所有服务：

```
[root@node2 ~]# systemctl restart flanneld kube-proxy kubelet docker
[root@node2 ~]# systemctl enable flanneld kube-proxy kubelet docker
[root@node2 ~]# systemctl status flanneld kube-proxy kubelet docker
```


## 查看集群状态：
```
[root@master ~]# kubectl get nodes
NAME      STATUS    AGE
node1     Ready     12m
node2     Ready     1m
```
```
[root@master ~]# kubectl version
Client Version: version.Info{Major:"1", Minor:"5", GitVersion:"v1.5.2", GitCommit:"269f928217957e7126dc87e6adfa82242bfe5b1e", GitTreeState:"clean", BuildDate:"2017-07-03T15:31:10Z", GoVersion:"go1.7.4", Compiler:"gc", Platform:"linux/amd64"}
Server Version: version.Info{Major:"1", Minor:"5", GitVersion:"v1.5.2", GitCommit:"269f928217957e7126dc87e6adfa82242bfe5b1e", GitTreeState:"clean", BuildDate:"2017-07-03T15:31:10Z", GoVersion:"go1.7.4", Compiler:"gc", Platform:"linux/amd64"}
```

端口服务总结：
Etcd 服务：2379端口

master: 一共4个服务，通讯使用8080端口
`systemctl restart kube-apiserver kube-controller-manager kube-scheduler flanneld`

node1-minion: 一共4个服务
kubeproxy 监控听端口号是 10249 ，kubelet 监听端口10248、10250、10255三个端口
`systemctl restart flanneld kube-proxy kubelet docker`

node2-minion: 一共4个服务
`systemctl restart flanneld kube-proxy kubelet docker`




