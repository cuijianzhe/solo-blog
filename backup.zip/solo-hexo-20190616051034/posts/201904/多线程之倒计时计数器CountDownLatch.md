title: 多线程之倒计时计数器 CountDownLatch
date: '2019-04-15 14:20:59'
updated: '2019-04-15 14:20:59'
tags: [进阶之路]
permalink: /articles/2019/04/15/1555309259187.html
---
上篇回顾：[多线程回环栅栏 CyclicBarrier](https://hacpai.com/forward?goto=http%3A%2F%2Fwww.cjzshilong.cn%3A8080%2Farticles%2F2019%2F04%2F10%2F1554887221480.html)
### 使用场景

假设有一个列表，多选之后，点击压缩。此时后台肯定是多线程跑压缩任务，那我们就可以使用`CountDownLatch`来在全部压缩完成之后处理一些事情。
### 示例代码
```
public class testMain {

    public static void main(String[] args) {
        // 初始化计数
        AtomicInteger count = new AtomicInteger(0);
        // 创建 10 个线程
        ExecutorService es = Executors.newFixedThreadPool(10);
        // 设置 CountDownLatch 为 10
        CountDownLatch countDownLatch = new CountDownLatch(10);

        for (int i = 0; i < 10; i++) {
            es.execute(() -> {
                // 每个线程累计增加 1000 次
                for (int j = 0; j < 1000; j++) {
                    count.addAndGet(1);
                }
                // 线程最后执行 CountDownLatch
                countDownLatch.countDown();
            });
        }
        try {
            countDownLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        ;
        System.out.println(count);

    }
}
```
可以看到，CountDownLatch 与 CyclicBarrier 非常类似，由此引出几个问题：

#### 解释一下 CountDownLatch 概念?

CountDownLatch 是通过一个计数器来实现的，计数器的初始值为线程的数量。每当一个线程完成了自己的任务后，计数器的值就会减 1。当计数器值到达 0 时，它表示所有的线程已经完成了任务，然后在闭锁上等待的线程就可以恢复执行任务。

#### CountDownLatch 和 CyclicBarrier 的不同之处?

CyclicBarrier 可以重用，CountDownLatch 不可以重用。  
CountDownLatch 的下一步的动作实施者是主线程  
CyclicBarrier 的下一步动作实施者还是“其他线程”本身
