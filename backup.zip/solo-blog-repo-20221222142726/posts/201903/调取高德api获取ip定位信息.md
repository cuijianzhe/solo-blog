title: 调取高德api获取ip定位信息
date: '2019-03-08 10:56:56'
updated: '2020-04-23 19:06:49'
tags: [API]
permalink: /articles/2019/03/08/1552013816021.html
---
![](https://b3logfile.com/bing/20180530.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

我为什么记录这个呢，为了以后用到相关监控工具或者访问日志时可以调用这个 API 去查询访问者的地域信息
IP 定位是一个简单的 HTTP 接口，根据用户输入的 IP 地址，能够快速的帮用户定位 IP 的所在位置。
使用 API 前您需先[申请Key](https://lbs.amap.com/dev/key)。若无高德地图 API 账号需要先申请账号。

第一步，申请”Web 服务 API”密钥（Key）；

第二步，拼接 HTTP 请求 URL，第一步申请的 Key 需作为必填参数一同发送；

第三步，接收 HTTP 请求返回的数据（JSON 或 XML 格式），解析数据。

如无特殊声明，接口的输入参数和输出数据编码全部统一为 UTF-8。

### IP 定位

----

* **IP 定位 API 服务地址：**

|URL|https://restapi.amap.com/v3/ip?parameters|
|---|---|
|请求方式|GET|

parameters 代表的参数包括必填参数和可选参数。所有参数均使用和号字符(&)进行分隔。下面的列表枚举了这些参数及其使用规则。

* **请求参数**

| 参数名 | 含义 | 规则说明 | 是否必须 | 缺省值 |
| --- | --- | --- |
| key| 请求服务权限标识  | 用户在高德地图官网[申请Web服务API类型KEY](https://lbs.amap.com/dev/)  | 必填 |
| ip| ip 地址 |  需要搜索的 IP 地址（仅支持国内）若用户不填写 IP，则取客户 http 之中的请求来进行定位 | 可选 |
| sig |  签名 | 选择数字签名认证的付费用户必填 | 可选 |
|output| 返回格式 |  可选值：JSON,XML | 可选 |

* **返回结果参数说明**

|名称含义|含义|规则说明|
|---|---|---|
|status|返回结果状态值|值为 0 或 1,0 表示失败；1 表示成功|
|info|返回状态说明|返回状态说明，status 为 0 时，info 返回错误原因，否则返回“OK”。|
|infocode|状态码|返回状态说明，10000 代表正确，详情参阅 info 状态表|
|province|省份名称|若为直辖市则显示直辖市名称；如果在局域网 IP 网段内，则返回“局域网”；非法 IP 以及国外 IP 则返回空|
|city|城市名称|若为直辖市则显示直辖市名称；如果为局域网网段内 IP 或者非法 IP 或国外 IP，则返回空|
|adcode|城市的 adcode 编码||
|rectangle|所在城市矩形区域范围|所在城市范围的左下右上对标对|

接下来，
这是我的高德官网 API key
![key.png](https://b3logfile.com/file/2019/04/key-426f2c14.png)

* **通过 GET 的方式开始调用：**

```
[root@zabbix ~]# curl "https://restapi.amap.com/v3/ip?output=json&key=fcxxxxqwqb1f&ip=223.71.40.26"

{"status":"1","info":"OK","infocode":"10000","province":"北京市","city":"北京市","adcode":"110000","rectangle":"116.0119343,39.66127144;116.7829835,40.2164962"}
```

如图

![API.png](https://b3logfile.com/file/2019/04/API-50d4f7f2.png)

** 哦也**?   ……
