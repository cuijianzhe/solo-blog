title: 阿里云机器和本地IDC建立ipsec VPN
date: '2019-03-16 15:18:50'
updated: '2019-10-31 20:27:21'
tags: [网络, Linux]
permalink: /articles/2019/03/16/1552720730829.html
---
![](https://b3logfile.com/bing/20180607.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 阿里机器端： ##
### 1. 安装strongswan
```
[root@blog_server ~]# yum install strongswan -y

Loaded plugins: fastestmirror
Loading mirror speeds from cached hostfile
Resolving Dependencies
--> Running transaction check
---> Package strongswan.x86_64 0:5.7.2-1.el7 will be installed
--> Processing Dependency: libtspi.so.1()(64bit) for package: strongswan-5.7.2-1.el7.x86_64
--> Running transaction check
---> Package trousers.x86_64 0:0.3.14-2.el7 will be installed
--> Finished Dependency Resolution

Dependencies Resolved

======================================================================================================================================================
 Package                              Arch                             Version                                   Repository                      Size
======================================================================================================================================================
Installing:
 strongswan                           x86_64                           5.7.2-1.el7                               epel                           1.4 M
Installing for dependencies:
 trousers                             x86_64                           0.3.14-2.el7                              base                           289 k

Transaction Summary
======================================================================================================================================================
Install  1 Package (+1 Dependent package)

Total download size: 1.7 M
Installed size: 4.8 M
Downloading packages:
(1/2): trousers-0.3.14-2.el7.x86_64.rpm                                                                                        | 289 kB  00:00:00     
(2/2): strongswan-5.7.2-1.el7.x86_64.rpm                                                                                       | 1.4 MB  00:00:00     
------------------------------------------------------------------------------------------------------------------------------------------------------
Total                                                                                                                 6.4 MB/s | 1.7 MB  00:00:00     
Running transaction check
Running transaction test
Transaction test succeeded
Running transaction
  Installing : trousers-0.3.14-2.el7.x86_64                                                                                                       1/2 
  Installing : strongswan-5.7.2-1.el7.x86_64                                                                                                      2/2 
  Verifying  : trousers-0.3.14-2.el7.x86_64                                                                                                       1/2 
  Verifying  : strongswan-5.7.2-1.el7.x86_64                                                                                                      2/2 

Installed:
  strongswan.x86_64 0:5.7.2-1.el7                                                                                                                     

Dependency Installed:
  trousers.x86_64 0:0.3.14-2.el7                                                                                                                      

Complete!
```

### 2.配置VPN

```
[root@blog_server ~]# vim /etc/strongswan/ipsec.conf 
# ipsec.conf - strongSwan IPsec configuration file

# basic configuration

config setup
        # strictcrlpolicy=yes
        # uniqueids = no

# Add connections here.

# Sample VPN connections
conn IDC
    keyexchange=ikev1
    left=0.0.0.0
    leftsubnet=172.17.144.0/20
    #阿里侧内网ip地址段 
    leftid=39.97.161.x
     # 阿里侧ID号，默认ip地址
    leftfirewall=no

 
    right=210.12.5.x
   #本地IDC出口公网
    rightsubnet=10.100.0.0/18
  //本地IDC内网ip地址段
    rightid=210.12.5.x
  #本地IDC的ID

    auto=start
    authby=secret
    ike=aes128-sha1-modp1024
   #IKE参数：加密算法、认证算法
    esp=aes128-sha1
   #安全协议参数
    type=tunnel
   #隧道模式
``` 
### 3.配置预共享秘钥
```
[root@blog_server ~]# vim /etc/strongswan/ipsec.secrets 
# ipsec.secrets - strongSwan IPsec secrets file
39.97.161.115 210.12.5.146 : PSK "123456"
```
```
[root@blog ~]# systemctl start strongswan
```
## 本地IDC端： ##
### 1. 配置访问控制列表，定义需要保护的数据流。
```
acl number 3001
 rule 5 permit ip source 10.100.0.0 0.0.63.255 destination 172.17.144.0 0.0.15.255
```
### 2.配置ipsec安全提议
```
ipsec proposal prop1631503669
 esp authentication-algorithm sha2-256
 esp encryption-algorithm aes-256 aes-128 des
```
### 3.创建IKE安全提议
```
ike proposal 2

 encryption-algorithm aes-256 aes-128 3des des
 dh group14 group5 group2 group1
 authentication-algorithm sha2-256 sha1 md5
 authentication-method pre-share
 integrity-algorithm hmac-sha2-256 hmac-sha1-96
 prf hmac-sha2-256 hmac-sha1
```
### 4.配置IKE对等体
```
ike peer ike1631503669

 undo version 2
 pre-shared-key %^%#pkCJSNJX_4Lk}1I0tu/#+7l:;,2SF~4@M~EK70k7%^%#
 ike-proposal 2
 remote-id-type ip
 remote-address 39.97.161.115
```
### 5.配置isakmp方式的ipsec策略
```
ipsec policy ipsec1191138051 2 isakmp

 security acl 3001
 ike-peer ike1631503669
 proposal prop1631503669
 tunnel local applied-interface           
 alias ali_test
 sa trigger-mode auto
 sa duration traffic-based 5242880
 sa duration time-based 3600
```
### 6.在接口调用上述策略
```
interface GigabitEthernet0/0/2

 undo shutdown
 ip address x.x.x.x 255.255.255.252
 gateway x.x.x.x
 service-manage http permit
 service-manage https permit
 service-manage ping permit
 service-manage ssh permit
 service-manage snmp permit
 service-manage telnet permit
 service-manage netconf permit
 bandwidth ingress 20000 threshold 95
 bandwidth egress 20000 threshold 95
 redirect-reverse next-hop 210.12.5.145
 ipsec policy ipsec1191138051
```

验证：
阿里侧ip：
```
[root@blog_server ~]# ifconfig

eth0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet 172.17.148.238  netmask 255.255.240.0  broadcast 172.17.159.255
        ether 00:16:3e:30:9a:be  txqueuelen 1000  (Ethernet)
        RX packets 200397  bytes 64382166 (61.3 MiB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 187248  bytes 142081323 (135.4 MiB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0

lo: flags=73<UP,LOOPBACK,RUNNING>  mtu 65536
        inet 127.0.0.1  netmask 255.0.0.0
        loop  txqueuelen 1  (Local Loopback)
        RX packets 48529  bytes 73198705 (69.8 MiB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 48529  bytes 73198705 (69.8 MiB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0
```
测试：
![ping1.png](https://b3logfile.com/file/2019/03/ping1-217514d6.png)

并且已经可以通过内网ip访问阿里云上的tomcat服务
![tomcat.png](https://b3logfile.com/file/2019/03/tomcat-606db2be.png)




