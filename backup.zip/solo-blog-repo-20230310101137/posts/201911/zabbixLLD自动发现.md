title: zabbix LLD 自动发现
date: '2019-11-26 13:50:54'
updated: '2020-12-05 15:17:28'
tags: [Linux]
permalink: /articles/2019/11/26/1555140148890.html
---
![](https://b3logfile.com/bing/20180413.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 1. 不同业务对应不同模板，现在创建一个模板，用于当前这个特殊业务

![模板.png](https://b3logfile.com/file/2019/04/模板-910ac960.png)
创建完成后，点击右上角的创建自动发现规则。
![发现规则.png](https://b3logfile.com/file/2019/04/发现规则-a61f4ae5.png)

## 2.键值脚本内容

![键值.png](https://b3logfile.com/file/2019/04/键值-7d42cec7.png)

```
[root@zabbix zabbix_agentd.d]# /usr/lib/zabbix/externalscripts/apdiscovery.sh 
{"data":[ {"{#APID}":"0"},{"{#APID}":"1"},{"{#APID}":"2"},{"{#APID}":"3"},{"{#APID}":"4"},{"{#APID}":"5"},{"{#APID}":"6"},{"{#APID}":"7"},{"{#APID}":"8"},{"{#APID}":"9"},{"{#APID}":"10"},{"{#APID}":"11"},{"{#APID}":"12"},{"{#APID}":"13"},{"{#APID}":"14"},{"{#APID}":"15"},{"{#APID}":"16"},{"{#APID}":"17"},{"{#APID}":"18"},{"{#APID}":"19"},{"{#APID}":"20"},{"{#APID}":"21"},{"{#APID}":"22"},{"{#APID}":"23"} ]}
```

脚本可取出当前设备的 ID 号；并且写出来的格式必须是 JSON 格式。

## 3. 创建监控项原型

对应的宏变量值和脚本中对应的变量要一致，并且大写。
![宏.png](https://b3logfile.com/file/2019/04/宏-62593bb5.png)

### 自动发现无线ap值（APNAME、APID）：

* SHELL脚本

```bash
#!/bin/bash
id=$(snmpwalk -v 2c -c limi@2018  10.200.252.8 1.3.6.1.4.1.2011.6.139.13.3.10.1.5 | cut -f1 -d "=" | cut -f10 -d ".")
id_array=(${id})
sum=$(snmpwalk -v 2c -c limi@2018  10.200.252.8 1.3.6.1.4.1.2011.6.139.13.3.10.1.5 | awk  '{print $4}' | sed 's/"//g' | wc -l)
name=$(snmpwalk -v 2c -c limi@2018  10.200.252.8 enterprises.2011.6.139.13.3.10.1.5 | awk  '{print $4}' | sed 's/"//g')
name_array=($name)

printf '{\"data\":[ '
for ((i=0;i<$sum;i++))
do
    printf "{\"{#APID}\":\"${id_array[$i]}\",\"{#APNAME}\":\"${name_array[$i]}\" }"

    if [ $i -lt $[ $sum-1 ] ];then
        printf ','
        fi
done
printf " ]}"
```

自动发现无线ap值（APNAME、APID）：

* PYTHON脚本

```python
#!/bin/env python3
#Author:cuijianzhe
import subprocess
import json

def PortList():
    CMD = "snmpwalk -v 2c -c limi@2018  10.200.250.5 1.3.6.1.4.1.2011.6.139.13.3.10.1.5"
    Result_str = subprocess.getoutput(CMD)
    tmp_list = Result_str.split("\n")
    ap_dict = {}
    for line in tmp_list:
        apName = eval(line.split(':')[3])
        apId = line.split('=')[0].split('.')[9]
        ap_dict[apId] = apName
    return ap_dict

if __name__ == "__main__":
    Results = PortList()
    aps = []
    for apinfo in Results:
        aps += [{'{#APID}': apinfo,'{#APNAME}': Results[apinfo]}]
    print(json.dumps({'data':aps},sort_keys=True,indent=4,separators=(',',':')))
```

```
[root@zabbix ~]# zabbix_get  -s 127.0.0.1 -k discovery_apid

{"data":[ {"{#APID}":"0","{#APNAME}":"446a-2e13-01e0" },{"{#APID}":"1","{#APNAME}":"446a-2e13-0900" },{"{#APID}":"2","{#APNAME}":"446a-2e13-01c0" },{"{#APID}":"3","{#APNAME}":"446a-2e13-01a0" },{"{#APID}":"4","{#APNAME}":"446a-2e13-0260" },{"{#APID}":"5","{#APNAME}":"446a-2e13-1220" },{"{#APID}":"6","{#APNAME}":"446a-2e17-db80" },{"{#APID}":"7","{#APNAME}":"446a-2e17-dac0" },{"{#APID}":"8","{#APNAME}":"446a-2e17-db00" },{"{#APID}":"9","{#APNAME}":"3F_DONG" },{"{#APID}":"10","{#APNAME}":"446a-2e17-db40" },{"{#APID}":"11","{#APNAME}":"446a-2e17-da60" },{"{#APID}":"12","{#APNAME}":"446a-2e13-2660" },{"{#APID}":"13","{#APNAME}":"446a-2e13-2680" },{"{#APID}":"14","{#APNAME}":"446a-2e13-0e20" },{"{#APID}":"15","{#APNAME}":"446a-2e13-25e0" },{"{#APID}":"16","{#APNAME}":"446a-2e13-2620" },{"{#APID}":"17","{#APNAME}":"446a-2e13-0160" },{"{#APID}":"18","{#APNAME}":"446a-2e13-0980" },{"{#APID}":"19","{#APNAME}":"446a-2e13-2580" },{"{#APID}":"20","{#APNAME}":"446a-2e13-18e0" },{"{#APID}":"21","{#APNAME}":"446a-2e13-2600" },{"{#APID}":"22","{#APNAME}":"446a-2e20-6780" },{"{#APID}":"23","{#APNAME}":"446a-2e20-6760" } ]}
```

## 4. 编写脚本值 zabbix 发现的 value 值传参进去而得出自己想要的值；

![传参.png](https://b3logfile.com/file/2019/04/传参-b43d6c96.png)

**可通过 zabbix_get 得出结果**
![get.png](https://b3logfile.com/file/2019/04/get-f6085e5d.png)

5. 新建或者在本机上调用自动发现模板
   查看自动发现的值：

![AP.png](https://b3logfile.com/file/2019/04/AP-164145e2.png)

![image.png](https://b3logfile.com/file/2020/12/image-18ebfe76.png)



