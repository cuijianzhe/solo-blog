title: 记一次grafana变量取值的过程
date: '2019-04-16 18:32:21'
updated: '2019-10-31 20:25:36'
tags: [Linux]
permalink: /articles/2019/04/16/1555410740995.html
---
![](https://b3logfile.com/bing/20181001.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


Grafana官网相关：[https://grafana.com/docs/](https://grafana.com/docs/)
## 1、首先把变量整到dashboard中，这次取zabbix的值由如下几个变量组成：
![变量.png](https://b3logfile.com/file/2019/04/变量-c7c813f6.png)

## 分别展示下变量的组成：
## 主机组：
``
![主机组.png](https://b3logfile.com/file/2019/04/主机组-8a2bdcae.png)
## 主机：
![主机.png](https://b3logfile.com/file/2019/04/主机-1ea72f14.png)
## 应用监控项
![应用.png](https://b3logfile.com/file/2019/04/应用-81e69cdc.png)
## 监控项：
![监控项.png](https://b3logfile.com/file/2019/04/监控项-69dcc298.png)
## 还有一个是网卡流量的监控取值
`Query：*.$host.Network interfaces.*`
`Regex：/(?:Incoming|Outgoing) network traffic on (.*)/`
![网卡.png](https://b3logfile.com/file/2019/04/网卡-172da4fd.png)
![网卡配置.png](https://b3logfile.com/file/2019/04/网卡配置-2f7c5152.png)

## 看下监控仪表盘模板展示，会应用到各个主机：
![模板.png](https://b3logfile.com/file/2019/04/模板-cdab864e.png)


### 添加变量后期更改数据只改变量即可，其他参数不用改变。
![变量.png](https://b3logfile.com/file/2019/04/变量-0f60e660.png)

然后设置主机组匹配规则：
![匹配.png](https://b3logfile.com/file/2019/04/匹配-a0282e78.png)

主机匹配：
![主机匹配.png](https://b3logfile.com/file/2019/04/主机匹配-e9894e3e.png)


## 添加ROWS模板
![image.png](https://b3logfile.com/file/2019/09/image-04b8716d.png)

![image.png](https://b3logfile.com/file/2019/09/image-4e4c4d8d.png)

相关配置：
`/CPU (user|system|iowait)/`

