title: 实现AI换脸术
date: '2019-08-31 14:57:56'
updated: '2019-08-31 18:18:32'
tags: [python]
permalink: /articles/2019/08/31/1567234676723.html
---
* [Face ++官方网址](https://www.faceplusplus.com.cn/)
* [使用脸部识别API](https://console.faceplusplus.com.cn/documents/4888373)
* [图像识别融合API](https://console.faceplusplus.com.cn/documents/20813963)

在此使用旷视科技的人脸识别API进行完成。先对图片进行脸部识别并进行融合，看这里：
```
import requests
import simplejson
import json
import base64

def find_face(imgfile):
    print("finding")
    http_url = 'https://api-cn.faceplusplus.com/facepp/v3/detect'
    data = {"api_key": 'nFnE8LQ32lteRvt99pA-kaMGCG9PRkGI',
            "api_secret": '0RD-G7z9LNEmd4WDdd7PJSmq7vQaIuTs', "image_file": imgfile, "return_landmark": 1}
    files = {"image_file": open(imgfile, "rb")}
    response = requests.post(http_url, data=data, files=files)
    req_con = response.content.decode('utf-8')   #decode将已编码的json字符串解码成python对象
    req_dict = json.JSONDecoder().decode(req_con)
    this_json = simplejson.dumps(req_dict)   #将Python对象编码成JSON字符串
    this_json2 = simplejson.loads(this_json)   #将已编码的 JSON 字符串解码为 Python 对象
    faces = this_json2['faces']
    # print(faces)
    list0 = faces[0]
    rectangle = list0['face_rectangle']
    # print(rectangle)

    return rectangle
# find_face()

def merge_face(img_url_1,img_url_2,img_url_3,number):
    ff1 = find_face(img_url_1)
    ff2 = find_face(img_url_2)
    rectangle1 = str(str(ff1['top']) + "," + str(ff1['left']) + "," + str(ff1['width']) + "," + str(ff1['height']))
    rectangle2 = str(ff2['top']) + "," + str(ff2['left']) + "," + str(ff2['width']) + "," + str(ff2['height'])
    url_add = "https://api-cn.faceplusplus.com/imagepp/v1/mergeface"
    f1 = open(img_url_1, 'rb')
    f1_64 = base64.b64encode(f1.read())
    f1.close()
    f2 = open(img_url_2, 'rb')
    f2_64 = base64.b64encode(f2.read())
    f2.close()
    data = {"api_key": 'nFnE8LQ32lteRvt99pA-kaMGCG9PRkGI', "api_secret": '0RD-G7z9LNEmd4WDdd7PJSmq7vQaIuTs',
            "template_base64": f1_64, "template_rectangle": rectangle1,
            "merge_base64": f2_64, "merge_rectangle": rectangle2, "merge_rate": number}
    response = requests.post(url_add, data=data)
    req_con = response.content.decode('utf-8')
    req_dict = json.JSONDecoder().decode(req_con)
    result = req_dict['result']
    imgdata = base64.b64decode(result)
    file = open(img_url_3, 'wb')
    file.write(imgdata)
    file.close()

import os
def test():
    image1 = "guan.jpg"  #图2的脸会换到图1上
    image2 = "cjz.jpg"
    image3 = "1234.png"
    try:
        merge_face(image1,image2,image3,100)
    except:
        pass
test()
```
## 把视频拆分成图片
```
# 将视频拆分成图片
def video2txt_jpg():
    vc=cv2.VideoCapture("test.mp4")
    c=1
    if vc.isOpened():
        r, frame=vc.read()
        if not os.path.exists('images'):
            os.mkdir('images')
        os.chdir('images')
    else:
        r=False
    while r:
        cv2.imwrite(str(c) + '.jpg', frame)
        # txt2image()  # 同时转换为ascii图
        r, frame=vc.read()
        c+=1
    os.chdir('..')
    return vc
video2txt_jpg()
```
可以得出如下：
![image.png](https://img.hacpai.com/file/2019/08/image-75b47260.png)

把图片整合成视频：
```
def jpg2video():
    fourcc=VideoWriter_fourcc(*"MJPG")
    fps = 24
    outfile_name = 'test.mp4'
    images=os.listdir('images')
    im=Image.open('images/' + images[0])
    vw=cv2.VideoWriter(outfile_name + '.avi', fourcc, fps, im.size)

    os.chdir('images')
    for image in range(len(images)):
        # Image.open(str(image)+'.jpg').convert("RGB").save(str(image)+'.jpg')
        frame=cv2.imread(str(image + 1) + '.jpg')
        vw.write(frame)
        # print(str(image + 1) + '.jpg' + ' finished')
    os.chdir('..')
    vw.release()
```
如下：
![image.png](https://img.hacpai.com/file/2019/08/image-b1facb4e.png)

