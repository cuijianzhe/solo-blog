title: PGone、孙八一、小青龙剪辑作品展
date: '2019-03-05 23:08:16'
updated: '2019-04-30 00:18:55'
tags: [嘻哈, HIHPOP]
permalink: /articles/2019/03/05/1551798496474.html
---
### Pgone的《H.M.E》谁还记得？小青龙的《Time》何人不知，孙八一诙谐《take it easy》！

---

###       **这个diss了嘻哈大半个娱乐圈的人……我服** :dizzy_face:

<center><video width="100%" height="100%" controls>
<source src="https://cjz.cjzshilong.cn/pgone.mp4"  type="video/mp4">
</video><center>

---

###    **小青龙和辉子的精彩battle**  :+1: 

<center><video width="100%" height="100%" controls>
<source src="https://cjz.cjzshilong.cn/Time.mp4"  type="video/mp4">
</video><center>

---
###     **这是我剪辑过的最喜欢的孙八一的作品** :+1: 

<center><video width="100%" height="100%" controls>

<source src="https://cjz.cjzshilong.cn/sunbayi.mp4"  type="video/mp4">
</video><center>
