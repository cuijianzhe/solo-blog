title: nginx反向代理tomcat项目之solo
date: '2019-03-15 19:17:18'
updated: '2020-01-19 10:06:58'
tags: [nginx]
permalink: /articles/2019/03/15/1552648638089.html
---
nginx 配置


```bash
upstream backend {
    server localhost:8080; # Solo Docker 监听端口
}

server {
    listen       80;
    server_name  cjzshilong.cn www.cjzshilong.cn; # 博客域名
    rewrite ^(.*)$ https://$host$1 permanent; 	 

   
location / {
   proxy_pass http://backend$request_uri;
   proxy_set_header  Host $host:$server_port;
   proxy_set_header Connection "Keep-Alive"; 
   proxy_set_header  X-Real-IP  $remote_addr;
   client_max_body_size  10m;
   proxy_buffer_size 128k;
   proxy_buffers  32 32k;
   proxy_busy_buffers_size 128k;
   }
```
