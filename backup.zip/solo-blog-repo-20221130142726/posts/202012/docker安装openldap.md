title: docker安装openldap
date: '2020-12-26 11:51:09'
updated: '2020-12-26 12:00:21'
tags: [Openldap]
permalink: /articles/2020/12/26/1608954669638.html
---
![](https://b3logfile.com/bing/20180811.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 项目地址

https://github.com/osixia/docker-openldap

# 服务器安装

### 获取相关镜像

```bash
docker pull osixia/openldap
docker pull osixia/phpldapadmin
```

### 部署

```
docker run \
    -d \
    -p 389:389 \
    -p 636:636 \
    -v /usr/local/ldap:/usr/local/ldap \
    -v /data/openldap/ldap:/var/lib/ldap \
    -v /data/openldap/slapd.d:/etc/ldap/slapd.d \
    --env LDAP_ORGANISATION="limikeji" \
    --env LDAP_DOMAIN="limikeji.com" \
    --env LDAP_ADMIN_PASSWORD="qwe*123456" \
    --name openldap \
    --hostname openldap-host\
    --network bridge \
    osixia/openldap:1.4.0
```

* -v /data/openldap/ldap:/var/lib/ldap：将数据持久化到本地
* 其中 -p 389:389 \ TCP/IP访问端口，-p 636:636 \ SSL连接端口。
* –name your_ldap 自行设置容器名称
* –network bridge 连接默认的bridge网络（docker0）
* –hostname openldap-host 设置容器主机名称为 openldap-host
* –env LDAP_ORGANISATION=“company” 配置LDAP组织名称
* –env LDAP_DOMAIN=“company.com” 配置LDAP域名
* –env LDAP_ADMIN_PASSWORD=“123456” 配置LDAP密码
  默认登录用户名：admin
  
  #### 安装完毕可采用此工具进行测试：
  
  ![image.png](https://b3logfile.com/file/2020/12/image-dbf68d36.png)
  
  ![image.png](https://b3logfile.com/file/2020/12/image-70471495.png)
  
  #### 安装可视化工具：PHPLdapAdmin客户端
  
  
  
  ```bash
  docker run \
  -p 8080:80 \
  --privileged \
  --name limildap \
  --env PHPLDAPADMIN_HTTPS=false \
  --env PHPLDAPADMIN_LDAP_HOSTS=172.17.148.238 \
  --detach osixia/phpldapadmin
  ```
* -d 分离模式启动容器
* –privileged 特权模式启动(使用该参数，container内的root拥有真正的root权限。
  否则，container内的root只是外部的一个普通用户权限。)
* –env PHPLDAPADMIN_HTTPS=false 禁用HTTPS
* –env PHPLDAPADMIN_LDAP_HOSTS =172.17.148.238 配置openLDAP的IP或者域名，我的openLDAP是在服务器172.17.148.238启动。
* 此处设置访问端口为8080，可自行更改访问端口号
* 可开启443端口 -p 443:443

#### 测试登录

http://39.97.161.115:8080/

![image.png](https://b3logfile.com/file/2020/12/image-fd1c1c49.png)

至此openldap使用docker安装完成

#### openldap版本：

```
$ docker exec -it openldap slapd -V
@(#) $OpenLDAP: slapd 2.4.50+dfsg-1~bpo10+1 (May  4 2020 05:25:06) $
	Debian OpenLDAP Maintainers <pkg-openldap-devel@lists.alioth.debian.org>
```

查看状态：

```
$ docker ps -a
CONTAINER ID        IMAGE                   COMMAND                  CREATED             STATUS              PORTS                                        NAMES
b0a3b2be8c6e        osixia/openldap:1.4.0   "/container/tool/run"    37 minutes ago      Up 37 minutes       0.0.0.0:389->389/tcp, 0.0.0.0:636->636/tcp   openldap
e7615fbde6e2        osixia/phpldapadmin     "/container/tool/run"    18 hours ago        Up 18 hours         443/tcp, 0.0.0.0:8080->80/tcp                limildap                                                 lute-http
```

其他操作：

```
docker exec -it openldap ldapadd -x -D "cn=admin,dc=limikeji,dc=com" -w'qwe*123456' -f /usr/local/ldap/cuijianzhe.ldif  #添加人员
docker cp  cuijianzhe.ldif  ldap:/etc/
```

