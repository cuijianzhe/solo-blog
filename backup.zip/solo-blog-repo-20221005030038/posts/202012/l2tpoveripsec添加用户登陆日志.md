title: l2tp over ipsec添加用户登陆日志
date: '2020-12-08 18:26:05'
updated: '2020-12-08 18:35:12'
tags: [Linux]
permalink: /articles/2020/12/08/1607423165456.html
---
添加日志：

```bash
[root@ali-prod-ops-vpn ~]# cat  /etc/ppp/ip-up
#!/bin/bash
# This file should not be modified -- make local changes to
# /etc/ppp/ip-up.local instead

PATH=/sbin:/usr/sbin:/bin:/usr/bin
export PATH

LOGDEVICE=$6
REALDEVICE=$1

[ -f /etc/sysconfig/network-scripts/ifcfg-${LOGDEVICE} ] && /etc/sysconfig/network-scripts/ifup-post --realdevice ${REALDEVICE} ifcfg-${LOGDEVICE}

/etc/ppp/ip-up.ipv6to4 ${LOGDEVICE}

[ -x /etc/ppp/ip-up.local ] && /etc/ppp/ip-up.local "$@"

echo "##################################" >> /var/log/pptpd.log
echo "Now User $PEERNAME is connected!!!" >> /var/log/pptpd.log
echo "##################################" >> /var/log/pptpd.log
echo "time: `date -d today +%F_%T`" >> /var/log/pptpd.log
echo "clientIP: $6" >> /var/log/pptpd.log
echo "username: $PEERNAME" >> /var/log/pptpd.log
echo "device: $1" >> /var/log/pptpd.log
echo "vpnIP: $4" >> /var/log/pptpd.log
echo "assignIP: $5" >> /var/log/pptpd.log
exit 0
```

```
[root@ali-prod-ops-vpn ~]# cat  /etc/ppp/ip-down
#!/bin/bash
# This file should not be modified -- make local changes to
# /etc/ppp/ip-down.local instead

PATH=/sbin:/usr/sbin:/bin:/usr/bin
export PATH

LOGDEVICE=$6
REALDEVICE=$1

/etc/ppp/ip-down.ipv6to4 ${LOGDEVICE}

[ -x /etc/ppp/ip-down.local ] && /etc/ppp/ip-down.local "$@"

/etc/sysconfig/network-scripts/ifdown-post --realdevice ${REALDEVICE} \
    ifcfg-${LOGDEVICE}

echo "#####################################" >> /var/log/pptpd.log
echo "Now User $PEERNAME is disconnected!!!" >> /var/log/pptpd.log
echo "#####################################" >> /var/log/pptpd.log
echo "time: `date -d today +%F_%T`" >> /var/log/pptpd.log
echo "clientIP: $6" >> /var/log/pptpd.log
echo "username: $PEERNAME" >> /var/log/pptpd.log
echo "device: $1" >> /var/log/pptpd.log
echo "vpnIP: $4" >> /var/log/pptpd.log
echo "assignIP: $5" >> /var/log/pptpd.log
echo "connect time: $CONNECT_TIME s" >> /var/log/pptpd.log
echo "bytes sent: $BYTES_SENT B" >> /var/log/pptpd.log
echo "bytes rcvd: $BYTES_RCVD B" >> /var/log/pptpd.log
sum_bytes=$(($BYTES_SENT+$BYTES_RCVD))
sum=`echo "scale=2;$sum_bytes/1024/1024"|bc`
echo "bytes sum: $sum MB" >> /var/log/pptpd.log
ave=`echo "scale=2;$sum_bytes/1024/$CONNECT_TIME"|bc`
echo "average speed: $ave KB/s" >> /var/log/pptpd.log
exit 0
```

### 搭建

https://github.com/hwdsl2/setup-ipsec-vpn/blob/master/README-zh.md

