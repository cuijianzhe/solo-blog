title: python练习作业
date: '2019-06-05 14:35:35'
updated: '2019-06-05 15:44:07'
tags: [python]
permalink: /articles/2019/06/05/1559716535382.html
---
# 作业1：BMI计算输出
> BMI指数(Body Mass Index) 以称身体质量指数
    BMI值计算公式: BMI = 体重(公斤) / 身高的平方(米)
例如:
    一个人69公斤，身高是173公分
    BMI = 69 / 1.73**2 = 23.05
标准表:
    BMI < 18.5   体重过轻
    18.5 <= BMI < 24 体重正常
    BMI > 24  体重过重
要求: 输入身高的体重，打印出BMI的值并打印体重状况

```python
#!/bin/python3

Height = float(input('请输入身高(米)：'))
Weight = float(input('请输入体重(公斤)：'))
BMI =  Weight / Height **2
print('%.2f'%BMI)
if BMI < 18.5:
   print('您的体重过轻，BMI值为：%.2f' %BMI)
elif  BMI < 24:
   print('您的体重正常，BMI值为：%.2f'%BMI)
else:
   print('您的体重过重，BMI值为：%.2f'%BMI)
```