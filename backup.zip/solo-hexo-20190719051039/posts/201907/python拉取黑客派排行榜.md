title: python拉取黑客派排行榜
date: '2019-07-18 19:31:48'
updated: '2019-07-18 19:31:48'
tags: [待分类]
permalink: /articles/2019/07/18/1563449508471.html
---
虽然没什么用，学习阶段，练手。

```
import requests
import re
html =  requests.get('https://hacpai.com/top/general').text
result = re.findall('class="fn-flex-1".*?aria-name="(.*?)".*?href="(.*?)".*?',html,flags=re.S)
paihang_str = str(result)
with open('paihangbang.txt','w+',encoding='utf-8') as f:
    f.write(paihang_str)
```