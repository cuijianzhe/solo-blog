title: windows下实现黑客派自动签到
date: '2019-07-19 17:06:02'
updated: '2019-10-31 20:23:40'
tags: [Python]
permalink: /articles/2019/07/19/1563527162900.html
---
![](https://img.hacpai.com/bing/20190130.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 工具预览
* **Chrome浏览器，版本最好大于v71**
* **chromedriver**
* **selenium**

### 下载chromedriver
需要翻墙，地址为`http://chromedriver.chromium.org/downloads`,找到符合自己浏览器版本的chromedriver驱动，下载解压后，将chromedriver.exe文件放到Python目录下的Scripts目录下。[我已下载75版本](https://xyt.cjzshilong.cn/chromedriver_win32.zip)

### 安装selenium
`pip install selenium`

### 有界面
```
# -*- coding: utf-8 -*-

import time 
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

#myusername = "XXX"#登录账号
#mypassword = "XXX"#登录密码


driver = webdriver.Chrome() #模拟浏览器打开网站
driver.get("https://hacpai.com/login")
#driver.maximize_window() #将窗口最大化

try:
    driver.find_element_by_xpath('/html/body/div[1]/div/div[1]/div/div[1]/div[5]/div').click()
    #定位语句去源码中找
    time.sleep(2)#延时加载

    #找到登录框，输入账号密码
    driver.find_element_by_xpath("//*[@id='nameOrEmail']").send_keys("xxx")
    driver.find_element_by_xpath("//*[@id='loginPassword']").send_keys("xxx")


    #模拟点击登录
    driver.find_element_by_xpath("//*[@id='loginBtn']").click()
    time.sleep(2)

    # #模拟登陆后点击签到界面
    driver.get('https://hacpai.com/activity/checkin')
    #time.sleep(2)

    # #模拟点击签到
    driver.find_element_by_xpath('/html/body/div[1]/div[1]/div[1]/div[1]/div[1]/a').click()
    # 定位语句去源码中找
except:
    print("签到失败")
    driver.quit#退出
```
### 无界面后台运行，不确定是否支持linux
```
# -*- coding: utf-8 -*-
import time 
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options

#myusername = "XXX"#登录账号
#mypassword = "XXX"#登录密码

chrome_options = Options()
#加上下面两行，解决报错
chrome_options.add_argument('--no-sandbox')
chrome_options.add_argument('--disable-dev-shm-usage')
chrome_options.add_argument('window-size=1920x3000') #指定浏览器分辨率
chrome_options.add_argument('--disable-gpu') #谷歌文档提到需要加上这个属性来规避bug
chrome_options.add_argument('--hide-scrollbars') #隐藏滚动条, 应对一些特殊页面
chrome_options.add_argument('blink-settings=imagesEnabled=false')
#不加载图片, 提升速度
chrome_options.add_argument('--headless')
#浏览器不提供可视化页面. linux下如果系统不支持可视化不加这条会启动失败
# chrome_options.binary_location =
# r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" #手动指定使用的浏览器位置

driver = webdriver.Chrome(chrome_options=chrome_options) #模拟浏览器打开网站

#driver = webdriver.Chrome() #模拟浏览器打开网站
driver.get("https://hacpai.com/login")
#driver.maximize_window() #将窗口最大化

try:
    driver.find_element_by_xpath('/html/body/div[1]/div/div[1]/div/div[1]/div[5]/div').click()
    #定位语句去源码中找
    time.sleep(2)#延时加载

    #找到登录框，输入账号密码
    driver.find_element_by_xpath("//*[@id='nameOrEmail']").send_keys("xxx")
    driver.find_element_by_xpath("//*[@id='loginPassword']").send_keys("xxx")


    #模拟点击登录
    driver.find_element_by_xpath("//*[@id='loginBtn']").click()
    time.sleep(2)

    # #模拟登陆后点击签到界面
    driver.get('https://hacpai.com/activity/checkin')
    #time.sleep(2)

    # #模拟点击签到
    driver.find_element_by_xpath('/html/body/div[1]/div[1]/div[1]/div[1]/div[1]/a').click()
    # 定位语句去源码中找
except:
    print("签到失败")
    driver.quit#退出
```
