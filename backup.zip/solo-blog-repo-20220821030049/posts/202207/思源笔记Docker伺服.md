title: 思源笔记Docker伺服
date: '2022-07-10 21:36:53'
updated: '2022-07-10 21:36:53'
tags: [思源]
permalink: /articles/2022/07/10/1657460213914.html
---
服务端使用Docker版思源进行伺服搭建配置
[镜像地址](https://hub.docker.com/r/b3log/siyuan)

启动参数：

```
docker run \
  --detach \
  --name siyuan \
  -v /data/siyuan:/data/siyuan \
  -p 6806:6806 \
  -u 1000:1000  b3log/siyuan \
  --ssl=true \
  --resident=true \
  --lang=zh_CN \
  --workspace=/data/siyuan/
```

nginx反代，需要配置反代websocket，以下配置HTTPS和wss

```
upstream siyuan {
      server 127.0.0.1:6806;  # ip + 端口
}

map $http_upgrade $conn_upgrade {
      default upgrade;
      '' close;
    }
        
server {
      listen 80;
      listen 443 ssl;
      server_name siyuan.cjzshilong.cn;
      access_log   /var/log/nginx/siyuan.cjzshilong.cn_access.log log_json;
      error_log    /var/log/nginx/siyuan.cjzshilong.cn_error.log   error;

      ssl_certificate      /usr/local/nginx/conf/ssl/siyuan.cjzshilong.cn_bundle.crt;
      ssl_certificate_key  /usr/local/nginx/conf/ssl/siyuan.cjzshilong.cn.key;

      ssl_session_timeout 5m;
      ssl_protocols TLSv1 TLSv1.1 TLSv1.2;

    location / {
        proxy_set_header   X-Real-IP $remote_addr;
        proxy_set_header   Host      $http_host;
        proxy_pass         http://siyuan;
	proxy_http_version 1.1;
	proxy_set_header Upgrade $http_upgrade;
    	proxy_set_header Connection $conn_upgrade;
    	proxy_set_header X-real-ip $remote_addr;
        proxy_set_header X-Forwarded-For $remote_addr;
      }

}
```

http反向代理配置：

```
upstream siyuan {
      server 127.0.0.1:6806;  # ip + 端口
}
map $http_upgrade $connection_upgrade {
             default upgrade;
             '' close;
       }

server {
            listen 80;
            server_name siyuan.cjzshilong.cn;
            location / {
                proxy_pass  http://siyuan;  #请求转向 siyuan 定义的服务器列表
                proxy_http_version 1.1;
                proxy_set_header Upgrade $http_upgrade;
                proxy_set_header Connection $connection_upgrade;
            }
}
```

