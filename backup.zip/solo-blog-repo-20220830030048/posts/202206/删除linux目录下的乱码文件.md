title: 删除linux目录下的乱码文件？
date: '2022-06-24 15:53:09'
updated: '2022-06-24 15:53:09'
tags: [Linux]
permalink: /articles/2022/06/24/1656057189511.html
---
可以肯定得是删除文件名乱码得文件不直接用文件名，现有一种删除方法，留作记录。

```
# 1.查看文件的inode号
[root@devops-monitor ~]# ls -il 
total 49920
528760 -rw-r--r-- 1 root root        0 Jun 23 22:42 ?
523298 drwxr-xr-x 3 root root     4096 Jun 24 13:16 files
523297 -rw-r--r-- 1 root root     1875 Mar 24 15:13 hosts
523295 -rw-r--r-- 1 root root      600 Mar 25 15:11 hosts-wai
523277 drwxr-xr-x 2 root root     4096 Sep 24  2021 logs
529325 -rw-r--r-- 1 root root     1241 May 20 01:07 MegaSAS.log
523294 -rw-r--r-- 1 root root     6403 Apr 28 17:15 startminer.sh
528904 -rw-r--r-- 1 root root        2 Jun 24 01:14 tmp_f_data.log
523296 -rw-r--r-- 1 root root 51072900 Jun 24 01:14 tmp_instance_info.log
528880 -rw-r--r-- 1 root root        0 May 17 11:42 ʴ??V?7ъnc??
528893 -rw-r--r-- 1 root root        0 Jun 23 22:42 ??x??

#2. 根据查找得inode号打印出乱码得文件名
[root@devops-monitor ~]# find ./ -inum 528760
./?

#3. 通过exec 删除文件名乱码得文件
find ./ -inum 528760 -exec rm -i {} \;
```

