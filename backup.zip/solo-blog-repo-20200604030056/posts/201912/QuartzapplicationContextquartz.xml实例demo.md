title: Quartz    applicationContext-quartz.xml 实例demo
date: '2019-12-06 18:04:44'
updated: '2019-12-06 18:04:44'
tags: [java]
permalink: /articles/2019/12/06/1575626684620.html
---
![](https://img.hacpai.com/bing/20191202.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

```xml
<?xml version="1.0" encoding="UTF-8"?>  
<beans xmlns="http://www.springframework.org/schema/beans"  
   	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
   	xmlns:p="http://www.springframework.org/schema/p"
	xmlns:aop="http://www.springframework.org/schema/aop" 
	xmlns:context="http://www.springframework.org/schema/context"
	xmlns:jee="http://www.springframework.org/schema/jee"
	xmlns:tx="http://www.springframework.org/schema/tx"
    xsi:schemaLocation="  
        http://www.springframework.org/schema/aop http://www.springframework.org/schema/aop/spring-aop.xsd
		http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd
		http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context.xsd
		http://www.springframework.org/schema/jee http://www.springframework.org/schema/jee/spring-jee.xsd
		http://www.springframework.org/schema/tx http://www.springframework.org/schema/tx/spring-tx.xsd"
		default-autowire="byName" default-lazy-init="true">  

    <bean id="quartzJob" class="com.ulane.ulink.job.quartz.QuartzJob"/>




	<!-- demo1分钟读取一次 -->
    <bean name="demoTestDetail"
          class="org.springframework.scheduling.quartz.JobDetailFactoryBean">
        <property name="jobClass">
        	<value>com.ulane.ulink.job.quartz.JobStoreTXQuartzJobBean</value>
        </property> 
        
        <property name="jobDataAsMap">
			<map>
				 <entry key="targetObject" value="quartzJob" />
				 <entry key="targetMethod" value="demoTest" />
			</map>
		</property>
    	<property name="durability" value="true" />
    </bean>

    <bean id="demoTestTrigger" class="org.springframework.scheduling.quartz.CronTriggerFactoryBean">
        <property name="jobDetail" ref="demoTestDetail"/>
        <property name="cronExpression" value="0 * *  * * ?"/>
    </bean>






    <bean name="monitorLoginUserDetail"
          class="org.springframework.scheduling.quartz.JobDetailFactoryBean">
        <property name="jobClass">
            <value>com.ulane.ulink.job.quartz.JobStoreTXQuartzJobBean</value>
        </property>

        <property name="jobDataAsMap">
            <map>
                <entry key="targetObject" value="quartzJob" />
                <entry key="targetMethod" value="monitorLoginUserData" />
            </map>
        </property>
        <property name="durability" value="true" />
    </bean>

    <!-- 清理过期token，5分钟执行一次-->
    <bean id="monitorLoginUserTrigger" class="org.springframework.scheduling.quartz.CronTriggerFactoryBean">
        <property name="jobDetail" ref="monitorLoginUserDetail"/>
        <property name="cronExpression" value="0 0/5 *  * * ?"/>
    </bean>






    <bean name="syncHuaWeiBaseInfoDetail"
          class="org.springframework.scheduling.quartz.JobDetailFactoryBean">
        <property name="jobClass">
            <value>com.ulane.ulink.job.quartz.JobStoreTXQuartzJobBean</value>
        </property>

        <property name="jobDataAsMap">
            <map>
                <entry key="targetObject" value="quartzJob" />
                <entry key="targetMethod" value="syncHuaWeiBaseInfo" />
            </map>
        </property>
        <property name="durability" value="true" />
    </bean>

    <!-- 同步华为基础数据，1天执行一次-->
    <bean id="syncHuaWeiBaseInfoTrigger" class="org.springframework.scheduling.quartz.CronTriggerFactoryBean">
        <property name="jobDetail" ref="syncHuaWeiBaseInfoDetail"/>
        <property name="cronExpression" value="0 0 0 * * ?"/>
        <property name="priority" value="10"></property>
    </bean>





    <bean name="queryDataAt5000Ms"
          class="org.springframework.scheduling.quartz.JobDetailFactoryBean">
        <property name="jobClass">
            <value>com.ulane.ulink.job.quartz.JobStoreTXQuartzJobBean</value>
        </property>

        <property name="jobDataAsMap">
            <map>
                <entry key="targetObject" value="quartzJob"/>
                <entry key="targetMethod" value="queryDataAt5000Ms"/>
            </map>
        </property>
        <property name="durability" value="true" />
    </bean>

    <bean id="queryDataAt5000MsTrigger" class="org.springframework.scheduling.quartz.CronTriggerFactoryBean">
        <property name="jobDetail" ref="queryDataAt5000Ms"/>
        <property name="cronExpression" value="0/5 * * * * ? "/>
        <property name="priority" value="4"></property>
    </bean>



    <bean name="queryDataAt2700000Ms"
          class="org.springframework.scheduling.quartz.JobDetailFactoryBean">
        <property name="jobClass">
            <value>com.ulane.ulink.job.quartz.JobStoreTXQuartzJobBean</value>
        </property>

        <property name="jobDataAsMap">
            <map>
                <entry key="targetObject" value="quartzJob"/>
                <entry key="targetMethod" value="queryDataAt2700000Ms"/>
            </map>
        </property>
        <property name="durability" value="true" />
    </bean>

    <bean id="queryDataAt2700000MsTrigger" class="org.springframework.scheduling.quartz.CronTriggerFactoryBean">
        <property name="jobDetail" ref="queryDataAt2700000Ms"/>
        <property name="cronExpression" value="0 0/45 * * * ? "/>
        <property name="priority" value="5"></property>
    </bean>




    <!-- 总管理类 如果将lazy-init='false'那么容器启动就会执行调度程序 context.getBean("startQuertz"); -->
    <bean id="startQuartz" lazy-init="true" autowire="no"
          class="org.springframework.scheduling.quartz.SchedulerFactoryBean">
        <property name="triggers">
            <list>
                <ref bean="demoTestTrigger"/>
                <ref bean="queryDataAt5000MsTrigger"/>
                <ref bean="queryDataAt2700000MsTrigger"/>
                <ref bean="monitorLoginUserTrigger"/>
                <ref bean="syncHuaWeiBaseInfoTrigger"/>
            </list>
        </property>
        <property name="startupDelay" value="30"/>
        <property name="dataSource" ref="dataSource" />
		<property name="applicationContextSchedulerContextKey" value="applicationContext" />
		<property name="configLocation" value="classpath:quartz.properties" />
		<property name="overwriteExistingJobs" value="true"/>
    </bean>
  
</beans>
```


需要注意的是，当配置为`<property name="dataSource" ref="dataSource" />`来缓存`quartz`使用的数据，当清理的时候需要手动删除数据库里的表数据。
* QRTZ_CRON_TRIGGERS
* QRTZ_JOB_DETAILS
* QRTZ_TRIGGERS
