title: zabbix自动发现华为AC6605管理AP状态以及连接数
date: '2019-08-05 14:49:26'
updated: '2020-07-01 14:58:01'
tags: [Linux, zabbix]
permalink: /articles/2019/08/05/1564987766272.html
---
**先把需要用的snmp的oid值获取到手。😰 具体的MIB文件官网上查找即可：**![image.png](https://img.hacpai.com/file/2019/08/image-a6c13673.png)
**yum安装：**
zabbix运行脚本目录：`/usr/lib/zabbix/externalscripts`
zabbix配置文件目录：`/etc/zabbix/zabbix_agentd.d`
**本地源码编译安装：**
zabbix运行脚本目录：`/usr/local/zabbix/share/zabbix/externalscripts`
zabbix配置文件目录：`/usr/local/zabbix/etc/zabbix_agentd.conf.d`

## 一、编写ap自动发现脚本：

### shell脚本实例：

```bash
[root@zabbix /usr/local/zabbix/share/zabbix/externalscripts]# cat apdiscovery.sh 
#!/bin/bash

id=$(snmpwalk -v 2c -c limi@2018  10.200.250.5 1.3.6.1.4.1.2011.6.139.13.3.10.1.5 | cut -f1 -d "=" | cut -f10 -d ".")
id_array=(${id})
sum=$(snmpwalk -v 2c -c limi@2018  10.200.250.5 1.3.6.1.4.1.2011.6.139.13.3.10.1.5 | wc -l) 
name=$(snmpwalk -v 2c -c limi@2018  10.200.250.5 enterprises.2011.6.139.13.3.10.1.5 | awk  '{print $4}' | sed 's/"//g')
name_array=($name)

printf '{\"data\":[ '
for ((i=0;i<$sum;i++))
do 
    printf "{\"{#APID}\":\"${id_array[$i]}\",\"{#APNAME}\":\"${name_array[$i]}\" }"
      
    if [ $i -lt $[ $sum-1 ] ];then
	printf ','
	fi
done
printf " ]}"
```

### python3脚本实例

```python
#!/bin/env python3
import json
import os
import sys
import subprocess
def discovery():
    CMD_name = '''snmpwalk -v 2c -c limi@2018  10.200.250.5 enterprises.2011.6.139.13.3.10.1.5 | awk  '{print $4}' | sed 's/"//g' '''
    CMD_id = 'snmpwalk -v 2c -c limi@2018  10.200.250.5 1.3.6.1.4.1.2011.6.139.13.3.10.1.5 | cut -f1 -d "=" | cut -f10 -d "."'
    ap_id = subprocess.getoutput(CMD_id)
    ap_name = subprocess.getoutput(CMD_name)
   #print(ap_id)
    id_list = ap_id.split("\n") #把AP的id每行数据添加到列表
    name_list = ap_name.split("\n")
    AP_list = list(zip(id_list,name_list))
    ap_dict = {}
    for v in AP_list:
        ap_dict[v[0]] = v[1]
    return ap_dict

#格式化成适合zabbix lld的json数据
if __name__ == "__main__":
    ap_value = discovery()
    ap_list = []
    for key in ap_value:
        ap_list += [{'{#APID}':key,'{#APNAME}':ap_value[key]}]
    #print(ap_list)
    print(json.dumps({'data':ap_list},sort_keys=True,indent=4,separators=(',',':')))

```

在目录/etc/zabbix/zabbix_agentd.d里面创建monitor_wlan.conf 文件

```bash
UserParameter=wlan.alive,/usr/local/zabbix/share/zabbix/externalscripts/monitor_wlan.sh
```

取出AP-id和ap-name
![image.png](https://img.hacpai.com/file/2019/09/image-e994c25c.png)

![image.png](https://img.hacpai.com/file/2019/08/image-eee3f2d7.png)

AP状态脚本：（需要把自动发现脚本（apdiscovery）里面的参数ap-id传参进来）

```bash
[root@zabbix /usr/local/zabbix/share/zabbix/externalscripts]# cat ap_status.sh 
#!/bin/bash
apid=$1
snmpwalk -v 2c -c limi@2018  10.200.250.5 1.3.6.1.4.1.2011.6.139.13.3.10.1.7.${apid} | awk '{print $4}'
```

AP连接用户数脚本：

```bash
[root@zabbix /usr/local/zabbix/share/zabbix/externalscripts]# cat apuser.sh 
#!/bin/bash
apid=$1
snmpwalk -v 2c -c limi@2018  10.200.250.5 1.3.6.1.4.1.2011.6.139.13.3.10.1.45.${apid} | awk '{print $4}'
```

例如：

![image.png](https://img.hacpai.com/file/2019/08/image-6d461848.png)

## 二、配置zabbix_agentd的配置目录里面的脚本关系：

```bash
[root@zabbix /usr/local/zabbix/etc/zabbix_agentd.conf.d]# cat discoveryapid.conf 
UserParameter=discovery_apid,/usr/local/zabbix/share/zabbix/externalscripts/apdiscovery.sh
UserParameter=discoveryapuser[*],/usr/local/zabbix/share/zabbix/externalscripts/apuser.sh $1
UserParameter=ap.status[*],/usr/local/zabbix/share/zabbix/externalscripts/ap_status.sh $1
```

## 三、zabbix里面的配置：

1. 创建一个模板：
   ![image.png](https://img.hacpai.com/file/2019/08/image-7b68489b.png)

2.创建自动发现规则：
![image.png](https://img.hacpai.com/file/2019/08/image-cb1af057.png)
里面配置如下：
![image.png](https://img.hacpai.com/file/2019/08/image-0b3b0798.png)

3.配置监控项原型：
![image.png](https://img.hacpai.com/file/2019/08/image-cd010809.png)

![image.png](https://img.hacpai.com/file/2019/08/image-a1485af4.png)

4.设置触发器：
![image.png](https://img.hacpai.com/file/2019/08/image-35fbdb99.png)

![image.png](https://img.hacpai.com/file/2019/08/image-1e53f5ab.png)

5. 新建主机：
   ![image.png](https://img.hacpai.com/file/2019/08/image-a0d93ccf.png)
   绑定模板：
   ![image.png](https://img.hacpai.com/file/2019/08/image-b70694e4.png)

**等待几分钟后便可出来结果（AP上下行速率自动发现同理）：**
![image.png](https://img.hacpai.com/file/2019/08/image-b8b64fc0.png)

**报警内容:**

![image.png](https://b3logfile.com/file/2020/07/image-a08c8f3b.png)

