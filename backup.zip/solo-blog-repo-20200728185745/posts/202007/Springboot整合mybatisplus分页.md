title: Springboot整合mybatis-plus分页
date: '2020-07-28 11:58:05'
updated: '2020-07-28 13:48:06'
tags: [java]
permalink: /articles/2020/07/28/1595908685910.html
---
引入相关依赖

```
<dependency>
			<groupId>com.github.pagehelper</groupId>
			<artifactId>pagehelper-spring-boot-starter</artifactId>
			<version>1.2.3</version>
			<exclusions>
				<exclusion>
					<groupId>org.mybatis</groupId>
					<artifactId>mybatis</artifactId>
				</exclusion>
				<exclusion>
					<groupId>org.mybatis</groupId>
					<artifactId>mybatis-spring</artifactId>
				</exclusion>
			</exclusions>
		</dependency>
		<!-- Mybatis-plus -->
		<dependency>
			<groupId>com.baomidou</groupId>
			<artifactId>mybatis-plus-boot-starter</artifactId>
			<version>3.1.0</version>
		</dependency>
```

读取mapper路径

```
mybatis-plus :
  mapper-locations: classpath:mapper/*Mapper.xml
  type-aliases-package: com.jianwei
```

在mapper类上声明此类是一个mapper,也可以在application启动类上添加mapperscan

```
@Mapper
public interface UploadFileMapper
```

配置分页属性

```
pagehelper:
  helper-dialect : mysql
  reasonable : true
  support-methods-arguments : true
  pageSizeZero : true
  params : count=countSql
```

使用分页


```
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

	PageHelper.startPage(pageNo, pageSize);
        List<UploadFile> list = uploadFileService.findList(new UploadFile());
        PageInfo pageInfo = new PageInfo<>(list);
```

