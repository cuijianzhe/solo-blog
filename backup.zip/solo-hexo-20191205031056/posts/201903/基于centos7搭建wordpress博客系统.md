title: 基于centos7搭建wordpress博客系统
date: '2019-03-05 22:11:10'
updated: '2019-11-16 15:25:34'
tags: [wordpress, 博客搭建]
permalink: /articles/2019/03/05/1551795070444.html
---
![](https://img.hacpai.com/bing/20171116.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 



---
### 搭建环境：linux+nginx+mysql+php
---

1、系统版本：
![centos.png](https://img.hacpai.com/file/2019/03/centos-637a0426.png)
2、软件版本：（目前中文版最新5.0.3）


参考网站：
1、wordpress官网： https://wordpress.org/ 
2、下载地址： https://wordpress.org/download/

### 搭建过程

1、下载完，对wordpress.tar.gz进行解压

`[root@localhost ~]# tar xf wordpress-5.0.3-zh_CN.tar.gz -C /usr/local/nginx/html/`  将wordpress软件整体解压到nginx根目录

2、针对wordpress在系统内新建mysql用户，并且授权

```bash
mysql> CREATE DATABASE wordpress;   # 创建wordpress库
Query OK, 1 row affected (0.00 sec)

mysql> GRANT ALL PRIVILEGES ON wordpress.* TO "wordpress"@"localhost"
    -> IDENTIFIED BY "wordpress";         # 给wordpress授权并且设置密码
Query OK, 0 rows affected (0.02 sec)

mysql> FLUSH PRIVILEGES;
#刷新权限
Query OK, 0 rows affected (0.00 sec)

mysql> show databases;
   
+--------------------+
| Database           |
+--------------------+
| information_schema |
| mysql              |
| performance_schema |
| wordpress          |
+--------------------+
4 rows in set (0.02 sec)

mysql> exit
Bye
 
```
之后可直接打开web服务进行安装：
`http://192.168.1.5/wordpress/wp-admin/setup-config.php`

![wordpress.png](https://img.hacpai.com/file/2019/03/wordpress-ca8d1cf0.png)

下一步
![shujuku.png](https://img.hacpai.com/file/2019/03/shujuku-277fdac6.png)

下一步 提示报错，手动创建，将框内的配置信息粘贴到php文件中
![chuangjian.png](https://img.hacpai.com/file/2019/03/chuangjian-f53c1e8a.png)

`[root@localhost ~]# vim /usr/local/nginx/html/wordpress/wp-config.php`


下一步
![zhandian.png](https://img.hacpai.com/file/2019/03/zhandian-4123443e.png)

如下便是安装成功
![chenggong.png](https://img.hacpai.com/file/2019/03/chenggong-82edb519.png)

最后直接访问即可，自定义设置个性化内容
![wordpress1.png](https://img.hacpai.com/file/2019/03/wordpress1-b31034db.png)

![guohui.png](https://img.hacpai.com/file/2019/11/guohui-e67e7b3b.png)






