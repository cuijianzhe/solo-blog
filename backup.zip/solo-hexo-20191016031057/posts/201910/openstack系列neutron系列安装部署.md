title: openstack系列-neutron系列安装部署
date: '2019-10-15 10:01:16'
updated: '2019-10-15 14:52:29'
tags: [linux, openstack]
permalink: /articles/2019/10/15/1571104876779.html
---
# [neutron 部署](https://docs.openstack.org/neutron/rocky/install/controller-install-rdo.html)

## mysql 库创建

```
CREATE DATABASE neutron;
 GRANT ALL PRIVILEGES ON neutron.* TO 'neutron'@'localhost' \
  IDENTIFIED BY 'neutron';
GRANT ALL PRIVILEGES ON neutron.* TO 'neutron'@'%' \
  IDENTIFIED BY 'neutron';
```

## 创建服务凭据

*  创建 neutron 用户

```bash
[root@linux-node1 ~]# . admin-openrc 
[root@linux-node1 ~]# openstack user create --domain default --password-prompt neutron
User Password:
Repeat User Password:
+---------------------+----------------------------------+
| Field               | Value                            |
+---------------------+----------------------------------+
| domain_id           | default                          |
| enabled             | True                             |
| id                  | c0ce9b3d5a134ad08ce402c7528b1e91 |
| name                | neutron                          |
| options             | {}                               |
| password_expires_at | None                             |
+---------------------+----------------------------------+
```

* 向 neutron 用户添加管理员角色

```
openstack role add --project service --user neutron admin
```

* 创建neutron服务实体
```bash
[root@linux-node1 ~]# openstack service create --name neutron \
>   --description "OpenStack Networking" network
+-------------+----------------------------------+
| Field       | Value                            |
+-------------+----------------------------------+
| description | OpenStack Networking             |
| enabled     | True                             |
| id          | bf1996ceb1d846deb8af3b208f2ff4e1 |
| name        | neutron                          |
| type        | network                          |
+-------------+----------------------------------+
```

## 创建网络服务API endpoint
```bash
[root@linux-node1 ~]#   openstack endpoint create --region RegionOne \
>   network public http://10.200.51.100:9696
+--------------+----------------------------------+
| Field        | Value                            |
+--------------+----------------------------------+
| enabled      | True                             |
| id           | 5ef730844dab4c4c9c348a003b1cb8f7 |
| interface    | public                           |
| region       | RegionOne                        |
| region_id    | RegionOne                        |
| service_id   | bf1996ceb1d846deb8af3b208f2ff4e1 |
| service_name | neutron                          |
| service_type | network                          |
| url          | http://10.200.51.100:9696        |
+--------------+----------------------------------+
[root@linux-node1 ~]#   openstack endpoint create --region RegionOne \
>   network internal http://10.200.51.100:9696

+--------------+----------------------------------+
| Field        | Value                            |
+--------------+----------------------------------+
| enabled      | True                             |
| id           | 89e583655b7c4446892cb58dcc40152a |
| interface    | internal                         |
| region       | RegionOne                        |
| region_id    | RegionOne                        |
| service_id   | bf1996ceb1d846deb8af3b208f2ff4e1 |
| service_name | neutron                          |
| service_type | network                          |
| url          | http://10.200.51.100:9696        |
+--------------+----------------------------------+
[root@linux-node1 ~]#   
[root@linux-node1 ~]#    openstack endpoint create --region RegionOne \
>   network admin http://10.200.51.100:9696
+--------------+----------------------------------+
| Field        | Value                            |
+--------------+----------------------------------+
| enabled      | True                             |
| id           | 9abfbfb1288f40c7a92845ffcb6c3d8e |
| interface    | admin                            |
| region       | RegionOne                        |
| region_id    | RegionOne                        |
| service_id   | bf1996ceb1d846deb8af3b208f2ff4e1 |
| service_name | neutron                          |
| service_type | network                          |
| url          | http://10.200.51.100:9696        |
+--------------+----------------------------------+
```
## 配置网络选项
> Choose one of the following networking options to configure services specific to it. Afterwards, return here and proceed to [Configure the metadata agent](https://docs.openstack.org/neutron/rocky/install/controller-install-rdo.html#neutron-controller-metadata-agent-rdo).
* [Networking Option 1: Provider networks](https://docs.openstack.org/neutron/rocky/install/controller-install-option1-rdo.html)
* [Networking Option 2: Self-service networks](https://docs.openstack.org/neutron/rocky/install/controller-install-option2-rdo.html)

选项1部署了最简单的架构，该架构仅支持将实例附加到提供商（外部）网络。没有自助（私有）网络，路由器或浮动IP地址。只有该`admin`特权用户或其他特权用户才能管理提供商网络。
```
yum install openstack-neutron openstack-neutron-ml2 \
  openstack-neutron-linuxbridge ebtables -y
```
### 编辑 `/etc/neutron/neutron.conf`文件
* 在[database]部分中，配置数据库访问：
```
[database]
connection = mysql+pymysql://neutron:neutron@10.200.51.100/neutron
```

* 在[DEFAULT]部分中
```bash
[DEFAULT]
#启用模块化层2（ml2）插件并禁用其他插件
core_plugin = ml2
service_plugins =
#配置rabbitmq消息队列访问
transport_url = rabbit://openstack:openstack@10.200.51.100
auth_strategy = keystone
```
* 在[default]和[keystone_authToken]部分中，配置标识服务访问：
```bash
[keystone_authtoken]
www_authenticate_uri = http://10.200.51.100:5000
auth_url = http://10.200.51.100:5000
memcached_servers = 10.200.51.100:11211
auth_type = password
project_domain_name = default
user_domain_name = default
project_name = service
username = neutron
password = 598941324
```
* 在[default]和[nova]部分中，配置networking以通知compute网络拓扑更改
```
[DEFAULT]
notify_nova_on_port_status_changes = true
notify_nova_on_port_data_changes = true
```
```
[nova]
auth_url = http://10.200.51.100:5000
auth_type = password
project_domain_name = default
user_domain_name = default
region_name = RegionOne
project_name = service
username = nova
password = 598941324
```
* 在[oslo_concurrency]部分中，配置锁路径
```
[oslo_concurrency]
lock_path = /var/lib/neutron/tmp
```
### 配置模块化第2层（ML2）插件
####配置 /etc/neutron/plugins/ml2/ml2_conf.ini
* 在[ML2]部分中，启用平面和VLAN网络
```
[ml2]
type_drivers = flat,vlan
```
* 在[ML2]部分中，禁用自助服务网络
```
[ml2]
tenant_network_types =
```
* 在[ml2]部分中，启用Linux网桥机制
```
[ml2]
mechanism_drivers = linuxbridge
```
> After you configure the ML2 plug-in, removing values in the `type_drivers` option can lead to database inconsistency.
* 在[ML2]部分中，启用端口安全扩展驱动程序：
```
[ml2]
extension_drivers = port_security
```
* 在[ml2_type_flat]部分中，将提供商虚拟网络配置为平面网络
```
[ml2_type_flat]
# ...
flat_networks = provider
```
* 在[SecurityGroup]部分中，启用IPset以提高安全组规则的效率
```
[securitygroup]
# ...
enable_ipset = true
```
#### 配置Linux网桥代理
编辑/etc/neutron/plugins/ml2/linuxbridge_agent.ini

* 在[Linux_Bridge]部分中，将提供程序虚拟网络映射到提供程序物理网络接口：
```
[linux_bridge]
physical_interface_mappings = provider:ens33
```
* 在[vxlan]部分，禁用vxlan覆盖网络：
```
[vxlan]
enable_vxlan = false
```
* 在[SecurityGroup]部分中，启用安全组并配置Linux网桥iptables防火墙驱动程序：
```
[securitygroup]
enable_security_group = true
firewall_driver = neutron.agent.linux.iptables_firewall.IptablesFirewallDriver
```
* 通过验证以下所有sysctl值均设置为1，确保Linux操作系统内核支持网络桥筛选器
```bash
vim /etc/sysctl.conf
#...
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
```
```bash
[root@linux-node1 ~]# sysctl -p 
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
```
### 配置DHCP代理
 编辑`/etc/neutron/dhcp_agent.ini`文件
* 在[默认]部分中，配置Linux网桥接口驱动程序dnsmasq dhcp驱动程序，并启用隔离元数据，以便提供程序网络上的实例可以通过网络访问元数据：
```
[DEFAULT]
# ...
interface_driver = linuxbridge
dhcp_driver = neutron.agent.linux.dhcp.Dnsmasq
enable_isolated_metadata = true
```
###  [Networking Option 2: Self-service networks](https://docs.openstack.org/neutron/rocky/install/controller-install-option2-rdo.html)

网络配置选项2：

### 配置元数据代理
* 在[DEFAULT]部分中，配置元数据主机和共享密钥：

```
[DEFAULT]
nova_metadata_host = 10.200.51.100
metadata_proxy_shared_secret = 598941324
```

###  将计算服务配置为使用网络服务

* 编辑/etc/nova/nova.conf文件
```
[neutron]
url = http://10.200.51.100:9696
auth_url = http://10.200.51.100:5000
auth_type = 598941324
project_domain_name = default
user_domain_name = default
region_name = RegionOne
project_name = service
username = neutron
password = 598941324
service_metadata_proxy = true
metadata_proxy_shared_secret = 598941324
```
### 最后安装
* 网络服务初始化脚本需要一个指向ml2插件配置文件/etc/neutron/plugins/ml2/ml2_conf.ini的符号链接/etc/neutron/plugins.ini。如果此符号链接不存在，则使用以下命令创建它：
```
ln -s /etc/neutron/plugins/ml2/ml2_conf.ini /etc/neutron/plugin.ini
```
### 填充数据库：
```
su -s /bin/sh -c "neutron-db-manage --config-file /etc/neutron/neutron.conf \
  --config-file /etc/neutron/plugins/ml2/ml2_conf.ini upgrade head" neutron
```
* 重新启动计算API服务：
```
systemctl restart openstack-nova-api.service
```
* 启动网络服务并将其配置为在系统启动时启动。对于两种网络选项：
```
# systemctl enable neutron-server.service \
  neutron-linuxbridge-agent.service neutron-dhcp-agent.service \
  neutron-metadata-agent.service
# systemctl start neutron-server.service \
  neutron-linuxbridge-agent.service neutron-dhcp-agent.service \
  neutron-metadata-agent.service
```
~~对于网络选项2，还启用并启动第3层服务~~
```
# systemctl enable neutron-l3-agent.service
# systemctl start neutron-l3-agent.service
```
> 这里我是第一种

# [neutron计算节点安装](https://docs.openstack.org/neutron/rocky/install/compute-install-rdo.html)
```
yum install openstack-neutron-linuxbridge ebtables ipset
```
## 配置公共组件
```
[DEFAULT]
transport_url = rabbit://openstack:openstack@10.200.51.100
```
* 在[default]和[keystone_authToken]部分中，配置标识服务访问：
```
[DEFAULT]
# ...
auth_strategy = keystone

[keystone_authtoken]
www_authenticate_uri = http://10.200.51.100:5000
auth_url = http://10.200.51.100:5000
memcached_servers = 10.200.51.100:11211
auth_type = password
project_domain_name = default
user_domain_name = default
project_name = service
username = neutron
password = 598941324
```
* 在[oslo_concurrency]部分中，配置锁路径：
```
[oslo_concurrency]
lock_path = /var/lib/neutron/tmp
```
## 配置网络选项
Choose the same networking option that you chose for the controller node to configure services specific to it. Afterwards, return here and proceed to [Configure the Compute service to use the Networking service](https://docs.openstack.org/neutron/rocky/install/compute-install-rdo.html#neutron-compute-compute-rdo).

* [Networking Option 1: Provider networks](https://docs.openstack.org/neutron/rocky/install/compute-install-option1-rdo.html)
* [Networking Option 2: Self-service networks](https://docs.openstack.org/neutron/rocky/install/compute-install-option2-rdo.html)

### [](https://docs.openstack.org/neutron/rocky/install/compute-install-option1-rdo.html)

#### 配置Linux网桥代理
编辑 `/etc/neutron/plugins/ml2/linuxbridge_agent.ini`文件
* [Linux_Bridge]部分中，将提供程序虚拟网络映射到提供程序物理网络接口
```
[linux_bridge]
physical_interface_mappings = provider:ens33
```
* 在[vxlan]部分，禁用vxlan覆盖网络：
```
[vxlan]
enable_vxlan = false
```
* 在[SecurityGroup]部分中，启用安全组并配置Linux网桥iptables防火墙驱动程序：
```
[securitygroup]
# ...
enable_security_group = true
firewall_driver = neutron.agent.linux.iptables_firewall.IptablesFirewallDriver
```
* 通过验证以下所有sysctl值均设置为1，确保Linux操作系统内核支持网络桥筛选器：
```
[root@linux-node2 ~]# modprobe br_netfilter
[root@linux-node2 ~]# ls /proc/sys/net/bridge
bridge-nf-call-arptables  bridge-nf-call-iptables        bridge-nf-filter-vlan-tagged
bridge-nf-call-ip6tables  bridge-nf-filter-pppoe-tagged  bridge-nf-pass-vlan-input-dev
```
```
vim /etc/sysctl.conf 
net.bridge.bridge-nf-call-ip6tables = 1 
net.bridge.bridge-nf-call-iptables = 1
```
使其生效
```
[root@linux-node2 ~]# sysctl -p
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
```
* 编辑/etc/nova/nova.conf文件并完成以下操作：

```
[neutron]
url = http://10.200.51.100:9696
auth_url = http://10.200.51.100:5000
auth_type = password
project_domain_name = default
user_domain_name = default
region_name = RegionOne
project_name = service
username = neutron
password = 598941324
```
### [第二种网络方法选项](https://docs.openstack.org/neutron/rocky/install/compute-install-option2-rdo.html)

暂不使用
## 完成安装
* 重启

```
systemctl restart openstack-nova-compute.service
```
* 启动Linux网桥代理并将其配置为在系统引导时启动
```
systemctl enable neutron-linuxbridge-agent.service 
systemctl start neutron-linuxbridge-agent.service
```
## [验证操作](https://docs.openstack.org/neutron/rocky/install/verify.html)
* 列出neutron验证成功的代理
```
[root@linux-node1 ~]# openstack network agent list
+--------------------------------------+--------------------+-------------+-------------------+-------+-------+---------------------------+
| ID                                   | Agent Type         | Host        | Availability Zone | Alive | State | Binary                    |
+--------------------------------------+--------------------+-------------+-------------------+-------+-------+---------------------------+
| 3a300c2c-73dd-4ddd-b8af-2e39b54846b5 | Metadata agent     | linux-node1 | None              | :-)   | UP    | neutron-metadata-agent    |
| 5ad73cc8-8a6d-4fcb-a630-7fb52722f2a8 | Linux bridge agent | linux-node1 | None              | :-)   | UP    | neutron-linuxbridge-agent |
| aa8498be-1f4e-4151-b9ed-50b474e49e28 | Linux bridge agent | linux-node2 | None              | :-)   | UP    | neutron-linuxbridge-agent |
| dfcc05c5-2a57-49ee-9013-8097d8ecb854 | DHCP agent         | linux-node1 | nova              | :-)   | UP    | neutron-dhcp-agent        |
+--------------------------------------+--------------------+-------------+-------------------+-------+-------+---------------------------+
```






