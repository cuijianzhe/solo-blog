title: openstack系列- keystone部署文档
date: '2019-10-11 15:05:11'
updated: '2019-10-13 23:17:53'
tags: [openstack, linux]
permalink: /articles/2019/10/11/1570777511550.html
---
# 一、环境

## 基础环境设置  
###  主机名修改：
```
hostnamectl set-hostname linux-node1
```

修改host文件
```
10.200.51.100 linux-node1 linux-node1.limi.com
10.200.51.31 linux-node2 linux-node2.limi.com
```
> linux-node1  10.200.51.100   控制节点
linux-node2  10.200.51.31  计算节点

* [配置网络yum源：](https://opsx.alibaba.com/mirror?lang=zh-CN)
```
wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repo
sed -i  's/$releasever/7.7.1908/g' /etc/yum.repos.d/CentOS-Base.repo
```
###  NTP服务安装
```
yum install chrony -y
timedatectl set-timezone Asia/Shanghai  #配置时区
```
```
vim /etc/chrony.conf
...
allow 10.200.0.0/16
```
```
# systemctl enable chronyd.service
# systemctl start chronyd.service
```


> 更新内核后，重新启动机器

###  [OpenStack 包安装](https://docs.openstack.org/install-guide/environment-packages.html)
```  
yum install centos-release-openstack-stein -y  
yum upgrade  
```
```
yum install python-openstackclient
```
###  [SQL database安装](https://docs.openstack.org/install-guide/environment-sql-database.html)
```
yum install mariadb mariadb-server python2-PyMySQL -y
```
添加openstack配置文件
```shell
[root@linux-node1 my.cnf.d]# cat /etc/my.cnf.d/openstack.cnf 
[mysqld]
bind-address = 0.0.0.0

default-storage-engine = innodb
innodb_file_per_table = on
max_connections = 4096
collation-server = utf8_general_ci
character-set-server = utf8
```
```
# systemctl enable mariadb.service
# systemctl start mariadb.service
```
> 修改maridb初始密码
```
mysql_secure_installation
```
###  [Message queue消息队列](https://docs.openstack.org/install-guide/environment-messaging.html)

```
yum install rabbitmq-server -y
# systemctl enable rabbitmq-server.service
# systemctl start rabbitmq-server.service
```
创建openstack用户
```shell
[root@linux-node1 ~]#  rabbitmqctl add_user openstack openstack 
Creating user "openstack"
[root@linux-node1 ~]# rabbitmqctl set_permissions openstack ".*" ".*" ".*"
Setting permissions for user "openstack" in vhost "/"

```
[rabbitmqctl命令参考](https://www.rabbitmq.com/rabbitmqctl.8.html#set_user_tags)
`rabbitmq-plugins list` 查看rabbitmq插件列表
`rabbitmq-plugins enable rabbitmq_management` 开启web管理功能
`rabbitmqctl  list_users` 查看用户列表
`rabbitmqctl  set_user_tags admin administrator`  修改用户角色

### [Memcached库安装](https://docs.openstack.org/install-guide/environment-memcached.html)

```
 yum install memcached python-memcached
```
```shell
[root@linux-node1 ~]# cat !$
cat /etc/sysconfig/memcached
PORT="11211"
USER="memcached"
MAXCONN="1024"
CACHESIZE="64"
OPTIONS="-l 0.0.0.0,::1"    #此处授权主机允许所有的
[root@linux-node1 ~]# systemctl start memcached.service 
[root@linux-node1 ~]# systemctl enable memcached.service 
```
###  [Etcd安装](https://docs.openstack.org/install-guide/environment-etcd.html)
```
# yum install etcd
```
**配置**
```shell
[root@linux-node1 ~]# grep -v "^#\|^$" /etc/etcd/etcd.conf 
ETCD_DATA_DIR="/var/lib/etcd/default.etcd"
ETCD_LISTEN_PEER_URLS="http://10.200.51.100:2380"
ETCD_LISTEN_CLIENT_URLS="http://10.200.51.100:2379"
ETCD_NAME="controller"
ETCD_INITIAL_ADVERTISE_PEER_URLS="http://10.200.51.100:2380"
ETCD_ADVERTISE_CLIENT_URLS="http://10.200.51.100:2379"
ETCD_INITIAL_CLUSTER="controller=http://10.200.51.100:2380"
ETCD_INITIAL_CLUSTER_TOKEN="etcd-cluster-01"
ETCD_INITIAL_CLUSTER_STATE="new"
```
```
[root@linux-node1 ~]# systemctl start etcd
[root@linux-node1 ~]# systemctl enable  etcd
```
# 二、安装openstack服务
## 2.1 [Keystone 安装](https://docs.openstack.org/keystone/rocky/install/index-rdo.html)
 
### 配置keystone库
```
CREATE DATABASE keystone;
GRANT ALL PRIVILEGES ON keystone.* TO 'keystone'@'localhost' \
  IDENTIFIED BY 'keystone';
GRANT ALL PRIVILEGES ON keystone.* TO 'keystone'@'%' \
  IDENTIFIED BY 'keystone';
```
```
yum install openstack-keystone httpd mod_wsgi -y
```
>  /etc/keystone/keystone.conf 配置进行修改
```
[database]
...
connection = mysql+pymysql://keystone:keystone@10.200.51.100/keystone
```
```
[token]
...
provider = fernet
```
>  [keystone令牌三种生成方式](https://www.cnblogs.com/dhplxf/p/7966890.html)

* 同步数据库：
```
su -s /bin/sh -c "keystone-manage db_sync" keystone
```
* 初始化FERNET密钥存储库：
```
# keystone-manage fernet_setup --keystone-user keystone --keystone-group keystone
# keystone-manage credential_setup --keystone-user keystone --keystone-group keystone
```
* 创建bootstrap服务
``` 
  keystone-manage bootstrap --bootstrap-password 598941324 \
--bootstrap-admin-url http://10.200.51.100:5000/v3 \
--bootstrap-internal-url http://10.200.51.100:5000/v3 \
--bootstrap-public-url http://10.200.51.100:5000/v3 \
--bootstrap-region-id RegionOne 
```
* 配置http服务
```bash
vim /etc/httpd/conf/httpd.conf 
...
ServerName 10.200.51.100:80
```
配置软链接
```
ln -s /usr/share/keystone/wsgi-keystone.conf /etc/httpd/conf.d/
```
* 配置SSL

* 配置环境变量：(#此密码用boostrap中的密码)
```
export OS_USERNAME=admin
export OS_PASSWORD=598941324
export OS_PROJECT_NAME=admin
export OS_USER_DOMAIN_NAME=Default
export OS_PROJECT_DOMAIN_NAME=Default
export OS_AUTH_URL=http://10.200.51.100:5000/v3
export OS_IDENTITY_API_VERSION=3
```
###  创建域、角色、用户和项目
* 创建mystack域
```shell
[root@linux-node1 ~]# openstack domain create --description "mystack" mystack
+-------------+----------------------------------+
| Field       | Value                            |
+-------------+----------------------------------+
| description | mystack                          |
| enabled     | True                             |
| id          | 4cbe80fad0b7460c8a7220fc63c0f130 |
| name        | mystack                          |
| tags        | []                               |
+-------------+----------------------------------+
```
* 创建myproject、service、demo项目
```shell
[root@linux-node1 ~]# openstack project create --domain default \
>   --description "Demo Project" myproject
+-------------+----------------------------------+
| Field       | Value                            |
+-------------+----------------------------------+
| description | Demo Project                     |
| domain_id   | default                          |
| enabled     | True                             |
| id          | 7728319b685d4e5fb8aa8c9274fcb4b5 |
| is_domain   | False                            |
| name        | myproject                        |
| parent_id   | default                          |
| tags        | []                               |
+-------------+----------------------------------+

[root@linux-node1 ~]# openstack project create --domain default \
> --description "Service Project" service
+-------------+----------------------------------+
| Field       | Value                            |
+-------------+----------------------------------+
| description | Service Project                  |
| domain_id   | default                          |
| enabled     | True                             |
| id          | 50b9efa71e704582ad667a8b98b5b770 |
| is_domain   | False                            |
| name        | service                          |
| parent_id   | default                          |
| tags        | []                               |
+-------------+----------------------------------+
[root@linux-node1 ~]# openstack project create --domain default \
> --description "Demo Project" demo
+-------------+----------------------------------+
| Field       | Value                            |
+-------------+----------------------------------+
| description | Demo Project                     |
| domain_id   | default                          |
| enabled     | True                             |
| id          | 4291d582710e407aa7abc46a64f2da57 |
| is_domain   | False                            |
| name        | demo                             |
| parent_id   | default                          |
| tags        | []                               |
+-------------+----------------------------------+
```
* 创建用户(myuser、demo)
```shell
[root@linux-node1 ~]# openstack user create --domain default \
>   --password-prompt myuser
User Password:
Repeat User Password:
+---------------------+----------------------------------+
| Field               | Value                            |
+---------------------+----------------------------------+
| domain_id           | default                          |
| enabled             | True                             |
| id                  | 618ce6c96aa7462a9a2300d05379443f |
| name                | myuser                           |
| options             | {}                               |
| password_expires_at | None                             |
+---------------------+----------------------------------+
[root@linux-node1 ~]# openstack user create --domain default \
> --password-prompt demo
User Password:
Repeat User Password:
+---------------------+----------------------------------+
| Field               | Value                            |
+---------------------+----------------------------------+
| domain_id           | default                          |
| enabled             | True                             |
| id                  | 9f702ce3021741918ad7b9e4ec63daff |
| name                | demo                             |
| options             | {}                               |
| password_expires_at | None                             |
+---------------------+----------------------------------+

```
> password:598941324

* 创建demo、myrole角色
```shell
[root@linux-node1 ~]# openstack role create demo
+-------------+----------------------------------+
| Field       | Value                            |
+-------------+----------------------------------+
| description | None                             |
| domain_id   | None                             |
| id          | f1b8bcab82964e3e8255d7ae4ababc0f |
| name        | demo                             |
+-------------+----------------------------------+
[root@linux-node1 ~]# openstack role create myrole
+-------------+----------------------------------+
| Field       | Value                            |
+-------------+----------------------------------+
| description | None                             |
| domain_id   | None                             |
| id          | 1c425ddc2b7c4e9eacd2e561697eca90 |
| name        | myrole                           |
+-------------+----------------------------------+
```
* 将myrole角色添加到myproject项目和myuser用户：
```shell
[root@linux-node1 ~]# openstack role add --project myproject --user myuser myrole
```
* 作为上一节中创建的demo、myuser用户，请求身份验证令牌：
> 命令
```
   openstack --os-auth-url http://10.200.51.100:5000/v3 \
--os-project-domain-name default \
--os-user-domain-name default \
--os-project-name demo \
--os-username admin token issue
```
```shell
[root@linux-node1 ~]#  openstack --os-auth-url http://10.200.51.100:5000/v3 \
> --os-project-domain-name default \
> --os-user-domain-name default \
> --os-project-name demo \
> --os-username demo token issue
Password: 
+------------+-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
| Field      | Value                                                                                                                                                                                   |
+------------+-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
| expires    | 2019-10-11T11:14:12+0000                                                                                                                                                                |
| id         | gAAAAABdoFX01swIecvosowJi-oGV8Y5fTHmPiGY4OtsAV2p1f0fkOWgc88v8QwmZtnKF83b501CTWBqdnIx1A78ZCN3SWufOHni24JVk1PP06JMzvtw8LFslGwYiJxtHCinCyxhW5fM9F3CxMYBGcq1xfRnkCV3PDJmoNCDS9ds8IdDREmXceQ |
| project_id | 4291d582710e407aa7abc46a64f2da57                                                                                                                                                        |
| user_id    | 9f702ce3021741918ad7b9e4ec63daff                                                                                                                                                        |
+------------+-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+

[root@linux-node1 ~]#    openstack --os-auth-url http://10.200.51.100/v3 \
> --os-project-domain-name default \
> --os-user-domain-name default \
> --os-project-name myproject \
> --os-username myuser token issue
Password: 
+------------+-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
| Field      | Value                                                                                                                                                                                   |
+------------+-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
| expires    | 2019-10-11T11:21:30+0000                                                                                                                                                                |
| id         | gAAAAABdoFeqLzi8NPoEwyiFAdbUhnZjVFS8avXsns9eQRWBFlPbouQfZOizXhh_cYn7iLMDmsrhL-d-Bw6UfjB4tB-PnowYcxckWhN3hEFSfd0gGbu9SzK3HUyNfw1pGuJ3E67Wxy7E_NR8QRMVG4yuooO-H-Y71-SCeNqAv1ak__xK4cBb54g |
| project_id | 7728319b685d4e5fb8aa8c9274fcb4b5                                                                                                                                                        |
| user_id    | 618ce6c96aa7462a9a2300d05379443f                                                                                                                                                        |
+------------+-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
```
* 创建用户脚本：
```shell
[root@linux-node1 ~]# cat admin-openrc 
export OS_PROJECT_DOMAIN_NAME=Default
export OS_USER_DOMAIN_NAME=Default
export OS_PROJECT_NAME=admin
export OS_USERNAME=admin
export OS_PASSWORD=598941324
export OS_AUTH_URL=http://10.200.51.100:5000/v3
export OS_IDENTITY_API_VERSION=3
export OS_IMAGE_API_VERSION=2
```
* 脚本验证：
```shell
[root@linux-node1 ~]# . admin-openrc
[root@linux-node1 ~]# openstack token issue
+------------+-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
| Field      | Value                                                                                                                                                                                   |
+------------+-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
| expires    | 2019-10-11T11:42:06+0000                                                                                                                                                                |
| id         | gAAAAABdoFx-gay2U7zVQHXIrVY4tYHvUzKc3XyLaB6VPgpjKEY3PjOfzSe81Wo7OdqHR4bC_KyPgJLtvEiz-YY-l46drqRRADDql4-I0Nf1sl2yfp7uaQNjokpJiRBi76JUhdpDEOMdeFEnLm3R0t4WO86a0fKDZIbkoM7ChKX4QkvoL7-6ce4 |
| project_id | 4291d582710e407aa7abc46a64f2da57                                                                                                                                                        |
| user_id    | 9f702ce3021741918ad7b9e4ec63daff                                                                                                                                                        |
+------------+-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
```


