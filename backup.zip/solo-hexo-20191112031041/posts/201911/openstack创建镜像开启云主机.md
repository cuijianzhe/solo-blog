title: openstack创建镜像，开启云主机
date: '2019-11-07 15:22:42'
updated: '2019-11-08 09:33:36'
tags: [openstack, Linux]
permalink: /articles/2019/11/07/1573111362693.html
---

# 创建虚拟机

## 基本环境
* 查看自己的CPU是否支持全虚拟化虚拟化技术且是64位的
Inter：
```
cat /proc/cpuinfo | grep --color vmx
```
AMD：
```
cat /proc/cpuinfo | grep --color svm
```
看看flag有没有上面的vmx或者是svm，有的话就是支持全虚拟化技术

## 安装KVM
* 安装KVM模块、管理工具和libvirt，命令行安装：
```
yum install qemu-kvm libvirt libguestfs-tools virt-install virt-manager libvirt-python -y
```
注：
> qemu-kvm ： kvm主程序， KVM虚拟化模块
> virt-manager： KVM图形化管理工具
> libvirt： 虚拟化服务
> libguestfs-tools : 虚拟机的系统管理工具
> virt-install ： 安装虚拟机的实用工具 。比如 virt-clone克隆工具就是这个包安装的
> libvirt-python ： python调用libvirt虚拟化服务的api接口库文件

* 查看安装完ＫＶＭ后的服务：
```
systemctl start libvirtd
systemctl enable libvirtd
systemctl is-enabled libvirtd
```

* 确定正确加载kvm 模块
```
[root@cinder ~]# lsmod | grep kvm
kvm_intel             188644  0 
kvm                   621480  1 kvm_intel
irqbypass              13503  1 kvm
```
## [创建网桥接口](http://rpmfind.net/linux/RPM/centos/7.6.1810/x86_64/Packages/bridge-utils-1.5-9.el7.x86_64.html)
```
rpm -ivh /mnt/Packages/bridge-utils-1.5-9.el7.x86_64.rpm
```
* 把enp61s0f0绑到br0桥设备上：
```
[root@ceph3 ~]# cat  /etc/sysconfig/network-scripts/ifcfg-enp61s0f0
TYPE=Ethernet
PROXY_METHOD=none
BROWSER_ONLY=no
BOOTPROTO=static
DEFROUTE=yes
IPV4_FAILURE_FATAL=no
IPV6INIT=yes
IPV6_AUTOCONF=yes
IPV6_DEFROUTE=yes
IPV6_FAILURE_FATAL=no
IPV6_ADDR_GEN_MODE=stable-privacy
NAME=enp61s0f0
UUID=7aca621d-6b78-4d78-9dd6-c088bad7b44b
DEVICE=enp61s0f0
ONBOOT=yes
BRIDGE="br0"
```
* 生成桥设备的配置文件：
```
[root@ceph3 ~]# cat /etc/sysconfig/network-scripts/ifcfg-br0 
DEVICE="br0"
NM_CONTROLLED="yes"
ONBOOT="yes"
TYPE="Bridge"
BOOTPROTO=none
IPADDR=192.168.51.208
NETMASK=255.255.255.0
GATEWAY=192.168.51.1
DNS1=10.200.50.209
DNS2=223.5.5.5
```
```
systemctl restart network
```
> 注：TYPE="Bridge" ， Ｂ要大写

* 查看桥接网口状态
```
[root@ceph3 ~]# brctl show
bridge name	bridge id		STP enabled	interfaces
br0		8000.346b5b29809b	no		enp61s0f0
virbr0		8000.525400fb5e54	yes		virbr0-nic
```

> virbr0是一种虚拟网络接口，是一种虚拟网络接口，这由于安装和启用了 libvirt libvirtlibvirt libvirtd 服务后 会自动 生成一个桥接设备，名字为virbr0。libvirtd在服务器上生成一个virtual network switch,KVM中的所有虚拟机都是通过virbr0连接的。


## 使用命令：virt-manager 建立虚拟机

*创建一个分区：
```
fdisk /dev/mapper/centos-data
mkfs.xfs /dev/mapper/centos-data
mount /dev/mapper/centos-data /var/lib/libvirt/images/
```
执行 virt-manager 进行创建虚拟机
```
[root@cinder ~]# virt-manager
```
~~之后的步骤省略~~

* 常用命令：
> virsh list     #列出在运行的虚拟机
> virsh start centos7.0    #启动centos7.0虚拟机
> virsh shutdown centos7.0
> virsh autostart centos7.0

## 创建镜像
```
[root@controller ~]# ll
-rw-------. 1 root root 10739318784 Nov  6 04:45 centos7.0.qcow2
-rw-r--r--. 1 root root   700143616 Aug  8 09:30 Centos.qcow2
```
```
openstack image create "Centos7.7" \
  --file centos7.0.qcow2 \
  --disk-format qcow2 --container-format bare \
  --public
```
```
[root@controller ~]# cd /var/lib/docker/volumes/glance/_data/images/
[root@controller images]# ll
total 12769116
-rw-r-----. 1 42415 42415   700143616 Nov  6 20:38 043bb24a-7fac-4b5d-9592-da099f649e75
-rw-r-----. 1 42415 42415  1623392256 Nov  6 20:43 1b82de8c-1d3b-4d68-8d8f-23dad6fa7cad
-rw-r-----. 1 42415 42415    12716032 Nov  2 20:23 4992fc52-b1e1-4a5d-88af-1c7c8ac94d9c
-rw-r-----. 1 42415 42415 10739318784 Nov  6 04:53 d6acb85e-bfe1-4ec1-9e95-3504005e0ee4
```

# 创建云主机
* 查看镜像列表
```
[root@controller ~]# openstack image list 
+--------------------------------------+-----------+--------+
| ID                                   | Name      | Status |
+--------------------------------------+-----------+--------+
| 1b82de8c-1d3b-4d68-8d8f-23dad6fa7cad | 111       | active |
| 043bb24a-7fac-4b5d-9592-da099f649e75 | 1907      | active |
| d6acb85e-bfe1-4ec1-9e95-3504005e0ee4 | Centos7.7 | active |
| 4992fc52-b1e1-4a5d-88af-1c7c8ac94d9c | cirros    | active |
+--------------------------------------+-----------+--------+
```
* 创建实例
```
[root@controller ~]# openstack server create     --image Centos7.7     --flavor m1.small     --key-name mykey     --network demo-net     cuijianzhe
+-------------------------------------+--------------------------------------------------+
| Field                               | Value                                            |
+-------------------------------------+--------------------------------------------------+
| OS-DCF:diskConfig                   | MANUAL                                           |
| OS-EXT-AZ:availability_zone         |                                                  |
| OS-EXT-SRV-ATTR:host                | None                                             |
| OS-EXT-SRV-ATTR:hypervisor_hostname | None                                             |
| OS-EXT-SRV-ATTR:instance_name       |                                                  |
| OS-EXT-STS:power_state              | NOSTATE                                          |
| OS-EXT-STS:task_state               | scheduling                                       |
| OS-EXT-STS:vm_state                 | building                                         |
| OS-SRV-USG:launched_at              | None                                             |
| OS-SRV-USG:terminated_at            | None                                             |
| accessIPv4                          |                                                  |
| accessIPv6                          |                                                  |
| addresses                           |                                                  |
| adminPass                           | KjDjkU67ViyA                                     |
| config_drive                        |                                                  |
| created                             | 2019-11-07T06:48:38Z                             |
| flavor                              | m1.small (2)                                     |
| hostId                              |                                                  |
| id                                  | d5506d7e-bd2f-43e6-9f56-99eea1a80eb1             |
| image                               | Centos7.7 (d6acb85e-bfe1-4ec1-9e95-3504005e0ee4) |
| key_name                            | mykey                                            |
| name                                | cuijianzhe                                       |
| progress                            | 0                                                |
| project_id                          | fda196dacffd4f35b3c3118035edff0e                 |
| properties                          |                                                  |
| security_groups                     | name='default'                                   |
| status                              | BUILD                                            |
| updated                             | 2019-11-07T06:48:38Z                             |
| user_id                             | 5afd82c446e64186918b911e1f587388                 |
| volumes_attached                    |                                                  |
+-------------------------------------+--------------------------------------------------+
```
* 查看实例列表
```
[root@controller ~]# openstack server list
+--------------------------------------+------------+--------+-------------------------------------+-----------+----------+
| ID                                   | Name       | Status | Networks                            | Image     | Flavor   |
+--------------------------------------+------------+--------+-------------------------------------+-----------+----------+
| d5506d7e-bd2f-43e6-9f56-99eea1a80eb1 | cuijianzhe | ACTIVE | demo-net=10.0.0.113                 | Centos7.7 | m1.small |
| 95a188ae-cab9-4708-9b0b-d4e46a007261 | demo2      | ACTIVE | demo-net=10.0.0.111, 192.168.50.173 | 111       | m1.small |
| 8302d488-66e3-4f97-a8d2-592fad8fae83 | demo2      | ACTIVE | demo-net=10.0.0.222, 192.168.50.218 | 1907      | m1.small |
| 1c4c6ba2-7a76-4207-a534-c7dbacf6a883 | demo1      | ACTIVE | demo-net=10.0.0.199, 192.168.50.172 | cirros    | m1.tiny  |
+--------------------------------------+------------+--------+-------------------------------------+-----------+----------+
```

**创建云主机实例**：
```
创建实例：
openstack server create     --image 1907     --flavor m1.small     --key-name mykey     --network demo-net     demo2
```
## 挂载卷
![image.png](https://img.hacpai.com/file/2019/11/image-a0e4fe9b.png)


```
[root@host-10-0-0-113 ~]# mkfs.xfs /dev/vdb 
meta-data=/dev/vdb               isize=512    agcount=4, agsize=655360 blks
         =                       sectsz=512   attr=2, projid32bit=1
         =                       crc=1        finobt=0, sparse=0
data     =                       bsize=4096   blocks=2621440, imaxpct=25
         =                       sunit=0      swidth=0 blks
naming   =version 2              bsize=4096   ascii-ci=0 ftype=1
log      =internal log           bsize=4096   blocks=2560, version=2
         =                       sectsz=512   sunit=0 blks, lazy-count=1
realtime =none                   extsz=4096   blocks=0, rtextents=0
[root@host-10-0-0-113 ~]# mount /dev/vdb /data
[root@host-10-0-0-113 ~]# df -h 
Filesystem               Size  Used Avail Use% Mounted on
devtmpfs                 908M     0  908M   0% /dev
tmpfs                    919M     0  919M   0% /dev/shm
tmpfs                    919M  8.5M  911M   1% /run
tmpfs                    919M     0  919M   0% /sys/fs/cgroup
/dev/mapper/centos-root  8.0G  1.2G  6.9G  15% /
/dev/vda1               1014M  149M  866M  15% /boot
tmpfs                    184M     0  184M   0% /run/user/0
/dev/vdb                  10G   33M   10G   1% /data
```
