title: Django 添加ldap认证细节注意
date: '2020-12-26 15:27:15'
updated: '2020-12-26 15:44:31'
tags: [Python]
permalink: /articles/2020/12/26/1608967635869.html
---
# 项目地址

https://github.com/etianen/django-python3-ldap

# LDAP

为什么说呢？django认挣这里，亏在公司的ldap没有cn认证用户，导致同步用户时一直失败，所以添加一个cn用户。

如果不添加cn查找用户会出现同步时出现如下报错：

```
LDAP bind failed: LDAPInvalidCredentialsResult - 49 - invalidCredentials - None - None - bindResponse - None
CommandError: Could not connect to LDAP server
```

添加admin Generic: Posix Group (posixGroup)，并且增加password属性，用于登录查找

![image.png](https://b3logfile.com/file/2020/12/image-67c609a7.png)

```python
### LDAP

# The URL of the LDAP server.
LDAP_AUTH_URL = "ldap://172.16.16.4:389"
# Initiate TLS on connection.
LDAP_AUTH_USE_TLS = False

# The LDAP search base for looking up users.
LDAP_AUTH_SEARCH_BASE = "ou=manager,dc=limikeji,dc=com"
# The LDAP class that represents a user.
LDAP_AUTH_OBJECT_CLASS = "inetOrgPerson"

# User model fields mapped to the LDAP
# attributes that represent them.
LDAP_AUTH_USER_FIELDS = {
    "username": "uid",
    "first_name": "sn",
    "last_name": "sn",
    "email": "mail",
}

# A tuple of django model fields used to uniquely identify a user.
LDAP_AUTH_USER_LOOKUP_FIELDS = ("username",)

# Path to a callable that takes a dict of {model_field_name: value},
# returning a dict of clean model data.
# Use this to customize how data loaded from LDAP is saved to the User model.
LDAP_AUTH_CLEAN_USER_DATA = "django_python3_ldap.utils.clean_user_data"
LDAP_AUTH_SYNC_USER_RELATIONS = "django_python3_ldap.utils.sync_user_relations"
LDAP_AUTH_FORMAT_SEARCH_FILTERS = "django_python3_ldap.utils.format_search_filters"
LDAP_AUTH_FORMAT_USERNAME = "django_python3_ldap.utils.format_username_openldap"


# The LDAP username and password of a user for querying the LDAP database for user
# details. If None, then the authenticated user will be used for querying, and
# the `ldap_sync_users` command will perform an anonymous query.
#同步用户：python manage.py ldap_sync_users

LDAP_AUTH_CONNECTION_USERNAME = 'cuijianzhe'
LDAP_AUTH_CONNECTION_PASSWORD = '97583758032750875'

AUTHENTICATION_BACKENDS = {"django_python3_ldap.auth.LDAPBackend",'django.contrib.auth.backends.ModelBackend',}
```

## 同步用户

```
python manager.py ldap_sync_users
```

