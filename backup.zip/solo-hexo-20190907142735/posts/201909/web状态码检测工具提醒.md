title: web状态码检测工具提醒
date: '2019-09-07 11:24:38'
updated: '2019-09-07 13:42:20'
tags: [linux]
permalink: /articles/2019/09/07/1567826678848.html
---
最近换了一款新皮肤[solo-nexmoe](https://github.com/InkDP/solo-nexmoe)，但是无奈一直间歇性报500，但是访问有时有时好的，所以找了一个脚本检测500出现的时间，第一时间去看情况。

```bash
#!/bin/bash

URL=https://www.cjzshilong.cn
DING_URL=https://oapi.dingtalk.com/robot/send?access_token=e9a9fbc7a68cd17db9f5eeb1165efcb5525f8543a4697e4eac64920198a4afb3

function SendMessageToDingding(){ 
    curl "${DING_URL}" -H 'Content-Type: application/json' -d "
    {
        \"actionCard\": {
            \"title\": \"o(╥﹏╥)o故障啦\", 
            \"text\": \"Web地址: $URL\n\n状态码: $1\n\n响应时间：${REQUEST_TIME}秒\n\n当前时间：${DT}\n\n\",
            \"hideAvatar\": \"0\", 
            \"btnOrientation\": \"0\", 
            \"btns\": [
            {
                \"title\": \"URL地址链接\", 
                \"actionURL\": \"$URL\"
            }
        ]
        }, 
        \"msgtype\": \"actionCard\"
    }"
} 

function httpRequest()
{
    DT=$(date)
    CODE=$(echo `curl -o /dev/null -s -m 10 --connect-timeout 10 -w %{http_code} "$URL"`)
    REQUEST_TIME=$(curl -o /dev/null -s -w "time_connect: %{time_connect}\ntime_starttransfer: %{time_starttransfer}\ntime_total: %{time_total}\n" "$URL" | awk /time_total/ | awk -F ': ' '{print $2}')
    if [[ "$REQUEST_TIME" > "2" ]] || [[ "$CODE" -ne 200 ]];then
         SendMessageToDingding $CODE
    else
         :
    fi
}

httpRequest
step=5
while true
do
    httpRequest
    sleep $step
done

```
后台运行此脚本，触发规则发送[钉钉消息到自定义机器人](https://ding-doc.dingtalk.com/doc#/serverapi2/qf2nxq)。
![image.png](https://img.hacpai.com/file/2019/09/image-77d78bb7.png)

在此，也希望 @InkDP 能够给看下是不是还存在小漏洞，我得环境就是docker没其他设置了。

