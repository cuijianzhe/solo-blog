title: 我在 GitHub 上的开源项目
date: '2019-06-17 05:00:24'
updated: '2019-09-04 22:43:32'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [solo-blog](https://github.com/cuijianzhe/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/cuijianzhe/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`3`](https://github.com/cuijianzhe/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/cuijianzhe/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://www.cjzshilong.cn`](https://www.cjzshilong.cn "项目主页")</span>

✍️ 邯城往事 -                >>>  展颜笑夙愿，一笑泯恩仇 <<<



---

### 2. [bolo-blog](https://github.com/cuijianzhe/bolo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/cuijianzhe/bolo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/cuijianzhe/bolo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/cuijianzhe/bolo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://117.50.64.121`](https://117.50.64.121 "项目主页")</span>

✍️ 邯城往事 -                >>>  展颜笑夙愿，一笑泯恩仇 <<<



---

### 3. [work_scripts](https://github.com/cuijianzhe/work_scripts) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/cuijianzhe/work_scripts/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/cuijianzhe/work_scripts/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/cuijianzhe/work_scripts/network/members "分叉数")</span>

my scripts on work



---

### 4. [l2tp-over-ipsec-web-manager](https://github.com/cuijianzhe/l2tp-over-ipsec-web-manager) <kbd title="主要编程语言">CSS</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/cuijianzhe/l2tp-over-ipsec-web-manager/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/cuijianzhe/l2tp-over-ipsec-web-manager/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/cuijianzhe/l2tp-over-ipsec-web-manager/network/members "分叉数")</span>





---

### 5. [cuijianzhe.github.io](https://github.com/cuijianzhe/cuijianzhe.github.io) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/cuijianzhe/cuijianzhe.github.io/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/cuijianzhe/cuijianzhe.github.io/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/cuijianzhe/cuijianzhe.github.io/network/members "分叉数")&nbsp;&nbsp;[🏠`https://cuijianzhe.github.io`](https://cuijianzhe.github.io "项目主页")</span>

Solo 导出的静态站点。



---

### 6. [L2TP-OVER-IPSEC-ManagerWeb](https://github.com/cuijianzhe/L2TP-OVER-IPSEC-ManagerWeb) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/cuijianzhe/L2TP-OVER-IPSEC-ManagerWeb/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/cuijianzhe/L2TP-OVER-IPSEC-ManagerWeb/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/cuijianzhe/L2TP-OVER-IPSEC-ManagerWeb/network/members "分叉数")</span>





---

### 7. [Django_study](https://github.com/cuijianzhe/Django_study) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/cuijianzhe/Django_study/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/cuijianzhe/Django_study/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/cuijianzhe/Django_study/network/members "分叉数")</span>

Python

