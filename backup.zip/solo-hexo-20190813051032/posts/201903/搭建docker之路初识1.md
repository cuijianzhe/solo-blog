title: 搭建docker之路-初识（1）
date: '2019-03-26 11:39:37'
updated: '2019-03-29 18:18:31'
tags: [linux]
permalink: /articles/2019/03/26/1553571577540.html
---
# 一、 安装docker环境
## 1.1 安装
`[root@host ~]# yum install -y docker`
查看信息：
```
[root@bogon ~]# systemctl start docker 

[root@bogon ~]# systemctl enable  docker 
Created symlink from /etc/systemd/system/multi-user.target.wants/docker.service to /usr/lib/systemd/system/docker.service.
[root@bogon ~]# docker version 
Client:
 Version:         1.13.1
 API version:     1.26
 Package version: docker-1.13.1-94.gitb2f74b2.el7.centos.x86_64
 Go version:      go1.10.3
 Git commit:      b2f74b2/1.13.1
 Built:           Tue Mar 12 10:27:24 2019
 OS/Arch:         linux/amd64

Server:
 Version:         1.13.1
 API version:     1.26 (minimum version 1.12)
 Package version: docker-1.13.1-94.gitb2f74b2.el7.centos.x86_64
 Go version:      go1.10.3
 Git commit:      b2f74b2/1.13.1
 Built:           Tue Mar 12 10:27:24 2019
 OS/Arch:         linux/amd64
 Experimental:    false
```
## 1.2 下载docker镜像

![dockerliucheng.jpg](https://img.hacpai.com/file/2019/03/dockerliucheng-1ea22883.jpg)



```
[root@bogon ~]# docker search centos  //从dockerHub中查找符合条件的镜像
INDEX       NAME                                         DESCRIPTION                                     STARS     OFFICIAL   AUTOMATED
docker.io   docker.io/centos                             The official build of CentOS.                   5270      [OK]       
docker.io   docker.io/ansible/centos7-ansible            Ansible on Centos7                              121                  [OK]
docker.io   docker.io/jdeathe/centos-ssh                 CentOS-6 6.10 x86_64 / CentOS-7 7.5.1804 x...   108                  [OK]
docker.io   docker.io/consol/centos-xfce-vnc             Centos container with "headless" VNC sessi...   83                   [OK]
docker.io   docker.io/imagine10255/centos6-lnmp-php56    centos6-lnmp-php56                              52                   [OK]
docker.io   docker.io/centos/mysql-57-centos7            MySQL 5.7 SQL database server                   49                   
docker.io   docker.io/tutum/centos                       Simple CentOS docker image with SSH access      44                   
docker.io   docker.io/gluster/gluster-centos             Official GlusterFS Image [ CentOS-7 +  Glu...   40                   [OK]
docker.io   docker.io/openshift/base-centos7             A Centos7 derived base image for Source-To...   40                   
docker.io   docker.io/centos/postgresql-96-centos7       PostgreSQL is an advanced Object-Relationa...   37                   
docker.io   docker.io/centos/python-35-centos7           Platform for building and running Python 3...   34                   
docker.io   docker.io/kinogmt/centos-ssh                 CentOS with SSH                                 26                   [OK]
docker.io   docker.io/centos/httpd-24-centos7            Platform for running Apache httpd 2.4 or b...   22                   
docker.io   docker.io/centos/php-56-centos7              Platform for building and running PHP 5.6 ...   20                   
docker.io   docker.io/openshift/jenkins-2-centos7        A Centos7 based Jenkins v2.x image for use...   20                   
docker.io   docker.io/pivotaldata/centos-gpdb-dev        CentOS image for GPDB development. Tag nam...   10                   
docker.io   docker.io/openshift/wildfly-101-centos7      A Centos7 based WildFly v10.1 image for us...   6                    
docker.io   docker.io/openshift/jenkins-1-centos7        DEPRECATED: A Centos7 based Jenkins v1.x i...   4                    
docker.io   docker.io/darksheer/centos                   Base Centos Image -- Updated hourly             3                    [OK]
docker.io   docker.io/pivotaldata/centos                 Base centos, freshened up a little with a ...   3                    
docker.io   docker.io/pivotaldata/centos-mingw           Using the mingw toolchain to cross-compile...   2                    
docker.io   docker.io/blacklabelops/centos               CentOS Base Image! Built and Updates Daily!     1                    [OK]
docker.io   docker.io/openshift/wildfly-81-centos7       A Centos7 based WildFly v8.1 image for use...   1                    
docker.io   docker.io/pivotaldata/centos-gcc-toolchain   CentOS with a toolchain, but unaffiliated ...   1                    
docker.io   docker.io/smartentry/centos                  centos with smartentry                          0 
 ```

 **从公网dockerhub上拉取镜像image**

```
[root@host ~]# docker pull docker.io/centos

Using default tag: latest
Trying to pull repository docker.io/library/centos ... 
latest: Pulling from docker.io/library/centos
8ba884070f61: Pull complete 
Digest: sha256:8d487d68857f5bc9595793279b33d082b03713341ddec91054382641d14db861
Status: Downloaded newer image for docker.io/centos:latest
```
开启NAT转发功能
```
[root@host ~]# vim /etc/sysctl.conf
net.ipv4.ip_forward = 1
//执行sysctl -p生效
[root@host ~]# sysctl -p
net.ipv4.ip_forward = 1
[root@host ~]# systemctl restart docker
[root@host ~]# docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
docker.io/centos    latest              9f38484d220f        11 days ago         202 MB
```   
##  1.3实际应用：     
### 例1：运行一个  container  并加载镜像 centos，运行起来这个实例后，在实例中执行 /bin/bash 命令

```
[root@host ~]# docker run -it docker.io/centos:latest /bin/bash    ##启动一个实例
[root@ff20a65c5b95 /]# ls
anaconda-post.log  bin  dev  etc  home  lib  lib64  media  mnt  opt  proc  root  run  sbin  srv  sys  tmp  usr  var
[root@ff20a65c5b95 /]# cat /etc/redhat-release
CentOS Linux release 7.6.1810 (Core) 
[root@ff20a65c5b95 /]# exit
exit
[root@host ~]# 
```   
docker 常用参数：
run 运行  
-i 以交互模式运行容器，通常不 -t  同时使用；
-t 为容器重新分配一个伪输入终端，通常和 -i 同时使用；

### 例2：在 container 中启动一个长久运行的进程，不断向 stdin 输出  hello world  。模拟一个后台运行的服务

```
[root@bogon ~]# docker run -d docker.io/centos:latest /bin/sh -c  "while  true;do echo hello world; sleep 1; done"

6246ea4f21efb67018894fa78940210236e05d2e2953f942e5666488015b0f31  //容器的ID
```

### 例3：从一个容器中取日志，查看输出的内容，可用于后期检查 docker 实例在标准输出中弹出的错误信息或正常的信息。

语法：  docker logs  容器实例的  Name/ID
```
[root@bogon ~]# docker logs 6246ea4f21efb67018894fa78940210236e05d2e2953f942e5666488015b0f31
hello world
hello world
hello world
hello world
hello world
hello world
hello world
hello world
```
查看正在运行的容器
```
[root@bogon ~]# docker ps

CONTAINER ID        IMAGE                     COMMAND                  CREATED             STATUS              PORTS               NAMES
6246ea4f21ef        docker.io/centos:latest   "/bin/sh -c 'while..."   2 minutes ago       Up 2 minutes                            compassionate_hugle
[root@bogon ~]#  docker ps -a     #-a 列出所有容器（包含沉睡/退出状态的容器）； 
CONTAINER ID        IMAGE                     COMMAND                  CREATED             STATUS                   PORTS               NAMES
6246ea4f21ef        docker.io/centos:latest   "/bin/sh -c 'while..."   3 minutes ago       Up 3 minutes                                 compassionate_hugle
ff20a65c5b95        docker.io/centos:latest   "/bin/bash"              3 hours ago         Exited (0) 3 hours ago                       serene_yalow
```

杀死一个容器
```
[root@bogon ~]# docker kill 6246ea4f21ef

6246ea4f21ef
```
### 例4：启动、停止、重启 container 容器实例
启动： run # 创建并运行 docker 实例
```
[root@bogon ~]# docker run -d docker.io/centos:latest /bin/sh -c  "while  true;do echo hello world; sleep 1; done"

f639c4a00e22734e9c4faecd1480d01333c6049599d7e851342aa588e3e2926a
[root@bogon ~]# 
[root@bogon ~]# docker ps
CONTAINER ID        IMAGE                     COMMAND                  CREATED             STATUS              PORTS               NAMES
f639c4a00e22        docker.io/centos:latest   "/bin/sh -c 'while..."   7 seconds ago       Up 6 seconds                            infallible_lewin
[root@bogon ~]# docker stop f639c4a00e22
f639c4a00e22
[root@bogon ~]# docker ps
CONTAINER ID        IMAGE               COMMAND             CREATED             STATUS              PORTS               NAMES
[root@bogon ~]# 
```
     
### 例5：删除指定 container ： rm
```
[root@bogon ~]# docker rm f639c4a00e22
f639c4a00e22
[root@bogon ~]# docker ps
CONTAINER ID        IMAGE               COMMAND             CREATED             STATUS              PORTS        

```
#  二、docker镜像制作的方法：
Docker Image 的制作两种方法

方法 1：docker commit	#保存 container 的当前状态到 image 后，然后生成对应的 image 
方法 2：docker build #使用 Dockerfile 文件自动化制作 image

## 2.1 创建一个安装好 apache web 服务器的容器镜像
```
[root@bogon ~]# docker run -it docker.io/centos:latest /bin/bash
[root@692713fffabb /]# yum install -y httpd 
 #根据容器弼前状态做一个 image 镜像：创建一个安装了 apache 工具的 centos 镜像语法： docker commit <container 的 ID>或<image_name>
[root@bogon ~]# docker ps -a
CONTAINER ID        IMAGE                     COMMAND                  CREATED             STATUS                        PORTS               NAMES
692713fffabb        docker.io/centos:latest   "/bin/bash"              14 minutes ago      Exited (0) 2 minutes ago                          priceless_kare
6246ea4f21ef        docker.io/centos:latest   "/bin/sh -c 'while..."   46 minutes ago      Exited (137) 40 minutes ago                       compassionate_hugle
ff20a65c5b95        docker.io/centos:latest   "/bin/bash"              3 hours ago         Exited (0) 3 hours ago                            serene_yalow
[root@bogon ~]# docker commit 692713fffabb docker.io/centos:apache 
sha256:d61468f39896cf7f900f44b442c3e20960eba54bf877809f30a832e5c844ff15
[root@bogon ~]# docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
docker.io/centos    apache              d61468f39896        7 seconds ago       318 MB
docker.io/centos    latest              9f38484d220f        11 days ago         202 MB
#使用新创建的 docker.io/centos：apache 镜像，生成一台容器实例： 镜像，生成一台容器实例：
[root@bogon ~]# docker run -it centos:apache /bin/bash
[root@e105be29362b /]# rpm -qa httpd
httpd-2.4.6-88.el7.centos.x86_64
[root@e105be29362b /]# 
#查找安装包可以说明基于docker的apacheweb服务器构建成功

```
## 2.2通过docker build 创建一个基于 centos 的 httpd web 服务器镜像。使用 docker build 创建镜像时，需要使用 Dockerfile 文件自动化制作 image  镜像注：Dockerfile 有点像源码编译时./configure 后产生的 Makefile

以下操作要在 docker 物理机上操作：

1、创建工作目录
```
[root@bogon ~]# mkdir /docker-build 
[root@bogon docker-build]# touch Dockerfile

```
2、编辑Dockerfile
Dockerfile 用来创建一个自定义的 image,包含了用户指定的软件依赖等。

```
[root@bogon docker-build]# vim Dockerfile 
FROM docker.io/centos:latest
MAINTAINER <www.cjzshilong.cn>
RUN yum -y install httpd
ADD start.sh /usr/local/bin/start.sh
ADD index.html /var/www/html/index.html
CMD /usr/local/bin/start.sh
```
注释：
FROM docker.io/centos:latest # FROM 基于哪个镜像MAINTAINER <www.cjzshilong.cn>
MAINTAINER镜像创建者
RUN yum -y install httpd	#RUN 安装软件用
ADD start.sh /usr/local/bin/start.sh
ADD index.html /var/www/html/index.html CMD /usr/local/bin/start.sh
ADD   将文件<src>拷贝到新产生的镜像的文件系统对应的路径<dest>。所有拷贝到新镜像中的文件和文件夹权限为 0755,uid 和 gid 为 0
CMD echo hello world	#container 启劢时执行的命令或启劢服务，但是一个 Dockerfile 中叧能有一条 CMD 命令，多条则叧执行最后一条 CMD.

3、创建  start.sh 脚本启动 httpd 服务和 apache 默认首页 index.html 文件

```
[root@bogon docker-build]# echo "/usr/sbin/httpd -DFOREGROUND" > start.sh
[root@bogon docker-build]# chmod a+x start.sh 
[root@bogon docker-build]# echo "docker images build test" > index.html

```
注：/usr/sbin/httpd -DFOREGROUND 参数的含意：
Systemd is designed to run processes "in the foreground", that is, they don't have to specifically run themselves as daemons. The processes don't exactly run in the foreground, they run under systemd and it captures their input and output, but from the process's perspective, it is the same as running in the foreground.  That  is  systemd's  preferred method of operation, but it does have compatibility with traditional daemons.

4、使用命令来创建新的image
语法：docker build -t    父镜像名：镜像的 tag	Dockerfile 文件所在路径
-t :表示 tage，镜像名
例：使用命令 docker build 来创建新的 image,并命名为 docker.io/centos:httpd 

```
[root@bogon docker-build]# docker build -t docker.io/centos:httpd ./
……
Complete!
 ---> 15fa43bfc4fd
Removing intermediate container 032876270cc9
Step 4/6 : ADD start.sh /usr/local/bin/start.sh
 ---> 7c5122e78132
Removing intermediate container d4788388dfd4
Step 5/6 : ADD index.html /var/www/html/index.html
 ---> b02c0f7e5657
Removing intermediate container e8fd13da450e
Step 6/6 : CMD /usr/local/bin/start.sh
 ---> Running in e28625d1a0e3
 ---> 7703e62fc080
Removing intermediate container e28625d1a0e3
Successfully built 7703e62fc080

[root@bogon docker-build]# docker images

REPOSITORY          TAG                 IMAGE ID            CREATED              SIZE
docker.io/centos    httpd               7703e62fc080        About a minute ago   318 MB
docker.io/centos    apache              d61468f39896        27 minutes ago       318 MB
docker.io/centos    latest              9f38484d220f        11 days ago          202 MB
```

./表示当前目录，当前目录要含有Dockerfile文件

#  三、Docker images的发布
方法 1：Save Image To TarBall
方法 2：Push Image To Docker Hub
## 3.1 方法1：Save Image To TarBall 
保 存 Image 到 tar 包
语法：docker save -o 导出的镜像名.tar  本地镜像名：镜像标签例：
```
[root@bogon ~]# docker save -o docker.io-centos-httpd-image.tar docker.io/centos:httpd

[root@bogon ~]# ll -h
总用量 311M
-rw-------. 1 root root 311M 3月  26 18:38 docker.io-centos-httpd-image.tar
```
例：使用导入本地镜像：
```
[root@bogon ~]# docker rmi docker.io/centos:httpd

Untagged: docker.io/centos:httpd
Deleted: sha256:7703e62fc0802dcb545ed4403dda4e343e0d51ae984db30efb2e32f0e045ef26
Deleted: sha256:b02c0f7e565757ec489dd759a45abf321273bca9959e3193dcf9a6d3de4adf2b
Deleted: sha256:1e9184e36e9a941d7bd35ae854ac2677367f0f0882d2d8056cc1a9b025dad4c3
Deleted: sha256:7c5122e7813298d44726f2c4df0f27be01cfe85ab2cf530d3729d3e84908dd29
Deleted: sha256:ff61787458e2102cfa4247fea79da7103d5017ef496ba8b9f83ad9296f1f60ea
Deleted: sha256:15fa43bfc4fd425002a5b528d061782f954643234fdd0beef31f380646b8471b
Deleted: sha256:0e4e270a381efa029a8d0a26e377055ca8aa49d1d3fe595d2c05fb76824ff809
Deleted: sha256:bf93b347b502d32efcbfe18746fda992b7675e36ead5fb727e237194c999cdaf
[root@bogon ~]# docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
docker.io/centos    apache              d61468f39896        34 minutes ago      318 MB
docker.io/centos    latest              9f38484d220f        11 days ago         202 MB
[root@bogon ~]# docker load -i docker.io-centos-httpd-image.tar 
f42df3e4c26b: Loading layer [==================================================>] 116.6 MB/116.6 MB
b1e658f9a703: Loading layer [==================================================>] 3.584 kB/3.584 kB
1ebe4270a160: Loading layer [==================================================>] 3.584 kB/3.584 kB
Loaded image: docker.io/centos:httpd
[root@bogon ~]# docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
docker.io/centos    httpd               7703e62fc080        10 minutes ago      318 MB
docker.io/centos    apache              d61468f39896        35 minutes ago      318 MB
docker.io/centos    latest              9f38484d220f        11 days ago         202 MB
[root@bogon ~]# 
```

## 3.2 方法2：Push Image To Docker Hub 发布到外网

1、Signup on docker hub & create repo	注册一个帐号https://hub.docker.com/
2、Login to docker hub
// docker login -u userabc -p abc123 -e userab@gmail.com
3、Push image to docker hub	#上传镜像
// docker push centos:httpd
4、Pull image from docker hub	#下载镜像
//  docker pull userabc/centos:httpd	# 用户名/镜像名

## 3.2 方法3：使用阿里云的私有仓库来发布;
待实验……

#  四、Container 容器端口映射

## 4.1 实战Container 端口映射
启动Container
```
[root@bogon ~]# docker run -d -p 80:80 docker.io/centos:httpd 

6a1fc818a972307687b9130ad7460c098c2bd88d60eb9026d565c7c24b71fe33
[root@bogon ~]# 
```
注： -p 物理机的 80 端口:容器实例的 80 端口 ，把容器中的 80 端口映射到物理机上的 80 端口

在物理机上查看容器状态
```
[root@bogon ~]# docker ps

CONTAINER ID        IMAGE                    COMMAND                  CREATED             STATUS              PORTS                NAMES
6a1fc818a972        docker.io/centos:httpd   "/bin/sh -c /usr/l..."   43 seconds ago      Up 42 seconds       0.0.0.0:80->80/tcp   unruffled_yonath
[root@bogon ~]# netstat -antup | grep 80
tcp        0      0 192.168.89.209:22       192.168.89.80:62820     ESTABLISHED 1397/sshd: root@pts 
tcp        0      0 192.168.89.209:22       192.168.89.80:62819     ESTABLISHED 1358/sshd: root@pts 
tcp6       0      0 :::80                   :::*                    LISTEN      6742/docker-proxy-c 
[root@bogon ~]# 
```
测试http
![dockerhtml.png](https://img.hacpai.com/file/2019/03/dockerhtml-8795600a.png)

## 4.2 访问正在运行的container容器实例

语 法 ： docker exec -it <container id | name> /bin/bash 
查看正在运行的容器 ID：

```
[root@bogon ~]# docker ps 

CONTAINER ID        IMAGE                    COMMAND                  CREATED             STATUS              PORTS                NAMES
6a1fc818a972        docker.io/centos:httpd   "/bin/sh -c /usr/l..."   6 minutes ago       Up 6 minutes        0.0.0.0:80->80/tcp   unruffled_yonath
[root@bogon ~]# docker exec -it 6a1fc818a972 /bin/bash 
[root@6a1fc818a972 /]# echo cuijianzhe > /var/www/html/test.html
[root@6a1fc818a972 /]# exit
exit
[root@bogon ~]# curl http://192.168.89.209/test.html
cuijianzhe
[root@bogon ~]# 
```
查看物理机和容器的网络
查看容器的ip
```
[root@bogon ~]# docker exec -it 6a1fc818a972 /bin/bash 
[root@6a1fc818a972 /]# yum install net-tools -y 
Loaded plugins: fastestmirror, ovl
Loading mirror speeds from cached hostfile
 * base: mirrors.zju.edu.cn
 * extras: mirrors.shu.edu.cn
 * updates: mirrors.shu.edu.cn
Resolving Dependencies
--> Running transaction check
---> Package net-tools.x86_64 0:2.0-0.24.20131004git.el7 will be installed
--> Finished Dependency Resolution

Dependencies Resolved

==========================================================================================================================================================================================================
 Package                                        Arch                                        Version                                                       Repository                                 Size
==========================================================================================================================================================================================================
Installing:
 net-tools                                      x86_64                                      2.0-0.24.20131004git.el7                                      base                                      306 k

Transaction Summary
==========================================================================================================================================================================================================
Install  1 Package

Total download size: 306 k
Installed size: 918 k
Downloading packages:
net-tools-2.0-0.24.20131004git.el7.x86_64.rpm                                                                                                                                      | 306 kB  00:00:00     
Running transaction check
Running transaction test
Transaction test succeeded
Running transaction
  Installing : net-tools-2.0-0.24.20131004git.el7.x86_64                                                                                                                                              1/1 
  Verifying  : net-tools-2.0-0.24.20131004git.el7.x86_64                                                                                                                                              1/1 

Installed:
  net-tools.x86_64 0:2.0-0.24.20131004git.el7                                                                                                                                                             

Complete!
[root@6a1fc818a972 /]# ifconfig
eth0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet 172.17.0.2  netmask 255.255.0.0  broadcast 0.0.0.0
        inet6 fe80::42:acff:fe11:2  prefixlen 64  scopeid 0x20<link>
        ether 02:42:ac:11:00:02  txqueuelen 0  (Ethernet)
        RX packets 184  bytes 326507 (318.8 KiB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 162  bytes 11695 (11.4 KiB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0

lo: flags=73<UP,LOOPBACK,RUNNING>  mtu 65536
        inet 127.0.0.1  netmask 255.0.0.0
        inet6 ::1  prefixlen 128  scopeid 0x10<host>
        loop  txqueuelen 1000  (Local Loopback)
        RX packets 0  bytes 0 (0.0 B)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 0  bytes 0 (0.0 B)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0

[root@6a1fc818a972 /]# 
```

物理机的ip：

```
[root@bogon ~]# ifconfig

docker0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet 172.17.0.1  netmask 255.255.0.0  broadcast 0.0.0.0
        inet6 fe80::42:a1ff:fee8:1077  prefixlen 64  scopeid 0x20<link>
        ether 02:42:a1:e8:10:77  txqueuelen 0  (Ethernet)
        RX packets 33531  bytes 2208751 (2.1 MiB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 37270  bytes 74193226 (70.7 MiB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0

ens33: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet 192.168.89.209  netmask 255.255.255.0  broadcast 192.168.89.255
        inet6 fe80::e99d:e9f2:8c11:9372  prefixlen 64  scopeid 0x20<link>
        ether 00:0c:29:33:7b:83  txqueuelen 1000  (Ethernet)
        RX packets 278009  bytes 207333025 (197.7 MiB)
        RX errors 0  dropped 1  overruns 0  frame 0
        TX packets 98075  bytes 8610553 (8.2 MiB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0

lo: flags=73<UP,LOOPBACK,RUNNING>  mtu 65536
        inet 127.0.0.1  netmask 255.0.0.0
        inet6 ::1  prefixlen 128  scopeid 0x10<host>
        loop  txqueuelen 1000  (Local Loopback)
        RX packets 634  bytes 57000 (55.6 KiB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 634  bytes 57000 (55.6 KiB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0

vethd559ccb: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet6 fe80::8cea:50ff:fe38:8696  prefixlen 64  scopeid 0x20<link>
        ether 8e:ea:50:38:86:96  txqueuelen 0  (Ethernet)
        RX packets 162  bytes 11695 (11.4 KiB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 184  bytes 326507 (318.8 KiB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0

[root@bogon ~]# 
```

目前相当于虚拟机的NAT模式
![dockermoshi.png](https://img.hacpai.com/file/2019/03/dockermoshi-8b180ed2.png)

配置容器的root密码：
```
[root@bogon ~]# docker exec -it 6a1fc818a972 /bin/bash 

[root@6a1fc818a972 /]# echo 598941324 | passwd --stdin root
Changing password for user root.
passwd: all authentication tokens updated successfully.
[root@6a1fc818a972 /]# 
```
在容器中安装 sshd 服务，然后把 22 端口映射出去，就可以远程登录容器了。
