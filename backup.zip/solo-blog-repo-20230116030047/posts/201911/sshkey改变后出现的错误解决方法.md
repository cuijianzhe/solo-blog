title: ssh-key改变后出现的错误解决方法
date: '2019-11-02 09:32:07'
updated: '2020-03-26 14:19:55'
tags: [Linux]
permalink: /articles/2019/11/02/1572658327824.html
---
```shell
[root@ceph1 ceph]# scp root@192.168.51.206:/etc/ceph/ceph.conf root@192.168.51.212:/root
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@    WARNING: REMOTE HOST IDENTIFICATION HAS CHANGED!     @
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
IT IS POSSIBLE THAT SOMEONE IS DOING SOMETHING NASTY!
Someone could be eavesdropping on you right now (man-in-the-middle attack)!
It is also possible that a host key has just been changed.
The fingerprint for the ECDSA key sent by the remote host is
SHA256:USPeF4jTZDOv4uSyLhKx/lCUYkK/4fjb/QzIxO90akc.
Please contact your system administrator.
Add correct host key in /root/.ssh/known_hosts to get rid of this message.
Offending ECDSA key in /root/.ssh/known_hosts:4
ECDSA host key for 192.168.51.212 has changed and you have requested strict checking.
Host key verification failed.
lost connection
Connection to 192.168.51.206 closed.
```

解决方法：

```
ssh-keygen -R 192.168.51.212
```

解决方法2：

```
vim ~/.ssh/known_hosts
```

* 重置ssh秘钥：
```
ssh-keygen -p
```
把相关远程主机信息删掉
