title: python脚本操作数据库
date: '2019-07-26 15:26:38'
updated: '2019-07-26 15:32:21'
tags: [python]
permalink: /articles/2019/07/26/1564125997971.html
---
# python数据库基本操作
---

操作关键字
创建连接     connect [kəˈnekt] 连接
实例化游标   cursor [ˈkɜːsə(r)] 游标
执行sql语句 execute [ˈeksɪkjuːt] 实行;执行;
提交修改     commit [kəˈmɪt] 做出
事务回滚     rollback [ˈrəʊlbæk] 回落;
关闭游标和链接 close

## 一、用脚本连接数据库：
```
import pymysql
#创建一个对象，用于连接数据库，参数分别设置为地址，用户名，密码，数据库，字符集
db = pymysql.connect(host = 'localhost',user='root',password='598941324',database='cuijianzhe',charset='utf8')
#使用cursor方法创建一个游标对象，相当一个操作者
cursor = db.cursor()
#编写下sql语句
sql = '''create table teacher(
id int primary key auto_increment,
name varchar(30),
age int,
classroom int)'''
#使用execute方法执行sql语句，相当于操作都在mysql命令中输入sql语句并回车
cursor.execute(sql)
#关闭游标
cursor.close()
#关闭数据库
```
查看数据库：
```
mysql> show tables;
+----------------------+
| Tables_in_cuijianzhe |
+----------------------+
| student              |
| teacher              |
+----------------------+
2 rows in set (0.00 sec)
mysql> desc teacher;
+-----------+-------------+------+-----+---------+----------------+
| Field     | Type        | Null | Key | Default | Extra          |
+-----------+-------------+------+-----+---------+----------------+
| id        | int(11)     | NO   | PRI | NULL    | auto_increment |
| name      | varchar(30) | YES  |     | NULL    |                |
| age       | int(11)     | YES  |     | NULL    |                |
| classroom | int(11)     | YES  |     | NULL    |                |
+-----------+-------------+------+-----+---------+----------------+
4 rows in set (0.00 sec)

```

connect 参数详解：
•      host=None,          	# 要连接的主机地址
•      user=None,          	# 用于登录的数据库用户
•      password='',        	# 密码
•      database=None,      	# 要连接的数据库
•      port=0,             	# 端口，一般为 3306
•      charset='',         		# 字符编码
•      conv=None,          	# 转换字典
•      use_unicode=None,   	# 是否使用 unicode 编码
•      init_command=None,  	# 连接建立时运行的初始语句 
•      connect_timeout=10, 	# 连接超时时间，(default: 10, min: 1, max: 31536000)
•      autocommit=False,   	# 是否自动提交事务
•      db=None,            	# 同 database，为了兼容 MySQLdb
•      passwd=None,        	# 同 password，为了兼容 MySQLdb
•      local_infile=False,     	# 是否允许载入本地文件
•      read_timeout=None,  	# 读取超时时间
•      write_timeout=None, 	# 写入时间


## 二、增添一条数据：
```
import pymysql

#连接数据库，参数分别为本地地址，用户名，密码，数据库，字符集
db = pymysql.connect(host = '10.200.36.66',user = 'root',password ='598941324',database='cuijianzhe',charset='utf8')
#使用cursor方法创建一个游标对象，相当于一个操作者
cursor = db.cursor()
# 插入sql语句
sql = "insert into  teacher(name,age,classroom)value ('cnm',19,'200')"
#使用execute方法执行sql语句，相当于操作者在mysql命令中输入SQL语句并回车
cursor.execute(sql)
#提交给数据库，主要配合为增加删除修改这些操作
db.commit()
#关闭游标
cursor.close()
#关闭数据库
db.close()
```
查看表结构：
```
mysql> select * from teacher\G
*************************** 1. row ***************************
       id: 1
     name: 哈哈哈
      age: 19
classroom: 1995
*************************** 2. row ***************************
       id: 2
     name: cnm
      age: 19
classroom: 200
2 rows in set (0.00 sec)

```
## 三、删除表：
```
import pymysql

#连接数据库，参数分别为本地地址，用户名，密码，数据库，字符集
db = pymysql.connect(host = '10.200.36.66',user = 'root',password ='598941324',database='student',charset='utf8')
#使用cursor方法创建一个游标对象，相当于一个操作者
cursor = db.cursor()
# 使用 execute()  方法执行sql语句
#drop的时候提不提交都行，delect 的时候要commit
#delete from tab_name where id =1 
cursor.execute("drop table student")     
#提交给数据库，主要配合为增加删除修改这些操作
db.commit()
#关闭游标
cursor.close()
#关闭数据库连接
db.close()
```
查看相关操作结果：
```
mysql> show tables;
+----------------------+
| Tables_in_cuijianzhe |
+----------------------+
| student              |
| teacher              |
+----------------------+
2 rows in set (0.00 sec)

mysql> show tables;
+----------------------+
| Tables_in_cuijianzhe |
+----------------------+
| teacher              |
+----------------------+
1 row in set (0.00 sec)

```
## 四、更改数据
```
import  pymysql
#连接下数据库
db = pymysql.connect(host = '10.200.36.66',user = 'root',password ='598941324',database='cuijianzhe',charset='utf8')
#创建游标对象
cursor = db.cursor()
#使用execute执行sql语句
cursor.execute("update teacher set name='gunnimabi' where id=2")
#提交给数据库，用于配合修改操作
db.commit()
#关闭游标
cursor.close()
#关闭数据库连接
db.close

```

```
mysql> select * from teacher\G
*************************** 1. row ***************************
       id: 1
     name: 哈哈哈
      age: 19
classroom: 1995
*************************** 2. row ***************************
       id: 2
     name: gunnimabi
      age: 19
classroom: 200
2 rows in set (0.00 sec)

mysql> 

```
## 五、数据库查询操作
Python查询Mysql使用 fetchone() 方法获取单条数据, 使用fetchall() 方法获取多条数据。
fetchone(): 	该方法获取下一个查询结果集。结果集是一个对象
fetchall(): 	接收全部的返回结果行.
rowcount: 	这是一个只读属性，并返回执行execute()方法后影响的行数。

```
import  pymysql
#连接下数据库
db = pymysql.connect(host = '10.200.36.66',user = 'root',password ='598941324',database='cuijianzhe',charset='utf8')
#创建游标对象
cursor = db.cursor()
#使用execute执行sql语句
cursor.execute("select * from teacher")
#使用fetchone()方法获取单条数据
# data = cursor.fetchone()
# print('单条信息',data)
#fetcall查所有，以元组的形式返回
all_data = cursor.fetchall()
print(all_data)
#提交给数据库，用于配合修改操作
db.commit()
#关闭游标
cursor.close()
#关闭数据库连接
db.close
```