title: 迁移wiki- Atlassian Confluence并升级
date: '2020-05-07 19:33:06'
updated: '2020-05-14 23:29:02'
tags: [Linux, Wiki]
permalink: /articles/2020/05/07/1588851186350.html
---
## MySQL部署

#### rpm安装

```bash
wget https://cdn.mysql.com//Downloads/Connector-J/mysql-connector-java-5.1.49.tar.gz
wget https://cdn.mysql.com//Downloads/MySQL-5.7/mysql-community-server-5.7.30-1.el7.x86_64.rpm
wget https://cdn.mysql.com//Downloads/MySQL-5.7/mysql-community-common-5.7.30-1.el7.x86_64.rpm
wget https://cdn.mysql.com//Downloads/MySQL-5.7/mysql-community-libs-5.7.30-1.el7.x86_64.rpm
wget https://cdn.mysql.com//Downloads/MySQL-5.7/mysql-community-client-5.7.30-1.el7.x86_64.rpm
rpm -ivh mysql-community-server-5.7.30-1.el7.x86_64.rpm   --force --nodeps
rpm -ivh mysql-community-client-5.7.30-1.el7.x86_64.rpm --force --nodeps
rpm -ivh mysql-community-libs-5.7.30-1.el7.x86_64.rpm --force --nodeps
rpm -ivh mysql-community-common-5.7.30-1.el7.x86_64.rpm --force --nodeps
```

#### yum安装

`https://repo.mysql.com//mysql57-community-release-el7-10.noarch.rpm`

#### 密码修改

```shell
[root@localhost ~]#  grep password /var/log/mysqld.log
2020-05-08T01:40:02.868978Z 1 [Note] A temporary password is generated for root@localhost: hhhrjS?Xq61+
[root@localhost conf]# rpm -qa | grep -i mysql
mysql-community-client-5.7.30-1.el7.x86_64
mysql-community-common-5.7.30-1.el7.x86_64
mysql-community-server-5.7.30-1.el7.x86_64
mysql-community-libs-5.7.30-1.el7.x86_64
```

```mysql
[root@localhost ~]# mysql -uroot -p 
Enter password: 
Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 2
Server version: 5.7.30

Copyright (c) 2000, 2020, Oracle and/or its affiliates. All rights reserved.

Oracle is a registered trademark of Oracle Corporation and/or its
affiliates. Other names may be trademarks of their respective
owners.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

mysql> show databases;
ERROR 1820 (HY000): You must reset your password using ALTER USER statement before executing this statement.
mysql>  set password = password("598941324");
ERROR 1819 (HY000): Your password does not satisfy the current policy requirements
mysql> set global validate_password_policy=LOW; 
Query OK, 0 rows affected (0.00 sec)

mysql>  set global validate_password_length=6; 
Query OK, 0 rows affected (0.00 sec)

mysql> ALTER USER 'root'@'localhost' IDENTIFIED BY '598941324';
Query OK, 0 rows affected (0.00 sec)

mysql> show databases;
+--------------------+
| Database           |
+--------------------+
| information_schema |
| mysql              |
| performance_schema |
| sys                |
+--------------------+
4 rows in set (0.00 sec)

mysql> GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' IDENTIFIED BY '598941324' WITH GRANT OPTION;
Query OK, 0 rows affected, 1 warning (0.00 sec)
mysql>  CREATE DATABASE confluence CHARACTER SET utf8 COLLATE utf8_bin;
Query OK, 1 row affected (0.00 sec)

mysql> GRANT ALL PRIVILEGES ON confluence.* TO 'confluence'@'localhost' IDENTIFIED BY 'confluence';
Query OK, 0 rows affected, 1 warning (0.01 sec)

mysql> SET GLOBAL tx_isolation='READ-COMMITTED';   #设置默认隔离级别
Query OK, 0 rows affected, 1 warning (0.00 sec)

mysql> flush privileges;
Query OK, 0 rows affected (0.00 sec)
mysql> exit
Bye
```

#### mysql检查字符集：

```mysql
mysql> SHOW VARIABLES WHERE Variable_name LIKE 'character_set_%' OR Variable_name LIKE 'collation%';
+--------------------------+----------------------------+
| Variable_name            | Value                      |
+--------------------------+----------------------------+
| character_set_client     | utf8                       |
| character_set_connection | utf8                       |
| character_set_database   | utf8                       |
| character_set_filesystem | binary                     |
| character_set_results    | utf8                       |
| character_set_server     | utf8                       |
| character_set_system     | utf8                       |
| character_sets_dir       | /usr/share/mysql/charsets/ |
| collation_connection     | utf8_unicode_ci            |
| collation_database       | utf8_unicode_ci            |
| collation_server         | utf8_unicode_ci            |
+--------------------------+----------------------------+
11 rows in set (0.00 sec)
```

#### mysql配置：

```shell
[mysqld]
datadir=/alidata/lib/mysql
socket=/var/lib/mysql/mysql.sock
symbolic-links=0
init_connect='SET collation_connection = utf8_unicode_ci'
init_connect='SET NAMES utf8'
character-set-server=utf8
collation-server=utf8_unicode_ci
skip-character-set-client-handshake
max_allowed_packet=34M
innodb_log_file_size=268435456
[mysqld_safe]
log-error=/var/log/mariadb/mariadb.log
pid-file=/var/run/mariadb/mariadb.pid
!includedir /etc/my.cnf.d
```

## 部署JDK

```shell
[root@localhost ~]# java -version
java version "1.8.0_251"
Java(TM) SE Runtime Environment (build 1.8.0_251-b08)
Java HotSpot(TM) 64-Bit Server VM (build 25.251-b08, mixed mode)
```

## [Atlassian ](https://www.atlassian.com/zh/software/confluence/download)下载地址

下载地址：https://product-downloads.atlassian.com/software/confluence/downloads/atlassian-confluence-6.15.10-x64.bin

#### 安装：

```shell
[root@localhost ~]# ./atlassian-confluence-6.15.10-x64.bin 
......
Select the folder where you would like Confluence 6.15.10 to be installed,
then click Next.
Where should Confluence 6.15.10 be installed?
[/opt/atlassian/confluence]
/usr/local/confluence

Default location for Confluence data
[/var/atlassian/application-data/confluence]
/data/atlassian/application-data/confluence  
......
```

破解：

```
cp /usr/local/atlassian/confluence/confluence/WEB-INF/lib/atlassian-extras-decoder-v2-3.4.1.jar /root/
```

将其改名为atlassian-extras-2.4.jar（因为破解工具只认这个版本的名称）
将改名后的atlassian-extras-2.4.jar 传到本地，然后本地电脑操作：

数据库驱动上传：
`cp mysql-connector-java-5.1.49.jar /usr/local/atlassian/confluence/confluence/WEB-INF/lib`

迁移过程：

* 迁移confluence主目录文件（最好全部备份迁移）
* 数据库备份并且迁移；
* Edit the `<confluence-home>\confluence.cfg.xml` file.
* 更改 `<confluence-home>/confluence.cfg.xml`，数据库驱动程序



**主目录文件**：`/usr/local/atlassian/confluence/confluence/WEB-INF/classes/confluence-init.properties`



**迁移必备软件：**

![image.png](https://img.hacpai.com/file/2020/05/image-51f65166.png)

参考：
https://blog.csdn.net/leonliu06/article/details/104057660

https://www.jianshu.com/p/2f2142ce01b7

https://confluence.atlassian.com/conf63/manually-backing-up-the-site-929729737.html

数据库配置参考：

https://confluence.atlassian.com/doc/database-setup-for-mysql-128747.html
