title: kolla部署openstack（stein）部署---allinone
date: '2019-10-27 18:27:11'
updated: '2019-10-31 20:23:10'
tags: [openstack, Linux]
permalink: /articles/2019/10/27/1572172031071.html
---
# 前期准备


## 基本配置
### 扩展源

```
yum install epel-release -y
```
### hostname

```
[root@kolla ~]# cat /etc/hostname 
kolla
[root@kolla ~]# cat /etc/hosts
127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6
192.168.51.208  kolla.cn kolla
```
### 时间同步
```
yum install ntp -y && systemctl enable ntpd.service && systemctl start ntpd.service
```
### 配置pip源参考[这里](https://blog.csdn.net/sinat_21591675/article/details/82770360)
```
mkdir ~/.pip
vim ~/.pip/pip.conf
[global]
index-url = http://mirrors.aliyun.com/pypi/simple/
[install]
trusted-host=mirrors.aliyun.com
```
### 配置网卡信息
物理机，两张网卡，一张是管理网卡，另一张是桥接网卡（外网网卡）；

| IP地址 | 网卡类型 | 网卡 |在openstack网络中的作用|
| --- | --- | --- |--- |
|  192.168.51.208| bridge |enp61s0f0  | openstack内部管理网络 (managment nework) 以后Horizon web界面访问，就是通过这个IP地址|
| 无IP（不配置ip） |bridge  | enp61s0f3 | 外部网络 (external network) ，让neutron的br-ex 绑定使用，openstack中的虚拟机是通过这块网卡和外网通信的|

enp61s0f3中的配置
```
TYPE=Ethernet
PROXY_METHOD=none
BROWSER_ONLY=no
BOOTPROTO=none
DEFROUTE=yes
IPV4_FAILURE_FATAL=no
IPV6INIT=yes
IPV6_AUTOCONF=yes
IPV6_DEFROUTE=yes
IPV6_FAILURE_FATAL=no
IPV6_ADDR_GEN_MODE=stable-privacy
NAME=enp61s0f3
UUID=1abc4bd5-0df3-483e-9110-55f905c4d428
DEVICE=enp61s0f3
ONBOOT=yes
```
### 安装基础包和docker服务
####  安装基础包
```
yum install python-devel libffi-devel gcc openssl-devel git python-pip -y
pip install -U pip
yum install -y yum-utils device-mapper-persistent-data lvm2
```
#### 添加docker yum源并安装docker
```
yum-config-manager --add-repo http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
rpm --import https://mirrors.aliyun.com/docker-ce/linux/centos/gpg #导入rpm包密钥，检查后期在线安装的rpm是否安全
```
安装docker社区版本

```
yum -y install docker-ce
systemctl start docker && systemctl enable docker && systemctl status docker
```
设置docker volume卷挂载方式
```
mkdir /etc/systemd/system/docker.service.d
tee /etc/systemd/system/docker.service.d/kolla.conf << 'EOF'
[Service]
MountFlags=shared
EOF
```
> 注：加上MountFlags=shared后，当docker宿主机新增分区时，docker服务不用重启。添加这个参考后，后期在openstack中使用cinder存储服务时，新加磁盘比较方便。

####  镜像加速器设置 
在此我建议部署stein版本镜像加速器选择[daocloud](https://www.daocloud.io/mirror)，阿里、网易等加速器可能会出现pull docker出现问题。  
```  
curl -sSL https://get.daocloud.io/daotools/set_mirror.sh | sh -s http://f1361db2.m.daocloud.io  
```
重启相关服务

```
systemctl daemon-reload
systemctl restart docker && systemctl status docker
```
# 安装kolla-ansible
## 安装ansible
```
yum install ansible -y
pip install kolla-ansible 
```
> 报错：已经安装PyYAML 3.10，但是我们需要PyYAML

解决：
```
pip install PyYAML --ignore-installed PyYAML
```
* 复制kolla-ansible的相关配置文件
```
cp -r /usr/share/kolla-ansible/etc_examples/kolla /etc/
cp /usr/share/kolla-ansible/ansible/inventory/* /etc/kolla/
```
* 另外安装stein后期会遇到pip包找不到的问题，在此先安装
报错信息：ImportError: cannot import name decorate
解决：
```
pip install -U decorator
pip install --upgrade decorate
```
# 自定义安装kolla-ansible安装openstack的相关配置文件
## 自动生成openstack各服务的密码文件
```
kolla-genpwd
```

修改/etc/kolla/passwords.yml
```
 keystone_admin_password: 598941324
```
> 注：这是登录Dashboard，admin使用的密码，你可以根据自己需要自行修改。
## 编辑/etc/kolla/globals.yml文件
```
kolla_base_distro: "centos"
kolla_install_type: "binary" 
openstack_release: "stein"
kolla_internal_vip_address: "192.168.51.208"
network_interface: "enp61s0f0"
neutron_external_interface: "enp61s0f3"
enable_haproxy: "no"
```
> * kolla_install_type: "binary" ：使用yum安装二进制包安装，源码安装，指的是使用git clone源码安装
> * openstack_release: "stein"：指定安装stein版本的openstack，后期下载的openstack相关的docker镜像的tag标记也都为stein
> * node_custom_config: "/etc/kolla/config"：配置文件的位置
> * kolla_internal_vip_address: "192.168.51.208"：没有启用高可用，所以这里的IP可以和enp61s0f0一样，也可以独立写一个和enp61s0f3同网段的IP。这一项的作用是：指定openstack内部管理地址，以后就通过这个IP地址访问openstack web界面，管理私云。
注：如果配置了高可用，这里要使用一个没被占用的IP。这个IP是搭建HA高可用的浮动IP。 此IP将由keepalived管理以提供高可用性，应设置为和network_interface enp61s0f3 同一个网段的地址。
> * network_interface: "enp61s0f0"：Kolla-Ansible需要设置一些网络选项。 我们需要设置OpenStack使用的网络接口。设置的第一个接口是“network_interface”。 这是openstack内部多个管理类型网络的默认接口
> * neutron_external_interface: "enp61s0f3"：所需的第二个接口与用亍Neutron外部（或公共）网络，可以是vlan戒flat，取决于网络的创建方式。 此接口应在没有IP地址的情况下处于活动，如果不是，openstack于平台中的于主机实例将无法访问外部网络。 只要网卡启劢着，就可以了，不要给IP，有IP时br-ex桥接就不成功了。
> * enable_cinder: "no"：先不开启cinder
> * enable_haproxy: "no":关闭高可用

# 开始基于kolla-ansible安装openstack私有云
## 生成ssh-key，并授信本节点：

```
ssh-keygen
ssh-copy-id -i ~/.ssh/id_rsa.pub root@kolla
```
## 配置单节点清单文件
```
[root@kolla ~]# vim /etc/kolla/all-in-one 
# These initial groups are the only groups required to be modified. The
# additional groups are for more control of the environment.
[control]
kolla

[network]
kolla

[compute]
kolla

[storage]
kolla

[monitoring]
kolla

[deployment]
kolla
```
## 开始部署openstack
### 对主机进行预检查

```
kolla-ansible -i /etc/kolla/all-in-one prechecks
```
### 拉取镜像
```
kolla-ansible -i /etc/kolla/all-in-one pull
[root@kolla ~]# docker images | wc -l 
32
```
大概会下载32个镜像文件
## 最后进入实际的OpenStack部署：
```
kolla-ansible -i /etc/kolla/all-in-one deploy
```
部署完成后验证部署
```
kolla-ansible -i /etc/kolla/all-in-one post-deploy
```
这样就创建 /etc/kolla/admin-openrc.sh 文件
```
[root@kolla ~]# cat /etc/kolla/admin-openrc.sh 
export OS_PROJECT_DOMAIN_NAME=Default
export OS_USER_DOMAIN_NAME=Default
export OS_PROJECT_NAME=admin
export OS_TENANT_NAME=admin
export OS_USERNAME=admin
export OS_PASSWORD=598941324
export OS_AUTH_URL=http://192.168.51.208:35357/v3
export OS_INTERFACE=internal
export OS_IDENTITY_API_VERSION=3
export OS_REGION_NAME=RegionOne
export OS_AUTH_PLUGIN=password
```
## 部署完成
访问192.168.51.208即可进去openstack页面

# openstack-allinone使用方法
## 安装 openstack客户端并创建一个云主机
### 安装OpenStack client端，方便后期使用命令行操作openstack
```
pip install python-openstackclient
```
> 报错：ERROR: Package 'more-itertools' requires a different Python: 2.7.5 not in '>=3.4'

解决：
```
pip install more-itertools==5.0.0
pip install python-openstackclient
```
> 再次安装。


```
 pip install python-neutronclient
```
> 安装openstack网络相关的命令

## 创建一个云项目

### 修改init-runonce脚本，指定浮动IP地址范围

init-runonce是在openstack中快速创建一个云项目例子的脚本。浮劢IP就是云主机的公网IP。

* 修改如下配置
```
vim /usr/share/kolla-ansible/init-runonce
EXT_NET_CIDR='192.168.50.0/24'
EXT_NET_RANGE='start=192.168.50.150,end=192.168.50.199'
EXT_NET_GATEWAY='192.168.50.1'
```

### 使用init-runonce脚本创建一个openstack云项目
```
source /etc/kolla/admin-openrc.sh
cd /usr/share/kolla-ansible
./init-runonce
```
运行完毕之后出现如下：
```
To deploy a demo instance, run:

openstack server create \
    --image cirros \
    --flavor m1.tiny \
    --key-name mykey \
    --network demo-net \
    demo1
```
运行即可安装
```
[root@kolla kolla-ansible]# openstack server create \
>     --image cirros \
>     --flavor m1.tiny \
>     --key-name mykey \
>     --network demo-net \
>     demo1

+-------------------------------------+-----------------------------------------------+
| Field                               | Value                                         |
+-------------------------------------+-----------------------------------------------+
| OS-DCF:diskConfig                   | MANUAL                                        |
| OS-EXT-AZ:availability_zone         |                                               |
| OS-EXT-SRV-ATTR:host                | None                                          |
| OS-EXT-SRV-ATTR:hypervisor_hostname | None                                          |
| OS-EXT-SRV-ATTR:instance_name       |                                               |
| OS-EXT-STS:power_state              | NOSTATE                                       |
| OS-EXT-STS:task_state               | scheduling                                    |
| OS-EXT-STS:vm_state                 | building                                      |
| OS-SRV-USG:launched_at              | None                                          |
| OS-SRV-USG:terminated_at            | None                                          |
| accessIPv4                          |                                               |
| accessIPv6                          |                                               |
| addresses                           |                                               |
| adminPass                           | 7MxdJvxUhSop                                  |
| config_drive                        |                                               |
| created                             | 2019-10-27T02:49:06Z                          |
| flavor                              | m1.tiny (1)                                   |
| hostId                              |                                               |
| id                                  | 43d6a986-3f92-4cdd-a21c-22ad7dcb4c3a          |
| image                               | cirros (c912e610-4038-4a7f-8eea-670b44ac197b) |
| key_name                            | mykey                                         |
| name                                | demo1                                         |
| progress                            | 0                                             |
| project_id                          | 8370a6827e874b768c4f9778068cb4bc              |
| properties                          |                                               |
| security_groups                     | name='default'                                |
| status                              | BUILD                                         |
| updated                             | 2019-10-27T02:49:06Z                          |
| user_id                             | 7b5055a3536c415ca67f4a97752b3b5a              |
| volumes_attached                    |                                               |
+-------------------------------------+-----------------------------------------------+
```
### 此时即可在web上看到已创建的云主机
![image.png](https://img.hacpai.com/file/2019/10/image-23e2ad99.png)

