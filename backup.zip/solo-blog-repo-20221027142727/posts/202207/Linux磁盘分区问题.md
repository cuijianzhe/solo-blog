title: Linux磁盘分区问题
date: '2022-07-06 19:14:22'
updated: '2022-07-06 19:14:22'
tags: [Linux]
permalink: /articles/2022/07/06/1657106062614.html
---
# Linux磁盘分区

# 问题一：

**如果遇到下述问题：**

```
[root@ostack-228-32 ~]# mount /dev/sdb /data/
mount: /dev/sdb is already mounted or /data busy
```

**可以用此方式：**

```
[root@ostack-228-32 ~]# dmsetup status
VMDATA--node9-VMDATA--node9: 0 46816583680 thin-pool 0 15633/4145152 0/182877280 - rw no_discard_passdown queue_if_no_space - 1024 
VMDATA--node9-VMDATA--node9_tdata: 0 46816583680 linear 
VMDATA--node9-VMDATA--node9_tmeta: 0 33161216 linear 
centos-swap: 0 268435456 linear 
centos-root: 0 629145600 linear 
[root@ostack-228-32 ~]#  dmsetup remove_all
[root@ostack-228-32 ~]# dmsetup status
centos-swap: 0 268435456 linear 
centos-root: 0 629145600 linear
```

**最后进行挂载：**

```
[root@ostack-228-32 ~]# mkfs.xfs /dev/sdb
mkfs.xfs: /dev/sdb appears to contain a partition table (dos).
mkfs.xfs: Use the -f option to force overwrite.
[root@ostack-228-32 ~]# mkfs.xfs /dev/sdb1
meta-data=/dev/sdb1              isize=512    agcount=32, agsize=16777216 blks
         =                       sectsz=4096  attr=2, projid32bit=1
         =                       crc=1        finobt=0, sparse=0
data     =                       bsize=4096   blocks=536870655, imaxpct=5
         =                       sunit=64     swidth=192 blks
naming   =version 2              bsize=4096   ascii-ci=0 ftype=1
log      =internal log           bsize=4096   blocks=262143, version=2
         =                       sectsz=4096  sunit=1 blks, lazy-count=1
realtime =none                   extsz=4096   blocks=0, rtextents=0
[root@ostack-228-32 ~]# mount /dev/sdb1 /data
```

# 问题二：

**fdsik 分区最大只能 2T 分区，需要使用 parted 分区**

```
[root@ostack-228-32 ~]# parted /dev/sdb 
GNU Parted 3.1
Using /dev/sdb
Welcome to GNU Parted! Type 'help' to view a list of commands.
(parted) p                                                              
Model: UN LOGICAL VOLUME (scsi)
Disk /dev/sdb: 24.0TB
Sector size (logical/physical): 512B/4096B
Partition Table: msdos
Disk Flags: 
​
Number  Start  End  Size  Type  File system  Flags
​
(parted) mklabel gpt                                                    
Warning: The existing disk label on /dev/sdb will be destroyed and all data on this disk will be lost. Do you want to continue?
Yes/No? y                                                               
(parted) mkpart                                                         
Partition name?  []? sdb1                                               
File system type?  [ext2]? xfs                                          
Start? 0                                                                
End? 24.0TB                                                             
Warning: The resulting partition is not properly aligned for best performance.
Ignore/Cancel? Ignore                                                   
(parted) p                                                              
Model: UN LOGICAL VOLUME (scsi)
Disk /dev/sdb: 24.0TB
Sector size (logical/physical): 512B/4096B
Partition Table: gpt
Disk Flags: 
​
Number  Start   End     Size    File system  Name  Flags
 1      17.4kB  24.0TB  24.0TB               sdb1
​
(parted) quit                                                           
Information: You may need to update /etc/fstab.
​
[root@ostack-228-32 ~]# fdisk -l 
​
Disk /dev/sda: 480.1 GB, 480070426624 bytes, 937637552 sectors
Units = sectors of 1 * 512 = 512 bytes
Sector size (logical/physical): 512 bytes / 4096 bytes
I/O size (minimum/optimal): 262144 bytes / 262144 bytes
Disk label type: dos
Disk identifier: 0x000ca2b9
​
   Device Boot      Start         End      Blocks   Id  System
/dev/sda1   *        2048    37959679    18978816   83  Linux
/dev/sda2        37959680   935542783   448791552   8e  Linux LVM
WARNING: fdisk GPT support is currently new, and therefore in an experimental phase. Use at your own discretion.
​
Disk /dev/sdb: 24004.6 GB, 24004587945984 bytes, 46883960832 sectors
Units = sectors of 1 * 512 = 512 bytes
Sector size (logical/physical): 512 bytes / 4096 bytes
I/O size (minimum/optimal): 262144 bytes / 786432 bytes
Disk label type: gpt
Disk identifier: 67F6088B-A02E-4E5A-AAC5-2A06A017E61E
​
​
#         Start          End    Size  Type            Name
 1           34  46883960798   21.9T  Microsoft basic sdb1
Partition 1 does not start on physical sector boundary.
​
Disk /dev/mapper/centos-root: 322.1 GB, 322122547200 bytes, 629145600 sectors
Units = sectors of 1 * 512 = 512 bytes
Sector size (logical/physical): 512 bytes / 4096 bytes
I/O size (minimum/optimal): 262144 bytes / 262144 bytes
​
​
Disk /dev/mapper/centos-swap: 137.4 GB, 137438953472 bytes, 268435456 sectors
Units = sectors of 1 * 512 = 512 bytes
Sector size (logical/physical): 512 bytes / 4096 bytes
I/O size (minimum/optimal): 262144 bytes / 262144 bytes
​
[root@ostack-228-32 ~]# mkfs.xfs /dev/sd
sda   sda1  sda2  sdb   sdb1  
[root@ostack-228-32 ~]# mkfs.xfs /dev/sdb1 
warning: device is not properly aligned /dev/sdb1
Use -f to force usage of a misaligned device
[root@ostack-228-32 ~]# mkfs.xfs -f /dev/sdb1 
warning: device is not properly aligned /dev/sdb1
meta-data=/dev/sdb1              isize=512    agcount=32, agsize=183140480 blks
         =                       sectsz=512   attr=2, projid32bit=1
         =                       crc=1        finobt=0, sparse=0
data     =                       bsize=4096   blocks=5860495095, imaxpct=5
         =                       sunit=64     swidth=192 blks
naming   =version 2              bsize=4096   ascii-ci=0 ftype=1
log      =internal log           bsize=4096   blocks=521728, version=2
         =                       sectsz=512   sunit=64 blks, lazy-count=1
realtime =none                   extsz=4096   blocks=0, rtextents=0
[root@ostack-228-32 ~]# mount /dev/sdb1 /data/
[root@ostack-228-32 ~]# 
[root@ostack-228-32 ~]# 
[root@ostack-228-32 ~]# 
[root@ostack-228-32 ~]# df -Th
Filesystem              Type      Size  Used Avail Use% Mounted on
devtmpfs                devtmpfs  252G     0  252G   0% /dev
tmpfs                   tmpfs     252G     0  252G   0% /dev/shm
tmpfs                   tmpfs     252G   19M  252G   1% /run
tmpfs                   tmpfs     252G     0  252G   0% /sys/fs/cgroup
/dev/mapper/centos-root xfs       300G  4.0G  296G   2% /
/dev/sda1               xfs        19G  192M   18G   2% /boot
tmpfs                   tmpfs      51G     0   51G   0% /run/user/0
tmpfs                   tmpfs      60M     0   60M   0% /var/log/rtlog
/dev/sdb1               xfs        22T   34M   22T   1% /data
[root@ostack-228-32 ~]# vim /etc/fstab 
```

