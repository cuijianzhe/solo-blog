title: python获取数据实现echarts出图
date: '2019-09-06 16:14:52'
updated: '2019-09-06 16:28:15'
tags: [python, echarts]
permalink: /articles/2019/09/06/1567757692612.html
---
# python3 + echarts
## python3获取数据：
```
#!/bin/env python3
import json
import subprocess
import os
User_list = []
CMD_num = "snmpwalk -v 2c -c limi@2018  10.200.250.5 1.3.6.1.4.1.2011.6.139.13.3.10.1.5 | wc -l"  #AP总数
Num = int(subprocess.getoutput(CMD_num))
CMD_name = '''snmpwalk -v 2c -c limi@2018  10.200.250.5 enterprises.2011.6.139.13.3.10.1.5 | awk  '{print $4}' | sed 's/"//g' '''

ap_name = subprocess.getoutput(CMD_name)
Name_list = ap_name.split("\n")

for id in range(0,Num):
    CMD = "snmpwalk -v 2c -c limi@2018  10.200.250.5 1.3.6.1.4.1.2011.6.139.13.3.10.1.45.%s | awk '{print $4}'"%id  #AP连接用户数
    Sum = int(subprocess.getoutput(CMD))
    User_list.append(Sum)

data = json.dumps({'APUser':User_list,'APNAME':Name_list})
with open('/var/www/html/echarts/data/data'+'.json','w') as f:
     f.write(data)

```
## echarts渲染
> 在此表示echarts很强大
```
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>用户数显示</title>
    <script src="js/jquery-1.12.4.js"></script>
    <script src="js/echarts.min.js"></script>

</head>

<body>
<div id="main" style="width:2400px;height:800px;"></div>

<script>
    var myChart = echarts.init(document.getElementById('main'));
    // 异步加载数据
    $.get('data/data.json').done(function (data) {

        // 填入数据
        myChart.setOption({
            title: {
                text: 'AP用户数连接示例'
            },
            tooltip: {},
            legend: {
                data: ['用户数']
            },
            xAxis: {
                data: data.APNAME
            },
            yAxis: {},
            series: [{
                name: '用户数',
                type: 'bar',
                data: data.APUser
            }]
        });
    });
</script>
</body>
</html>

```
效果图：
![image.png](https://img.hacpai.com/file/2019/09/image-07a468e0.png)

