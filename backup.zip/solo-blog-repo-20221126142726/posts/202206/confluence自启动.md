title: confluence自启动
date: '2022-06-13 19:29:36'
updated: '2022-06-13 19:29:36'
tags: [Wiki]
permalink: /articles/2022/06/13/1655119776419.html
---
```bash
[root@system-wiki ~]# cat /usr/lib/systemd/system/wiki.service 
[Unit]
Description=Wiki

[Service]
Type=simple
PIDFile=/usr/local/atlassian/confluence/work/catalina.pid
ExecStartPre=rm -rf /usr/local/atlassian/confluence/work/catalina.pid
ExecStart=/usr/local/atlassian/confluence/bin/startup.sh
ExecStop=/usr/local/atlassian/confluence/bin/shutdown.sh
PrivateTmp=true
Restart=always
User=confluence
Group=confluence
[Install]
WantedBy=multi-user.target
```

pid设置文件：`/usr/local/atlassian/confluence/bin/setenv.sh`


