title: java数值类型的拆装箱与升降级之间的关系
date: '2019-04-11 21:03:35'
updated: '2019-04-11 21:03:35'
tags: [java]
permalink: /articles/2019/04/11/1554987815685.html
---
![](https://img.hacpai.com/bing/20181130.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

![](http://pouu7al9q.bkt.clouddn.com/%E6%8B%86%E8%A3%85%E7%AE%B1%E5%8D%87%E9%99%8D%E7%BA%A7.png) 