title: openstack系列- glance 服务部署
date: '2019-10-13 11:45:02'
updated: '2019-10-31 20:20:49'
tags: [Linux, openstack]
permalink: /articles/2019/10/13/1570938302267.html
---
#  [glance 服务安装](https://docs.openstack.org/glance/rocky/install/)
## glance库的创建
```
CREATE DATABASE glance;
 GRANT ALL PRIVILEGES ON glance.* TO 'glance'@'localhost' \
  IDENTIFIED BY 'glance';
GRANT ALL PRIVILEGES ON glance.* TO 'glance'@'%' \
  IDENTIFIED BY 'glance';
```
> 注意注意:每一条配置要新建到文件中，尽量不要打开注释在原有的基础上修改

 > 创建本地存储 

**1.一定要在opesntack-glance-api.service服务启动之前部署好存储设备，因为该服务在启动时会加载存储驱动检索存储设备，如果事先不存在，就意味着该服务没有识别到任何可用的存储设备，即便是后来你又新增了存储，仍然是无效的，最终导致你上传镜像失败；**

**2.一定要赋予opesntack-glance-api.service服务对存储设备的可写权限。**

## source管理凭据以获得对仅限管理的CLI命令的访问权限
* 创建glance用户
```bash
[root@linux-node1 ~]# . admin-openrc
[root@linux-node1 ~]#  openstack user create --domain default --password-prompt glance
User Password:
Repeat User Password:
+---------------------+----------------------------------+
| Field               | Value                            |
+---------------------+----------------------------------+
| domain_id           | default                          |
| enabled             | True                             |
| id                  | 50d3f42af55b47aeb9c7960cd4f77e5d |
| name                | glance                           |
| options             | {}                               |
| password_expires_at | None                             |
+---------------------+----------------------------------+
```
* 将管理角色添加到Glance用户和服务项目
```
openstack role add --project service --user glance admin
```
* 创建glance服务
```bash
[root@linux-node1 ~]#  openstack service create --name glance \
>   --description "OpenStack Image" image
+-------------+----------------------------------+
| Field       | Value                            |
+-------------+----------------------------------+
| description | OpenStack Image                  |
| enabled     | True                             |
| id          | b52dafaa99264002b7984e757668a82a |
| name        | glance                           |
| type        | image                            |
+-------------+----------------------------------+
```
* 创建glance API endpoints
```bash
[root@linux-node1 ~]#  openstack endpoint create --region RegionOne \
>   image public http://10.200.51.100:9292
+--------------+----------------------------------+
| Field        | Value                            |
+--------------+----------------------------------+
| enabled      | True                             |
| id           | 1cbd3c41a4a64df9a59b2fceae627d6e |
| interface    | public                           |
| region       | RegionOne                        |
| region_id    | RegionOne                        |
| service_id   | b52dafaa99264002b7984e757668a82a |
| service_name | glance                           |
| service_type | image                            |
| url          | http://10.200.51.100:9292        |
+--------------+----------------------------------+
[root@linux-node1 ~]#   openstack endpoint create --region RegionOne \
>   image internal http://10.200.51.100:9292
+--------------+----------------------------------+
| Field        | Value                            |
+--------------+----------------------------------+
| enabled      | True                             |
| id           | a952e55db8c04155a3a7c6d8a121630c |
| interface    | internal                         |
| region       | RegionOne                        |
| region_id    | RegionOne                        |
| service_id   | b52dafaa99264002b7984e757668a82a |
| service_name | glance                           |
| service_type | image                            |
| url          | http://10.200.51.100:9292        |
+--------------+----------------------------------+
[root@linux-node1 ~]#   openstack endpoint create --region RegionOne \
>   image admin http://10.200.51.100:9292

+--------------+----------------------------------+
| Field        | Value                            |
+--------------+----------------------------------+
| enabled      | True                             |
| id           | 0da610b8eb964bffa8debc17493a2ccc |
| interface    | admin                            |
| region       | RegionOne                        |
| region_id    | RegionOne                        |
| service_id   | b52dafaa99264002b7984e757668a82a |
| service_name | glance                           |
| service_type | image                            |
| url          | http://10.200.51.100:9292        |
+--------------+----------------------------------+
```
##  安装glance 
```
yum install openstack-glance -y
```
* 配置文件/etc/glance/glance-api.conf 修改
> 注意这里的配置文件最好新建
```
[database]
...
connection =  mysql+pymysql://glance:glance@10.200.51.100/glance
```
```
[keystone_authtoken]
www_authenticate_uri  = http://10.200.51.100:5000
auth_url = http://10.200.51.100:5000
memcached_servers = 10.200.51.100:11211
auth_type = password
project_domain_name = Default
user_domain_name = Default
project_name = service
username = glance
password = 598941324
```
```
[paste_deploy]
flavor = keystone
```
```
[glance_store]
stores = file,http
default_store = file
filesystem_store_datadir = /var/lib/glance/images/
```
* 配置/etc/glance/glance-registry.conf
```
[database]
connection = mysql+pymysql://glance:glance@10.200.51.100/glance
```
```
[keystone_authtoken]
www_authenticate_uri = http://10.200.51.100:5000
auth_url = http://10.200.51.100:5000
memcached_servers = 10.200.51.100:11211
auth_type = password
project_domain_name = Default
user_domain_name = Default
project_name = service
username = glance
password = 598941324
```
```
[paste_deploy]
flavor = keystone
```
* 数据库同步：
```
 su -s /bin/sh -c "glance-manage db_sync" glance
```
* images文件夹授权
```bash
[root@linux-node1 ~]# mkdir /var/lib/glance/images/
[root@linux-node1 ~]# chown -R glance:glance /var/lib/glance/images/
```
* 开机自启动
```
# systemctl enable openstack-glance-api.service \
  openstack-glance-registry.service
# systemctl start openstack-glance-api.service \
  openstack-glance-registry.service
```
状态：
```bash
[root@linux-node1 ~]# systemctl status openstack-glance-registry.service
● openstack-glance-registry.service - OpenStack Image Service (code-named Glance) Registry server
   Loaded: loaded (/usr/lib/systemd/system/openstack-glance-registry.service; disabled; vendor preset: disabled)
   Active: active (running) since 日 2019-10-13 11:24:33 CST; 6s ago
 Main PID: 3063 (glance-registry)
   CGroup: /system.slice/openstack-glance-registry.service
           ├─3063 /usr/bin/python2 /usr/bin/glance-registry
           ├─3074 /usr/bin/python2 /usr/bin/glance-registry
           ├─3075 /usr/bin/python2 /usr/bin/glance-registry
           ├─3076 /usr/bin/python2 /usr/bin/glance-registry
           └─3077 /usr/bin/python2 /usr/bin/glance-registry

10月 13 11:24:34 linux-node1 glance-registry[3063]: /usr/lib/python2.7/site-packages/paste/deploy/loadwsgi.py:22: Depr...tely.
10月 13 11:24:34 linux-node1 glance-registry[3063]: return pkg_resources.EntryPoint.parse("x=" + s).load(False)
10月 13 11:24:34 linux-node1 glance-registry[3063]: /usr/lib/python2.7/site-packages/paste/deploy/loadwsgi.py:22: Depr...tely.
10月 13 11:24:34 linux-node1 glance-registry[3063]: return pkg_resources.EntryPoint.parse("x=" + s).load(False)
10月 13 11:24:34 linux-node1 glance-registry[3063]: /usr/lib/python2.7/site-packages/paste/deploy/loadwsgi.py:22: Depr...tely.
10月 13 11:24:34 linux-node1 glance-registry[3063]: return pkg_resources.EntryPoint.parse("x=" + s).load(False)
10月 13 11:24:34 linux-node1 glance-registry[3063]: /usr/lib/python2.7/site-packages/glance/registry/api/__init__.py:3...oval.
10月 13 11:24:34 linux-node1 glance-registry[3063]: debtcollector.deprecate("Glance Registry service has been "
10月 13 11:24:34 linux-node1 glance-registry[3063]: /usr/lib/python2.7/site-packages/paste/deploy/util.py:55: Deprecat...ilter
10月 13 11:24:34 linux-node1 glance-registry[3063]: val = callable(*args, **kw)
Hint: Some lines were ellipsized, use -l to show in full.
[root@linux-node1 ~]# systemctl status openstack-glance-api.service 
● openstack-glance-api.service - OpenStack Image Service (code-named Glance) API server
   Loaded: loaded (/usr/lib/systemd/system/openstack-glance-api.service; disabled; vendor preset: disabled)
   Active: active (running) since 日 2019-10-13 11:24:08 CST; 1min 35s ago
 Main PID: 3008 (glance-api)
   CGroup: /system.slice/openstack-glance-api.service
           ├─3008 /usr/bin/python2 /usr/bin/glance-api
           ├─3019 /usr/bin/python2 /usr/bin/glance-api
           ├─3020 /usr/bin/python2 /usr/bin/glance-api
           ├─3021 /usr/bin/python2 /usr/bin/glance-api
           └─3022 /usr/bin/python2 /usr/bin/glance-api

10月 13 11:24:09 linux-node1 glance-api[3008]: /usr/lib/python2.7/site-packages/paste/deploy/loadwsgi.py:22: Deprecati...tely.
10月 13 11:24:09 linux-node1 glance-api[3008]: return pkg_resources.EntryPoint.parse("x=" + s).load(False)
10月 13 11:24:09 linux-node1 glance-api[3008]: /usr/lib/python2.7/site-packages/paste/deploy/loadwsgi.py:22: Deprecati...tely.
10月 13 11:24:09 linux-node1 glance-api[3008]: return pkg_resources.EntryPoint.parse("x=" + s).load(False)
10月 13 11:24:09 linux-node1 glance-api[3008]: /usr/lib/python2.7/site-packages/paste/deploy/loadwsgi.py:22: Deprecati...tely.
10月 13 11:24:09 linux-node1 glance-api[3008]: return pkg_resources.EntryPoint.parse("x=" + s).load(False)
10月 13 11:24:09 linux-node1 glance-api[3008]: /usr/lib/python2.7/site-packages/paste/deploy/loadwsgi.py:22: Deprecati...tely.
10月 13 11:24:09 linux-node1 glance-api[3008]: return pkg_resources.EntryPoint.parse("x=" + s).load(False)
10月 13 11:24:09 linux-node1 glance-api[3008]: /usr/lib/python2.7/site-packages/paste/deploy/util.py:55: DeprecationWa...ilter
10月 13 11:24:09 linux-node1 glance-api[3008]: val = callable(*args, **kw)
Hint: Some lines were ellipsized, use -l to show in full.
```
## 验证glance服务
```
[root@linux-node1 ~]# . admin-openrc 
[root@linux-node1 ~]#  wget http://download.cirros-cloud.net/0.4.0/cirros-0.4.0-x86_64-disk.img
```
```
openstack image create "cirros" \
  --file cirros-0.4.0-x86_64-disk.img \
  --disk-format qcow2 --container-format bare \
  --public
```
结果：
```bash
[root@linux-node1 ~]# openstack image create "cirros" \
>   --file cirros-0.4.0-x86_64-disk.img \
>   --disk-format qcow2 --container-format bare \
>   --public
+------------------+--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
| Field            | Value                                                                                                                                                                                      |
+------------------+--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
| checksum         | 443b7623e27ecf03dc9e01ee93f67afe                                                                                                                                                           |
| container_format | bare                                                                                                                                                                                       |
| created_at       | 2019-10-13T03:46:04Z                                                                                                                                                                       |
| disk_format      | qcow2                                                                                                                                                                                      |
| file             | /v2/images/b700d8c9-518f-4e30-853b-a245339f41d3/file                                                                                                                                       |
| id               | b700d8c9-518f-4e30-853b-a245339f41d3                                                                                                                                                       |
| min_disk         | 0                                                                                                                                                                                          |
| min_ram          | 0                                                                                                                                                                                          |
| name             | cirros                                                                                                                                                                                     |
| owner            | ce3251006573403993f317143cc3bf86                                                                                                                                                           |
| properties       | os_hash_algo='sha512', os_hash_value='6513f21e44aa3da349f248188a44bc304a3653a04122d8fb4535423c8e1d14cd6a153f735bb0982e2161b5b5186106570c17a9e58b64dd39390617cd5a350f78', os_hidden='False' |
| protected        | False                                                                                                                                                                                      |
| schema           | /v2/schemas/image                                                                                                                                                                          |
| size             | 12716032                                                                                                                                                                                   |
| status           | active                                                                                                                                                                                     |
| tags             |                                                                                                                                                                                            |
| updated_at       | 2019-10-13T03:46:05Z                                                                                                                                                                       |
| virtual_size     | None                                                                                                                                                                                       |
| visibility       | public                                                                                                                                                                                     |
+------------------+--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
```
* 确认上传镜像属性
```bash
[root@linux-node1 ~]#  openstack image list
+--------------------------------------+--------+--------+
| ID                                   | Name   | Status |
+--------------------------------------+--------+--------+
| b700d8c9-518f-4e30-853b-a245339f41d3 | cirros | active |
+--------------------------------------+--------+--------+
```
```
[root@linux-node1 images]# ll
总用量 12420
-rw-r-----. 1 glance glance 12716032 10月 13 11:46 b700d8c9-518f-4e30-853b-a245339f41d3
```
