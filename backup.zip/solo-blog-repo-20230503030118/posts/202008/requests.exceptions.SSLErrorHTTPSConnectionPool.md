title: 'requests.exceptions.SSLError: HTTPSConnectionPool'
date: '2020-08-08 14:20:54'
updated: '2020-08-08 14:30:08'
tags: [Python]
permalink: /articles/2020/08/08/1596867654155.html
---
**以前用的好好的脚本，这几天一直报这个错。经过查询时证书验证的错误。**

报错：`requests.exceptions.SSLError: HTTPSConnectionPool(host='tc.ltyuanfang.cn', port=443): Max retries exceeded with url: /api/token (Caused by SSLError(SSLError("bad handshake: Error([('SSL routines', 'tls_process_server_certificate', 'certificate verify failed')])")))`

**解决方法：**

```python
login = requests.post(url=url_token, data=payload,verify=False).text
```

* 请求参数加上跳过验证：`verify=False`



**然后，引入代码：**

```python
import urllib3
urllib3.disable_warnings()
```

