title: centos查看编译参数
date: '2022-06-13 19:31:14'
updated: '2022-06-13 19:31:14'
tags: [Linux]
permalink: /articles/2022/06/13/1655119874001.html
---
**查看nginx编译参数：/usr/local/nginx/sbin/nginx -V**
**查看apache编译参数：cat /usr/local/apache2/build/config.nice**
**查看mysql编译参数：cat /usr/local/mysql/bin/mysqlbug | grep CONFIGURE_LINE**
**查看php编译参数：/usr/local/php/bin/php -i | grep configure**


