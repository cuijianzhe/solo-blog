title: windows系统ping加上时间戳并且cmd隐藏运行实现方法
date: '2019-05-15 15:59:18'
updated: '2019-06-01 22:21:51'
tags: [网络]
permalink: /articles/2019/05/15/1557907158513.html
---
今天遇到这个需求了，因为有部分电脑网络偶尔出现问题，又不好排查，所以搞了一个这个脚本，感谢各位前辈，善加改进已经可用。
效果如下哦：
<img src="https://cjz.cjzshilong.cn/pingecho.png" width=789 height=377 />

## 添加一个脚本vbs。
```
Dim args, flag, unsuccOut

args=""
otherout=""
flag=0

If WScript.Arguments.count = 0 Then
WScript.Echo "Usage: cscript tping.vbs [-t] [-a] [-n count] [-l size] [-f] [-i TTL] [-v TOS]"
WScript.Echo "                         [-s count] [[-j host-list] | [-k host-list]]"
WScript.Echo "                         [-r count] [-w timeout] destination-list"
wscript.quit
End if

For i=0 to WScript.Arguments.count - 1
args=args & " " & WScript.Arguments(i)
Next

Set shell = WScript.CreateObject("WScript.Shell")
Set re=New RegExp
re.Pattern="^Reply|^Request|^来自|^请求"

Set myping=shell.Exec("ping" & args)

while Not myping.StdOut.AtEndOfStream
   strLine=myping.StdOut.ReadLine()
'WScript.Echo  "原数据" & chr(9) & strLine
   r=re.Test(strLine)
   If r Then
WScript.Echo date & " "& time & chr(9) & strLine
flag=1
   Else
unsuccOut=unsuccOut & strLine
   End if
Wend

if flag = 0 then
WScript.Echo unsuccOut
end if
```

可复制到文本改成vbs后缀即可。使用方法：把脚本放到指定盘符或者目录。使用如下命令：

`cscript D:\ping1.vbs www.baidu.com -t >> D:\baidu.txt`

然后找到对应文件即可，是一个排查网络稳定性的好方法。

## 隐藏窗口实现（bat脚本文件）：
```
@echo off

if "%1" == "h" goto begin
mshta vbscript:createobject("wscript.shell").run("""%~nx0"" h",0)(window.close)&&exit
:begin
REM
cscript D:\ping.vbs www.baidu.com -t >> D:\baidu.txt
```
运行这个脚本即可实现没有cmd窗口后台运行，亲测。如有需求可添加启动项或者计划任务里面搞一下，这样不用手动去触发，试试监控输出日志信息。

## 设置启动项，开机自启动：
<img src="https://cjz.cjzshilong.cn/start.png" width=600 height=300 />


<img src="https://cjz.cjzshilong.cn/qidongxiang.png" width=700 height=300 />
<img src="https://cjz.cjzshilong.cn/renwuguanliqi.png" width=700 height=300 />




