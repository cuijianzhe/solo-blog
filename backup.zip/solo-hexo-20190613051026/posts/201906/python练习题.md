title: python练习题
date: '2019-06-05 14:35:35'
updated: '2019-06-12 16:12:01'
tags: [python]
permalink: /articles/2019/06/05/1559716535382.html
---

# 一、字符串、列表、元组、字典、集合练习
## 1.1 BMI计算输出
> BMI指数(Body Mass Index) 以称身体质量指数
    BMI值计算公式: BMI = 体重(公斤) / 身高的平方(米)
例如:
    一个人69公斤，身高是173公分
    BMI = 69 / 1.73**2 = 23.05
标准表:
    BMI < 18.5   体重过轻
    18.5 <= BMI < 24 体重正常
    BMI > 24  体重过重
要求: 输入身高的体重，打印出BMI的值并打印体重状况

```python
#!/bin/python3

Height = float(input('请输入身高(米)：'))
Weight = float(input('请输入体重(公斤)：'))
BMI =  Weight / Height **2
print('%.2f'%BMI)
if BMI < 18.5:
   print('您的体重过轻，BMI值为：%.2f' %BMI)
elif  BMI < 24:
   print('您的体重正常，BMI值为：%.2f'%BMI)
else:
   print('您的体重过重，BMI值为：%.2f'%BMI)
```
## 1.2：统计字符串类型
> 题目要求!任意输入一串字母加数字，统计出，整数出现的个数。（字母不限大小写！）
   例：`123abc456efg123asd88$#@`
>   输出规范：
>   print(整数总共出现4次)

### 1.2.1 解决方法1：
```
#!/usr/bin/python3
# @Time  : 2019/6/7 13:58
# @Author : cuijianzhe
# @File  : str.py
# @Software: PyCharm
#a = "123abc456efg123asd88$#@"
a = input("请输入你需要查询的字符串包含数字和字母:")
num_list = [i for i in a if i.isdigit()]
print("出现数字的次数为:{},分别为{}".format(len(num_list),num_list))
num_set = set(num_list)
print("去重后的数字整数个数为{},分别为{}:".format(len(num_set),num_set))
```

输出结果：
```
请输入你需要查询的字符串包含数字和字母:123abc456efg123asd88$#@
出现数字的次数为:11,分别为['1', '2', '3', '4', '5', '6', '1', '2', '3', '8', '8']
去重后的数字整数个数为7,分别为{'8', '4', '1', '6', '3', '5', '2'}
```
### 1.2.2 解决方法2：
```python
#!/usr/bin/python3
# @Time  : 2019/6/7 13:58
# @Author : cuijianzhe
# @File  : str.py
# @Software: PyCharm
#a = "123abc456efg123asd88$#@"
a = input('请输入一串包含数字和字母的字符串：')
dict_str = {"num":0,"letter":0,"other":0}

for item in a:
    if item.isdigit():
        dict_str["num"] = dict_str["num"] + 1
    elif item.isalpha():
        dict_str["letter"] = dict_str["letter"] + 1
    else:
        dict_str["other"] = dict_str["other"] + 1
print(" 字符串：{}\n 数字个数：{}\n 字母个数：{}\n 其他字符：{}".format(a,dict_str["num"],dict_str["letter"],dict_str["other"]))
`````
输出结果：
```
$ python3 /python_file/str.py        

请输入一串包含字母或者数字或者特殊字符的字符串:123abc456efg123asd88$#@
字符串:123abc456efg123asd88$#@
数字个数：11
字母个数：9
其他特殊字符个数：3
```
# 二、编程第一步
## 2.1 裴波那契数列
```python
#!/bin/python3
# Fibonacci series: 斐波纳契数列
# 两个元素的总和确定了下一个数
a,b = 0, 1
while b < 1000:
    print(b,end=' ')
    a, b = b, a+b
```
输出结果：
```python
[root@cjz ~]# python3 shulie.py 

1 1 2 3 5 8 13 21 34 55 89 144 233 377 610 987 
```
## 2.2 韩信点兵
> 汉代名将韩信带1500名士兵打仗，战死四五百人，战后清点人数，3 人一排多出2人，5人一排，多出4人；7人一排，多出6人。韩信很快说出剩余人数：1049人。请问对吗？  
请用python验证：  
思路：定义变量，输出变量与3的余数，与5的余数，与7的余数

```
#!/bin/python3
#验证韩信结果：
sum = 1500
a = 1049
if (sum-a)%3==2 and (sum-a)%5==4 and (sum-a)%7==6:
    print('韩信说得对')
else:
    print('韩信说的不对')
#战死四五百人，说明最大人数为1100，最少人数为1000.
for i in range(1000,1100):
    if(i % 3 ==2 and i % 5 ==3 and i % 7 ==6):
        print('剩余士兵人数应该为:',i ,'个人')
```

## 2.3 字符串统计判断

> 给你一个字符串例如：’abcsadfadsfgfegegegea’，经过计算返回一个字典，字典中包含每个元素当中的个数，结合if 判断，for 循环，完成本次代码！
 例如：‘abb’ --> {‘a’:1,’b’:2}

### 2.3.1 最佳代码：
```
str = 'abcsadfadsfgfegegegea'

dict = {}
for i in str:
    dict[i]=str.count(i)
print(dict)
```
### 2.3.2 水
```
#水代码：只符合结果，不符合题意。
a = list(input('请输入你要查询的字符串：'))

set_a = set(a)
list_set = list(set_a)
# print(list_set)
print('不重复的字符为：%s' % (list_set))
for i in list_set:
    print('输入的字符串中{}的个数为{}'.format(i, a.count(i)))

```
## 2.4 字符串统计
> 输入任意行文字，存于列表L中,当不输入任何容直接回车后结束输入
   1) 打印L列表中的内容
   2) 计算您共输入了几行内容
   3) 计算您共输入了多少个字符
### 2.4.1 解决方法1：

```
a = 1
L = []
while a:
    b = str(input('输入任意行文字，回车结束：'))
    if  b.strip() == '':
        break
    else:
        L.append(b)
print('列表中的内容：{}\n一共输入{}行内容\n一共输入{}个字符'.format(L,len(L),len(''.join(L))))

```

### 2.4.2 解决方法2：
```
L = []
while 1 :
    s =  input('请输入任意字符：')
    if bool(s):
        L.append(s)
    else:
        break
print(L)
```
## 2.5 循环（while、for）打印树干
> 输入一个整数（代表树干的高度)
     打印出如下一棵树
     输入: 2
     打印: 
      *
   \***
      *
      *
     输入:3
       *
    \***
  \*****
       *
       *
       *

### 2.5.1 解决方法1：
  
```
n = int(input('输入一个正整数：'))

count = 1
while(n-count>=0):
    print(' '*(n-count) + '*'*(count*2-1) + ' '*(n-count))
    count = count + 1
count2 = 1
while(n-count2>=0):
    print(' '*(n-1) + '*'*(1*2-1) + ' '*(n-1))
    count2 = count2 + 1

```
### 2.5.2  解决方法2：

```
n = input("请输入一个整数：")

n = int(n)
for j in range(1,n+1):
    print(' '*(n-j),'*'*(j*2-1),' '*(n-j),end='\n')
for j in range(1,n+1):
    print(' '*(n-1),'*',end='\n')
```
### 2.5.3 拓展：打印金字塔树干：
```
tall_num =int(input("请输入高度(金字塔打印)："))

for i in range (tall_num + 1):
    print(" "*(tall_num - i),end=" ")
    print(" *"*(i+1))
for i in range (tall_num):
    print(' '*(tall_num+2)+'*')
```

## 2.6 判断是否为质数（素数）
> 写一个程序，任意输入一个整数，判断这个数是否是素数(prime)
    素数(也叫质数), 是只能被1和自身整除的正整数:
      如: 2 3 5 7 11 等
    提示:
      用排除法: 当判断x是否是素数是，只要让x分别除以:
        2, 3, 4, 5, .... x-1, 只要整除了，那x不是素数，否则x是素数

```
num = int(input('请输入一个正整数：'))
if num<2:
    print('请输入大于2的正整数')
else:
    for i in range(2,num):
        if (num % i) == 0:
            print(num,'不是质数')
            print(i,"乘以",num//i,"是",num)
            break
        else:
            print(num,'这个数是质数')

```