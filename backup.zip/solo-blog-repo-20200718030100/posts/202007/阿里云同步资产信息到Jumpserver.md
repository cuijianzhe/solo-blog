title: 阿里云同步资产信息到Jumpserver
date: '2020-07-16 19:47:40'
updated: '2020-07-17 18:20:35'
tags: [Python, Jumpserver]
permalink: /articles/2020/07/16/1594900059981.html
---
## 同步资产信息到Jumpserver

[**Jumpserver开发文档：**](https://docs.jumpserver.org/zh/master/)

* **创建API Key**![image.png](https://b3logfile.com/file/2020/07/image-d177f759.png)

[**阿里云API文档：**](https://help.aliyun.com/document_detail/25506.html?spm=a2c4g.11186623.2.21.64c215301AOgg0#doc-api-Ecs-DescribeInstances)

#### **具体代码：**

* 添加本地IDC机房服务器**白名单**，避免同步阿里云删除本地机房服务器资产
* 同步比较Jumpserver创建的重复资产
* 实时同步线上资产到Jumpserver
* 同步操作发送结果到**钉钉**消息

```python
#!/usr/bin/env python3
#coding=utf-8
import json
import requests
import time
from httpsig.requests_auth import HTTPSignatureAuth

from aliyunsdkcore.client import AcsClient
from aliyunsdkecs.request.v20140526.DescribeInstancesRequest import DescribeInstancesRequest

from collections import Counter
#192.168.51.208
KEY_ID = 'keyid'
SECRET = 'secret'
Jumpserver_url = 'http://192.168.51.208'

#aliyun参数

aliyun_ip_list = []
aliyun_name_list = []
JumpIP_list = []
JumpID_list = []
client = AcsClient('<accessKeyId>', '<accessSecret>', 'cn-beijing')
class aliyun_ecs():
    def __init__(self,num,client=client):
        self.client = client
        self.num = num
    def assets_list(self):
        request = DescribeInstancesRequest()
        request.set_accept_format('json')
        request.set_PageNumber(self.num)
        request.set_PageSize(100)
        response = json.loads(self.client.do_action_with_exception(request))
        instances_list = response.get('Instances').get('Instance')

        for info in instances_list:
            assetsName = info.get('InstanceName')
            aliyun_name_list.append(assetsName)
            assetsIp = ''.join(info.get('VpcAttributes').get('PrivateIpAddress').get('IpAddress'))
            aliyun_ip_list.append(assetsIp)
        return aliyun_ip_list,aliyun_name_list

class Jumpserver():
    def __init__(self,host=Jumpserver_url,keyid=KEY_ID,secret=SECRET):
        self.host = host
        self.keyid = keyid
        self.secret = secret
    def assets_list(self):
        url = self.host + '/api/v1/assets/assets/'
        signature_headers = ['(request-target)', 'accept', 'date', 'host']
        headers = {
            'Accept': 'application/json',
            'Date': str(time.strftime("%a %b %d %H:%M:%S %Y", time.localtime()))
        }
        auth = HTTPSignatureAuth(key_id=self.keyid, secret=self.secret,
                                 algorithm='hmac-sha256',
                                 headers=signature_headers)
        req = requests.get(url, auth=auth, headers=headers)
        list = json.loads(req.content)
        for var in list:
            JumpIP_list.append(var.get('ip'))
            JumpID_list.append(var.get('id'))

class new_Jumpserver():
    def __init__(self,ip,hostname,host=Jumpserver_url,keyid=KEY_ID,secret=SECRET):
        self.host = host
        self.keyid = keyid
        self.secret = secret
        self.ip = ip
        self.hostname = hostname

    def get_assets(self):
        url = self.host + '/api/v1/assets/assets/'
        signature_headers = ['(request-target)', 'accept', 'date', 'host']
        headers = {
            'Accept': 'application/json',
            'Date': "Mon, 17 Feb 2014 06:11:05 GMT"
        }
        auth = HTTPSignatureAuth(key_id=self.keyid, secret=self.secret,
                                 algorithm='hmac-sha256',
                                 headers=signature_headers)
        req = requests.get(url, auth=auth, headers=headers)
        return json.loads(req.content)

    def create_assets(self):
        url = self.host + '/api/v1/assets/assets/'
        signature_headers = ['(request-target)', 'accept', 'date', 'host']
        headers = {
            'Accept': 'application/json',
            'Date': str(time.strftime("%a %b %d %H:%M:%S %Y", time.localtime()))
        }
        auth = HTTPSignatureAuth(key_id=self.keyid, secret=self.secret,
                                 algorithm='hmac-sha256',
                                 headers=signature_headers)
        data = {
            'hostname': self.hostname,
            'ip': self.ip,
            'platform':'Linux',
            'nodes': self.get_assets()[0].get('nodes')[0],
            "admin_user_display": "limi_admin",
            "protocols": ["ssh/5203"],
            "created_by": "Administrator",
            "admin_user": self.get_assets()[0].get('admin_user'),
            "is_active": 'true',
        }
        req = requests.post(url,auth=auth,headers=headers,data=data)
        return json.loads(req.content)

def delete_assets(id):
    # /assets/nodes/{id}/
    url = Jumpserver_url + '/api/v1/assets/assets/{}/'.format(id)
    signature_headers = ['(request-target)', 'accept', 'date', 'host']
    headers = {
        'Accept': 'application/json',
        'Date': "Mon, 17 Feb 2014 06:11:05 GMT"
    }
    auth = HTTPSignatureAuth(key_id=KEY_ID, secret=SECRET,
                             algorithm='hmac-sha256',
                             headers=signature_headers)
    req = requests.delete(url, auth=auth, headers=headers)
    return req.content.decode('utf-8')

def send_msg(text):
    headers = {'Content-Type': 'application/json;charset=utf-8'}
    api_url = "https://oapi.dingtalk.com/robot/send?access_token=my_access_token"
    json_text= {
        "actionCard": {
            "title": "Jumpserver同步资产通知",
            "text":
             text,
            "hideAvatar": "0",
            "btnOrientation": "0",
            "btns": [
                {
                    "title": "Jumpserver链接",
                    "actionURL": "http://opt-jumpserver.jump.com"
                },
            ]
        },
        "msgtype": "actionCard"
    }
    Text = requests.post(api_url,data=json.dumps(json_text),headers=headers).json()
    return Text

def main():
    #本地机房服务器白名单
    white_list_ip = ['192.168.51.200','192.168.51.201','192.168.51.202','192.168.51.203','192.168.51.204','192.168.51.205','192.168.51.206',
                     '192.168.51.207','192.168.51.208','192.168.51.209','192.168.51.210','192.168.51.211','192.168.51.212','192.168.51.213',
                     '192.168.51.214',]
    #ali全部资产写入列表
    for num in range(1,7):
        all_assets = aliyun_ecs(int(num))
        aliyun_list = all_assets.assets_list()
    aliassets_dict = dict(list(zip(aliyun_list[0],aliyun_list[1]))) #将aliyun资产ip和命名合并成字典

    #jumpserver全部资产
    jump_assets = Jumpserver()
    jump_assets.assets_list()
    jumpserver_dict = dict(list(zip(JumpIP_list,JumpID_list))) #将Jumpserver资产合并成子字典

    #检查Jumpserver是否存在重复资产
    dup = dict(Counter(JumpIP_list))
    dup_set = [key for key,value in dup.items()if value > 1]
    if len(dup_set) > 0:
        message = '**Jumpserver中存在重复资产信息：**' + '\n\n' + str(dup_set)
        send_msg(message)
        with open('./log', 'a', encoding='utf-8') as dup_assets:
            dup_assets.write(message +'\n')
    #ali云和Jumpserver资产对比,如果jumpserver有而阿里云以及本地机房没有则删除Jumpserver资产
    for ip in JumpIP_list:
        if ip not in aliyun_ip_list+white_list_ip:
            delete_assets(jumpserver_dict[ip])
            message = '**Jumpserver删除资产通知：**' +'\n\n'+\
                      '**当前时间：**' + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())  + '\n\n' + \
                      '**删除ip:**' + ip
            send_msg(message)
            with open('./log','a',encoding='utf-8') as f:
                f.write(message + '\n')

    #对比同步阿里云的资产到Jumpserver
    for ip in aliyun_ip_list:
        if ip not in JumpIP_list:
            add_asset = new_Jumpserver(ip=ip,hostname=aliassets_dict[ip] + ip)
            add_asset.create_assets()
            message = '**Jumpserver添加资产通知：**'+'\n\n' +\
                      '**当前时间：**' + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())  + '\n\n'+\
                      '**添加ip：**' +ip
            send_msg(message)
            with open('./log','a',encoding='utf-8') as f:
                f.write(message  + '\n')
main()
```
